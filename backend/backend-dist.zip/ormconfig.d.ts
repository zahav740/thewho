import { DataSource } from 'typeorm';
export declare const AppDataSource: DataSource;
