"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const typeorm_1 = require("@nestjs/typeorm");
const platform_express_1 = require("@nestjs/platform-express");
const machines_module_1 = require("./modules/machines/machines.module");
const orders_module_1 = require("./modules/orders/orders.module");
const operations_module_1 = require("./modules/operations/operations.module");
const operators_module_1 = require("./modules/operators/operators.module");
const shifts_module_1 = require("./modules/shifts/shifts.module");
const calendar_module_1 = require("./modules/calendar/calendar.module");
const files_module_1 = require("./modules/files/files.module");
const health_module_1 = require("./modules/health/health.module");
const planning_module_1 = require("./modules/planning/planning.module");
const test_module_1 = require("./modules/test/test.module");
const pets_module_1 = require("./modules/pets/pets.module");
const translations_module_1 = require("./modules/translations/translations.module");
const operation_analytics_module_1 = require("./modules/operation-analytics/operation-analytics.module");
const synchronization_module_1 = require("./modules/synchronization/synchronization.module");
const header_size_middleware_1 = require("./common/middleware/header-size.middleware");
const orders_middleware_1 = require("./modules/orders/orders.middleware");
let AppModule = class AppModule {
    configure(consumer) {
        consumer
            .apply(header_size_middleware_1.HeaderSizeMiddleware)
            .forRoutes('*');
        consumer
            .apply(orders_middleware_1.OrdersDataMiddleware)
            .forRoutes('/api/orders', '/api/orders/:id');
    }
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule.forRoot({
                isGlobal: true,
            }),
            platform_express_1.MulterModule.register({
                limits: {
                    fileSize: 100 * 1024 * 1024,
                    files: 10,
                },
            }),
            typeorm_1.TypeOrmModule.forRoot({
                type: 'postgres',
                host: process.env.DB_HOST || 'localhost',
                port: parseInt(process.env.DB_PORT, 10) || 5432,
                username: process.env.DB_USERNAME || 'postgres',
                password: process.env.DB_PASSWORD || 'magarel',
                database: process.env.DB_NAME || 'thewho',
                entities: [__dirname + '/database/entities/*.entity{.ts,.js}', __dirname + '/modules/*/entities/*.entity{.ts,.js}'],
                synchronize: false,
                logging: process.env.NODE_ENV === 'development',
                autoLoadEntities: true,
                retryAttempts: 3,
                retryDelay: 3000,
            }),
            machines_module_1.MachinesModule,
            orders_module_1.OrdersModule,
            operations_module_1.OperationsModule,
            operators_module_1.OperatorsModule,
            shifts_module_1.ShiftsModule,
            calendar_module_1.CalendarModule,
            files_module_1.FilesModule,
            planning_module_1.PlanningModule,
            health_module_1.HealthModule,
            test_module_1.TestModule,
            pets_module_1.PetsModule,
            translations_module_1.TranslationsModule,
            operation_analytics_module_1.OperationAnalyticsModule,
            synchronization_module_1.SynchronizationModule,
        ],
    })
], AppModule);
//# sourceMappingURL=app.module.js.map