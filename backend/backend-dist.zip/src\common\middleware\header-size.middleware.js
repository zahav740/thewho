"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HeaderSizeMiddleware = void 0;
const common_1 = require("@nestjs/common");
let HeaderSizeMiddleware = class HeaderSizeMiddleware {
    use(req, res, next) {
        const headersSize = JSON.stringify(req.headers).length;
        const maxHeaderSize = 8192;
        if (headersSize > maxHeaderSize) {
            console.error('Headers too large:', {
                size: headersSize,
                headers: Object.keys(req.headers).map(key => ({
                    key,
                    length: String(req.headers[key]).length
                })).sort((a, b) => b.length - a.length).slice(0, 5)
            });
            throw new common_1.HttpException('Request header fields too large', 431);
        }
        const headersToRemove = ['cookie', 'referer', 'user-agent'];
        headersToRemove.forEach(header => {
            if (req.headers[header] && String(req.headers[header]).length > 1024) {
                delete req.headers[header];
            }
        });
        next();
    }
};
exports.HeaderSizeMiddleware = HeaderSizeMiddleware;
exports.HeaderSizeMiddleware = HeaderSizeMiddleware = __decorate([
    (0, common_1.Injectable)()
], HeaderSizeMiddleware);
//# sourceMappingURL=header-size.middleware.js.map