import { Operation } from './operation.entity';
export declare enum MachineType {
    MILLING_3AXIS = "milling-3axis",
    MILLING_4AXIS = "milling-4axis",
    TURNING = "turning"
}
export declare class MachineAvailability {
    id: string;
    machineName: string;
    machineType: string;
    isAvailable: boolean;
    currentOperationId: string;
    currentOperation: Operation;
    lastFreedAt: Date;
    createdAt: Date;
    updatedAt: Date;
    canPerformOperation(operationType: string): boolean;
    getTypeLabel(): string;
}
