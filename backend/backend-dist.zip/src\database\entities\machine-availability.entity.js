"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MachineAvailability = exports.MachineType = void 0;
const typeorm_1 = require("typeorm");
const operation_entity_1 = require("./operation.entity");
var MachineType;
(function (MachineType) {
    MachineType["MILLING_3AXIS"] = "milling-3axis";
    MachineType["MILLING_4AXIS"] = "milling-4axis";
    MachineType["TURNING"] = "turning";
})(MachineType || (exports.MachineType = MachineType = {}));
let MachineAvailability = class MachineAvailability {
    canPerformOperation(operationType) {
        switch (operationType) {
            case '3-axis':
                return ['milling-3axis', 'milling-4axis'].includes(this.machineType);
            case '4-axis':
                return this.machineType === 'milling-4axis';
            case 'turning':
                return this.machineType === 'turning';
            default:
                return false;
        }
    }
    getTypeLabel() {
        switch (this.machineType) {
            case 'milling-4axis':
                return 'Фрезерный 3-4 оси';
            case 'milling-3axis':
                return 'Фрезерный 3 оси';
            case 'turning':
                return 'Токарный';
            default:
                return this.machineType;
        }
    }
};
exports.MachineAvailability = MachineAvailability;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], MachineAvailability.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'machine_name', unique: true }),
    __metadata("design:type", String)
], MachineAvailability.prototype, "machineName", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'machine_type', type: 'varchar' }),
    __metadata("design:type", String)
], MachineAvailability.prototype, "machineType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'is_available', default: true }),
    __metadata("design:type", Boolean)
], MachineAvailability.prototype, "isAvailable", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'current_operation_id', type: 'varchar', nullable: true }),
    __metadata("design:type", String)
], MachineAvailability.prototype, "currentOperationId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => operation_entity_1.Operation, { nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'current_operation_id' }),
    __metadata("design:type", operation_entity_1.Operation)
], MachineAvailability.prototype, "currentOperation", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'last_freed_at', type: 'timestamp', nullable: true }),
    __metadata("design:type", Date)
], MachineAvailability.prototype, "lastFreedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], MachineAvailability.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Date)
], MachineAvailability.prototype, "updatedAt", void 0);
exports.MachineAvailability = MachineAvailability = __decorate([
    (0, typeorm_1.Entity)('machine_availability')
], MachineAvailability);
//# sourceMappingURL=machine-availability.entity.js.map