export declare enum MachineType {
    MILLING = "MILLING",
    TURNING = "TURNING"
}
export declare class Machine {
    id: number;
    code: string;
    type: MachineType;
    axes: number;
    isActive: boolean;
    isOccupied: boolean;
    createdAt: Date;
    updatedAt: Date;
}
