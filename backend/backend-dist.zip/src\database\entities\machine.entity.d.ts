export declare enum MachineType {
    MILLING = "MILLING",
    TURNING = "TURNING"
}
export declare class Machine {
    id: number;
    code: string;
    type: string;
    axes: number;
    isActive: boolean;
    isOccupied: boolean;
    currentOperation: number;
    assignedAt: Date;
    createdAt: Date;
    updatedAt: Date;
}
