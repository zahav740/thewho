import { Order } from './order.entity';
export declare class OperationProgress {
    id: string;
    order: Order;
    orderId: number;
    calculationDate: Date;
    startDate: Date;
    deadline: Date;
    estimatedCompletionDate: Date;
    quantity: number;
    totalProductionTime: number;
    totalSetupTime: number;
    totalRequiredTime: number;
    requiredWorkdays: number;
    willMeetDeadline: boolean;
    timeMargin: number;
    operations: any[];
    createdAt: Date;
    updatedAt: Date;
}
