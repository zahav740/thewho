"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationProgress = void 0;
const typeorm_1 = require("typeorm");
const order_entity_1 = require("./order.entity");
let OperationProgress = class OperationProgress {
};
exports.OperationProgress = OperationProgress;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)('uuid'),
    __metadata("design:type", String)
], OperationProgress.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => order_entity_1.Order),
    (0, typeorm_1.JoinColumn)({ name: 'order_id' }),
    __metadata("design:type", order_entity_1.Order)
], OperationProgress.prototype, "order", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'order_id', type: 'integer' }),
    __metadata("design:type", Number)
], OperationProgress.prototype, "orderId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'calculation_date', type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' }),
    __metadata("design:type", Date)
], OperationProgress.prototype, "calculationDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'start_date', type: 'timestamp', nullable: true }),
    __metadata("design:type", Date)
], OperationProgress.prototype, "startDate", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'deadline', type: 'timestamp' }),
    __metadata("design:type", Date)
], OperationProgress.prototype, "deadline", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'estimated_completion_date', type: 'timestamp', nullable: true }),
    __metadata("design:type", Date)
], OperationProgress.prototype, "estimatedCompletionDate", void 0);
__decorate([
    (0, typeorm_1.Column)(),
    __metadata("design:type", Number)
], OperationProgress.prototype, "quantity", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'total_production_time' }),
    __metadata("design:type", Number)
], OperationProgress.prototype, "totalProductionTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'total_setup_time' }),
    __metadata("design:type", Number)
], OperationProgress.prototype, "totalSetupTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'total_required_time' }),
    __metadata("design:type", Number)
], OperationProgress.prototype, "totalRequiredTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'required_workdays' }),
    __metadata("design:type", Number)
], OperationProgress.prototype, "requiredWorkdays", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'will_meet_deadline' }),
    __metadata("design:type", Boolean)
], OperationProgress.prototype, "willMeetDeadline", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'time_margin' }),
    __metadata("design:type", Number)
], OperationProgress.prototype, "timeMargin", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'jsonb' }),
    __metadata("design:type", Array)
], OperationProgress.prototype, "operations", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], OperationProgress.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Date)
], OperationProgress.prototype, "updatedAt", void 0);
exports.OperationProgress = OperationProgress = __decorate([
    (0, typeorm_1.Entity)('operation_progress')
], OperationProgress);
//# sourceMappingURL=operation-progress.entity.js.map