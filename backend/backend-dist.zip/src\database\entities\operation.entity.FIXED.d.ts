import { Order } from './order.entity';
import { Machine } from './machine.entity';
import { ShiftRecord } from './shift-record.entity';
export declare enum OperationStatus {
    PENDING = "PENDING",
    IN_PROGRESS = "IN_PROGRESS",
    COMPLETED = "COMPLETED",
    ON_HOLD = "ON_HOLD"
}
export declare enum OperationType {
    MILLING = "MILLING",
    TURNING = "TURNING",
    DRILLING = "DRILLING",
    GRINDING = "GRINDING"
}
export declare class Operation {
    id: number;
    operationNumber: number;
    get sequenceNumber(): number;
    operationType: string;
    estimatedTime: number;
    machineAxes: number;
    status: string;
    machine: string;
    completedUnits: number;
    actualTime: number;
    operators: any[];
    order: Order;
    machineEntity: Machine;
    shiftRecords: ShiftRecord[];
    createdAt: Date;
    updatedAt: Date;
}
