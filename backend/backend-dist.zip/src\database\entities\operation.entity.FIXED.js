"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Operation = exports.OperationType = exports.OperationStatus = void 0;
const typeorm_1 = require("typeorm");
const order_entity_1 = require("./order.entity");
const machine_entity_1 = require("./machine.entity");
const shift_record_entity_1 = require("./shift-record.entity");
var OperationStatus;
(function (OperationStatus) {
    OperationStatus["PENDING"] = "PENDING";
    OperationStatus["IN_PROGRESS"] = "IN_PROGRESS";
    OperationStatus["COMPLETED"] = "COMPLETED";
    OperationStatus["ON_HOLD"] = "ON_HOLD";
})(OperationStatus || (exports.OperationStatus = OperationStatus = {}));
var OperationType;
(function (OperationType) {
    OperationType["MILLING"] = "MILLING";
    OperationType["TURNING"] = "TURNING";
    OperationType["DRILLING"] = "DRILLING";
    OperationType["GRINDING"] = "GRINDING";
})(OperationType || (exports.OperationType = OperationType = {}));
let Operation = class Operation {
    get sequenceNumber() {
        return this.operationNumber;
    }
};
exports.Operation = Operation;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], Operation.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'operation_number' }),
    __metadata("design:type", Number)
], Operation.prototype, "operationNumber", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'operation_type', nullable: true }),
    __metadata("design:type", String)
], Operation.prototype, "operationType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'estimated_time' }),
    __metadata("design:type", Number)
], Operation.prototype, "estimatedTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'machine_axes', nullable: true }),
    __metadata("design:type", Number)
], Operation.prototype, "machineAxes", void 0);
__decorate([
    (0, typeorm_1.Column)({ default: 'PENDING' }),
    __metadata("design:type", String)
], Operation.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ nullable: true }),
    __metadata("design:type", String)
], Operation.prototype, "machine", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'completed_units', default: 0, nullable: true }),
    __metadata("design:type", Number)
], Operation.prototype, "completedUnits", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'actual_time', nullable: true }),
    __metadata("design:type", Number)
], Operation.prototype, "actualTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'jsonb', default: '[]', nullable: true }),
    __metadata("design:type", Array)
], Operation.prototype, "operators", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => order_entity_1.Order, (order) => order.operations, {
        onDelete: 'CASCADE',
    }),
    (0, typeorm_1.JoinColumn)({ name: 'order_id' }),
    __metadata("design:type", order_entity_1.Order)
], Operation.prototype, "order", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => machine_entity_1.Machine, { nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'machineId' }),
    __metadata("design:type", machine_entity_1.Machine)
], Operation.prototype, "machineEntity", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => shift_record_entity_1.ShiftRecord, (shiftRecord) => shiftRecord.operation, { nullable: true }),
    __metadata("design:type", Array)
], Operation.prototype, "shiftRecords", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], Operation.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Date)
], Operation.prototype, "updatedAt", void 0);
exports.Operation = Operation = __decorate([
    (0, typeorm_1.Entity)('operations')
], Operation);
//# sourceMappingURL=operation.entity.FIXED.js.map