import { Order } from './order.entity';
export declare enum OperationStatus {
    PENDING = "PENDING",
    IN_PROGRESS = "IN_PROGRESS",
    COMPLETED = "COMPLETED",
    ON_HOLD = "ON_HOLD"
}
export declare enum OperationType {
    MILLING = "MILLING",
    TURNING = "TURNING",
    DRILLING = "DRILLING",
    GRINDING = "GRINDING"
}
export declare class Operation {
    id: number;
    operationNumber: number;
    get sequenceNumber(): number;
    operationType: string;
    estimatedTime: number;
    machineAxes: number;
    status: string;
    machine: string;
    order: Order;
    createdAt: Date;
    updatedAt: Date;
}
