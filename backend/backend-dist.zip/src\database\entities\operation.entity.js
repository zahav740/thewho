"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Operation = exports.OperationType = exports.OperationStatus = void 0;
const typeorm_1 = require("typeorm");
const order_entity_1 = require("./order.entity");
var OperationStatus;
(function (OperationStatus) {
    OperationStatus["PENDING"] = "PENDING";
    OperationStatus["IN_PROGRESS"] = "IN_PROGRESS";
    OperationStatus["COMPLETED"] = "COMPLETED";
    OperationStatus["ON_HOLD"] = "ON_HOLD";
})(OperationStatus || (exports.OperationStatus = OperationStatus = {}));
var OperationType;
(function (OperationType) {
    OperationType["MILLING"] = "MILLING";
    OperationType["TURNING"] = "TURNING";
    OperationType["DRILLING"] = "DRILLING";
    OperationType["GRINDING"] = "GRINDING";
})(OperationType || (exports.OperationType = OperationType = {}));
let Operation = class Operation {
    get sequenceNumber() {
        return this.operationNumber;
    }
};
exports.Operation = Operation;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], Operation.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'operationNumber' }),
    __metadata("design:type", Number)
], Operation.prototype, "operationNumber", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'operationtype', nullable: true }),
    __metadata("design:type", String)
], Operation.prototype, "operationType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'estimatedTime' }),
    __metadata("design:type", Number)
], Operation.prototype, "estimatedTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'machineaxes', nullable: true }),
    __metadata("design:type", Number)
], Operation.prototype, "machineAxes", void 0);
__decorate([
    (0, typeorm_1.Column)({ default: 'PENDING' }),
    __metadata("design:type", String)
], Operation.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'assignedMachine', nullable: true }),
    __metadata("design:type", Number)
], Operation.prototype, "assignedMachine", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'assignedAt', nullable: true }),
    __metadata("design:type", Date)
], Operation.prototype, "assignedAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'completedAt', nullable: true }),
    __metadata("design:type", Date)
], Operation.prototype, "completedAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'actualQuantity', nullable: true }),
    __metadata("design:type", Number)
], Operation.prototype, "actualQuantity", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => order_entity_1.Order, (order) => order.operations, {
        onDelete: 'CASCADE',
    }),
    (0, typeorm_1.JoinColumn)({ name: 'orderId' }),
    __metadata("design:type", order_entity_1.Order)
], Operation.prototype, "order", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'createdAt' }),
    __metadata("design:type", Date)
], Operation.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updatedAt' }),
    __metadata("design:type", Date)
], Operation.prototype, "updatedAt", void 0);
exports.Operation = Operation = __decorate([
    (0, typeorm_1.Entity)('operations')
], Operation);
//# sourceMappingURL=operation.entity.js.map