import { Operation } from './operation.entity';
export declare enum Priority {
    CRITICAL = 1,
    HIGH = 2,
    MEDIUM = 3,
    LOW = 4
}
export declare class Order {
    id: number;
    drawingNumber: string;
    quantity: number;
    deadline: Date;
    priority: number;
    workType: string;
    pdfPath: string;
    operations: Operation[];
    createdAt: Date;
    updatedAt: Date;
}
