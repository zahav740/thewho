"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Order = exports.Priority = void 0;
const typeorm_1 = require("typeorm");
const operation_entity_1 = require("./operation.entity");
var Priority;
(function (Priority) {
    Priority[Priority["CRITICAL"] = 1] = "CRITICAL";
    Priority[Priority["HIGH"] = 2] = "HIGH";
    Priority[Priority["MEDIUM"] = 3] = "MEDIUM";
    Priority[Priority["LOW"] = 4] = "LOW";
})(Priority || (exports.Priority = Priority = {}));
let Order = class Order {
};
exports.Order = Order;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], Order.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'drawing_number', unique: true, nullable: true }),
    __metadata("design:type", String)
], Order.prototype, "drawingNumber", void 0);
__decorate([
    (0, typeorm_1.Column)(),
    __metadata("design:type", Number)
], Order.prototype, "quantity", void 0);
__decorate([
    (0, typeorm_1.Column)('date'),
    __metadata("design:type", Date)
], Order.prototype, "deadline", void 0);
__decorate([
    (0, typeorm_1.Column)(),
    __metadata("design:type", Number)
], Order.prototype, "priority", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'workType', nullable: true }),
    __metadata("design:type", String)
], Order.prototype, "workType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'pdfPath', nullable: true }),
    __metadata("design:type", String)
], Order.prototype, "pdfPath", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => operation_entity_1.Operation, (operation) => operation.order, {
        cascade: true,
    }),
    __metadata("design:type", Array)
], Order.prototype, "operations", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'createdAt' }),
    __metadata("design:type", Date)
], Order.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updatedAt' }),
    __metadata("design:type", Date)
], Order.prototype, "updatedAt", void 0);
exports.Order = Order = __decorate([
    (0, typeorm_1.Entity)('orders')
], Order);
//# sourceMappingURL=order.entity.backup.js.map