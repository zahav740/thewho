import { Operation } from './operation.entity';
export declare enum Priority {
    CRITICAL = 1,
    HIGH = 2,
    MEDIUM = 3,
    LOW = 4
}
export declare class Order {
    id: number;
    drawingNumber: string;
    deadline: Date;
    quantity: number;
    priority: number;
    workType: string;
    pdfPath: string;
    name?: string;
    clientName?: string;
    remainingQuantity?: number;
    status?: string;
    completionPercentage?: number;
    forecastedCompletionDate?: Date;
    isOnSchedule?: boolean;
    lastRecalculationAt?: Date;
    pdfUrl?: string;
    operations?: Operation[];
    createdAt: Date;
    updatedAt: Date;
}
