import { Order } from './order.entity';
export declare class PdfFile {
    id: string;
    order: Order;
    orderId: number;
    fileUrl: string;
    previewUrl: string;
    fileName: string;
    createdAt: Date;
    updatedAt: Date;
}
