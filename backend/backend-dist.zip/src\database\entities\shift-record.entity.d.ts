import { Operation } from './operation.entity';
import { Machine } from './machine.entity';
export declare enum ShiftType {
    DAY = "DAY",
    NIGHT = "NIGHT"
}
export declare class ShiftRecord {
    id: number;
    date: Date;
    shiftType: string;
    setupTime: number;
    setupOperator: string;
    dayShiftQuantity: number;
    dayShiftOperator: string;
    dayShiftTimePerUnit: number;
    nightShiftQuantity: number;
    nightShiftOperator: string;
    nightShiftTimePerUnit: number;
    drawingNumber: string;
    operationId: number;
    machineId: number;
    operation: Operation;
    machine: Machine;
    createdAt: Date;
    updatedAt: Date;
    archived: boolean;
    archivedAt: Date;
    resetAt: Date;
}
