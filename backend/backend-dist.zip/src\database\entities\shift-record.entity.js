"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShiftRecord = exports.ShiftType = void 0;
const typeorm_1 = require("typeorm");
const operation_entity_1 = require("./operation.entity");
const machine_entity_1 = require("./machine.entity");
var ShiftType;
(function (ShiftType) {
    ShiftType["DAY"] = "DAY";
    ShiftType["NIGHT"] = "NIGHT";
})(ShiftType || (exports.ShiftType = ShiftType = {}));
const NumericTransformer = {
    from: (value) => value ? parseFloat(value) : null,
    to: (value) => value ? value.toString() : null,
};
let ShiftRecord = class ShiftRecord {
};
exports.ShiftRecord = ShiftRecord;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], ShiftRecord.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)('date'),
    __metadata("design:type", Date)
], ShiftRecord.prototype, "date", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'shiftType' }),
    __metadata("design:type", String)
], ShiftRecord.prototype, "shiftType", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'setupTime', nullable: true }),
    __metadata("design:type", Number)
], ShiftRecord.prototype, "setupTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'setupOperator', nullable: true }),
    __metadata("design:type", String)
], ShiftRecord.prototype, "setupOperator", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'dayShiftQuantity', nullable: true }),
    __metadata("design:type", Number)
], ShiftRecord.prototype, "dayShiftQuantity", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'dayShiftOperator', nullable: true }),
    __metadata("design:type", String)
], ShiftRecord.prototype, "dayShiftOperator", void 0);
__decorate([
    (0, typeorm_1.Column)({
        name: 'dayShiftTimePerUnit',
        type: 'decimal',
        precision: 10,
        scale: 2,
        nullable: true,
        transformer: NumericTransformer
    }),
    __metadata("design:type", Number)
], ShiftRecord.prototype, "dayShiftTimePerUnit", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'nightShiftQuantity', nullable: true }),
    __metadata("design:type", Number)
], ShiftRecord.prototype, "nightShiftQuantity", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'nightShiftOperator', nullable: true }),
    __metadata("design:type", String)
], ShiftRecord.prototype, "nightShiftOperator", void 0);
__decorate([
    (0, typeorm_1.Column)({
        name: 'nightShiftTimePerUnit',
        type: 'decimal',
        precision: 10,
        scale: 2,
        nullable: true,
        transformer: NumericTransformer
    }),
    __metadata("design:type", Number)
], ShiftRecord.prototype, "nightShiftTimePerUnit", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'drawingnumber', nullable: true }),
    __metadata("design:type", String)
], ShiftRecord.prototype, "drawingNumber", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'operationId', nullable: true }),
    __metadata("design:type", Number)
], ShiftRecord.prototype, "operationId", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'machineId', nullable: true }),
    __metadata("design:type", Number)
], ShiftRecord.prototype, "machineId", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => operation_entity_1.Operation, { nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'operationId' }),
    __metadata("design:type", operation_entity_1.Operation)
], ShiftRecord.prototype, "operation", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => machine_entity_1.Machine, { nullable: true }),
    (0, typeorm_1.JoinColumn)({ name: 'machineId' }),
    __metadata("design:type", machine_entity_1.Machine)
], ShiftRecord.prototype, "machine", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'createdAt' }),
    __metadata("design:type", Date)
], ShiftRecord.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updatedAt' }),
    __metadata("design:type", Date)
], ShiftRecord.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'archived', default: false }),
    __metadata("design:type", Boolean)
], ShiftRecord.prototype, "archived", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'archivedAt', nullable: true }),
    __metadata("design:type", Date)
], ShiftRecord.prototype, "archivedAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ name: 'resetAt', nullable: true }),
    __metadata("design:type", Date)
], ShiftRecord.prototype, "resetAt", void 0);
exports.ShiftRecord = ShiftRecord = __decorate([
    (0, typeorm_1.Entity)('shift_records')
], ShiftRecord);
//# sourceMappingURL=shift-record.entity.js.map