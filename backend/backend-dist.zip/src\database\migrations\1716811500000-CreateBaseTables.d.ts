import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class CreateBaseTables1716811500000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
    private tableExists;
    private columnExists;
}
