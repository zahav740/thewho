import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class CreateDrawingNumberColumnIfNotExists1716812000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
