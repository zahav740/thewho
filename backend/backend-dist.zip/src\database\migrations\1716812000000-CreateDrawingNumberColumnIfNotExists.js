"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateDrawingNumberColumnIfNotExists1716812000000 = void 0;
class CreateDrawingNumberColumnIfNotExists1716812000000 {
    async up(queryRunner) {
        const hasColumn = await queryRunner.hasColumn('orders', 'drawing_number');
        if (!hasColumn) {
            await queryRunner.query(`
        ALTER TABLE orders 
        ADD COLUMN "drawing_number" character varying UNIQUE NULL
      `);
            console.log('Column "drawing_number" was created successfully');
        }
        else {
            console.log('Column "drawing_number" already exists, skipping creation');
        }
    }
    async down(queryRunner) {
        console.log('Down migration for CreateDrawingNumberColumnIfNotExists does nothing to prevent data loss');
    }
}
exports.CreateDrawingNumberColumnIfNotExists1716812000000 = CreateDrawingNumberColumnIfNotExists1716812000000;
//# sourceMappingURL=1716812000000-CreateDrawingNumberColumnIfNotExists.js.map