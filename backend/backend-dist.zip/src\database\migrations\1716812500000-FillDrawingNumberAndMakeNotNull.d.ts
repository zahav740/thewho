import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class FillDrawingNumberAndMakeNotNull1716812500000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
