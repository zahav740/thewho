"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FillDrawingNumberAndMakeNotNull1716812500000 = void 0;
class FillDrawingNumberAndMakeNotNull1716812500000 {
    async up(queryRunner) {
        await queryRunner.query(`
      UPDATE orders 
      SET "drawing_number" = 'TEMP-' || id::text 
      WHERE "drawing_number" IS NULL
    `);
        await queryRunner.query(`
      ALTER TABLE orders 
      ALTER COLUMN "drawing_number" SET NOT NULL
    `);
    }
    async down(queryRunner) {
        await queryRunner.query(`
      ALTER TABLE orders 
      ALTER COLUMN "drawing_number" DROP NOT NULL
    `);
    }
}
exports.FillDrawingNumberAndMakeNotNull1716812500000 = FillDrawingNumberAndMakeNotNull1716812500000;
//# sourceMappingURL=1716812500000-FillDrawingNumberAndMakeNotNull.js.map