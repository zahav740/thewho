import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class SeedInitialData1716813000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
