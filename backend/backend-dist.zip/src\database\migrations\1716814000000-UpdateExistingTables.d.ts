import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class UpdateExistingTables1716814000000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
    private tableExists;
    private columnExists;
}
