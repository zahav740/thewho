"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddMissingShiftRecordFields1735393200000 = void 0;
const typeorm_1 = require("typeorm");
class AddMissingShiftRecordFields1735393200000 {
    constructor() {
        this.name = 'AddMissingShiftRecordFields1735393200000';
    }
    async up(queryRunner) {
        const hasSetupStartDate = await queryRunner.hasColumn('shift_records', 'setupStartDate');
        if (!hasSetupStartDate) {
            await queryRunner.addColumn('shift_records', new typeorm_1.TableColumn({
                name: 'setupStartDate',
                type: 'date',
                isNullable: true,
            }));
        }
        const hasSetupOperator = await queryRunner.hasColumn('shift_records', 'setupOperator');
        if (!hasSetupOperator) {
            await queryRunner.addColumn('shift_records', new typeorm_1.TableColumn({
                name: 'setupOperator',
                type: 'varchar',
                isNullable: true,
            }));
        }
        const hasSetupType = await queryRunner.hasColumn('shift_records', 'setupType');
        if (!hasSetupType) {
            await queryRunner.addColumn('shift_records', new typeorm_1.TableColumn({
                name: 'setupType',
                type: 'varchar',
                isNullable: true,
            }));
        }
        const hasOperationId = await queryRunner.hasColumn('shift_records', 'operationId');
        if (!hasOperationId) {
            await queryRunner.addColumn('shift_records', new typeorm_1.TableColumn({
                name: 'operationId',
                type: 'int',
                isNullable: true,
            }));
        }
        const hasMachineId = await queryRunner.hasColumn('shift_records', 'machineId');
        if (!hasMachineId) {
            await queryRunner.addColumn('shift_records', new typeorm_1.TableColumn({
                name: 'machineId',
                type: 'int',
                isNullable: false,
            }));
        }
        console.log('✅ Миграция AddMissingShiftRecordFields завершена');
    }
    async down(queryRunner) {
        const columns = ['setupStartDate', 'setupOperator', 'setupType', 'operationId', 'machineId'];
        for (const columnName of columns) {
            const hasColumn = await queryRunner.hasColumn('shift_records', columnName);
            if (hasColumn) {
                await queryRunner.dropColumn('shift_records', columnName);
            }
        }
        console.log('✅ Откат миграции AddMissingShiftRecordFields завершен');
    }
}
exports.AddMissingShiftRecordFields1735393200000 = AddMissingShiftRecordFields1735393200000;
//# sourceMappingURL=1735393200000-AddMissingShiftRecordFields.js.map