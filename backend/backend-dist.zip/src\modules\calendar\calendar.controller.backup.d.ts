import { Repository } from 'typeorm';
import { Machine } from '../../database/entities/machine.entity';
import { Operation } from '../../database/entities/operation.entity';
import { Order } from '../../database/entities/order.entity';
export declare class CalendarController {
    private readonly machineRepository;
    private readonly operationRepository;
    private readonly orderRepository;
    constructor(machineRepository: Repository<Machine>, operationRepository: Repository<Operation>, orderRepository: Repository<Order>);
    test(): Promise<{
        status: string;
        message: string;
        timestamp: string;
    }>;
    debug(): Promise<{
        status: string;
        counts: {
            machines: number;
            operations: number;
            orders: number;
        };
        samples: {
            machine: Machine;
            operation: Operation;
            order: Order;
        };
        timestamp: string;
        error?: undefined;
        stack?: undefined;
    } | {
        status: string;
        error: any;
        stack: any;
        timestamp: string;
        counts?: undefined;
        samples?: undefined;
    }>;
    getCalendarView(startDate: string, endDate: string): Promise<{
        period: {
            startDate: string;
            endDate: string;
        };
        totalWorkingDays: number;
        machineSchedules: any[];
        timestamp: string;
        status?: undefined;
        error?: undefined;
        stack?: undefined;
    } | {
        status: string;
        error: any;
        stack: any;
        timestamp: string;
        period?: undefined;
        totalWorkingDays?: undefined;
        machineSchedules?: undefined;
    }>;
    private calculateWorkingDays;
    private generateDaysForMachine;
    private getCompletedShifts;
    private getPlannedOperation;
    private calculateOperationDuration;
    getUpcomingDeadlines(days?: number): Promise<{
        orderId: string;
        drawingNumber: string;
        deadline: Date;
        daysUntilDeadline: number;
        completedOperations: number;
        totalOperations: number;
        isAtRisk: boolean;
    }[]>;
    getMachineUtilization(startDate: string, endDate: string): Promise<{
        machineId: string;
        machineCode: string;
        totalCapacityMinutes: number;
        usedMinutes: number;
        utilizationPercent: number;
    }[]>;
}
