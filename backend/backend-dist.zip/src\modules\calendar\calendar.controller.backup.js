"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CalendarController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const machine_entity_1 = require("../../database/entities/machine.entity");
const operation_entity_1 = require("../../database/entities/operation.entity");
const order_entity_1 = require("../../database/entities/order.entity");
let CalendarController = class CalendarController {
    constructor(machineRepository, operationRepository, orderRepository) {
        this.machineRepository = machineRepository;
        this.operationRepository = operationRepository;
        this.orderRepository = orderRepository;
    }
    async test() {
        return {
            status: 'ok',
            message: 'Calendar controller is working',
            timestamp: new Date().toISOString(),
        };
    }
    async debug() {
        try {
            const machineCount = await this.machineRepository.count();
            const operationCount = await this.operationRepository.count();
            const orderCount = await this.orderRepository.count();
            const sampleMachine = await this.machineRepository.findOne({ where: {} });
            const sampleOperation = await this.operationRepository.findOne({ where: {} });
            const sampleOrder = await this.orderRepository.findOne({ where: {} });
            return {
                status: 'ok',
                counts: {
                    machines: machineCount,
                    operations: operationCount,
                    orders: orderCount,
                },
                samples: {
                    machine: sampleMachine,
                    operation: sampleOperation,
                    order: sampleOrder,
                },
                timestamp: new Date().toISOString(),
            };
        }
        catch (error) {
            return {
                status: 'error',
                error: error.message,
                stack: error.stack,
                timestamp: new Date().toISOString(),
            };
        }
    }
    async getCalendarView(startDate, endDate) {
        try {
            console.log('Calendar request:', { startDate, endDate });
            const machines = await this.machineRepository.find({
                where: { isActive: true },
                order: { code: 'ASC' },
            });
            console.log(`Found ${machines.length} machines`);
            const totalWorkingDays = this.calculateWorkingDays(startDate, endDate);
            const machineSchedules = [];
            for (const machine of machines) {
                const days = await this.generateDaysForMachine(machine.id, startDate, endDate);
                machineSchedules.push({
                    machineId: machine.id,
                    machineName: machine.code,
                    machineType: machine.type,
                    days: days
                });
            }
            return {
                period: { startDate, endDate },
                totalWorkingDays,
                machineSchedules,
                timestamp: new Date().toISOString(),
            };
        }
        catch (error) {
            console.error('Calendar error:', error);
            return {
                status: 'error',
                error: error.message,
                stack: error.stack,
                timestamp: new Date().toISOString(),
            };
        }
    }
    calculateWorkingDays(startDate, endDate) {
        const start = new Date(startDate);
        const end = new Date(endDate);
        let workingDays = 0;
        const current = new Date(start);
        while (current <= end) {
            const dayOfWeek = current.getDay();
            if (![5, 6].includes(dayOfWeek)) {
                workingDays++;
            }
            current.setDate(current.getDate() + 1);
        }
        return workingDays;
    }
    async generateDaysForMachine(machineId, startDate, endDate) {
        const days = [];
        const start = new Date(startDate);
        const end = new Date(endDate);
        const current = new Date(start);
        while (current <= end) {
            const dateStr = current.toISOString().split('T')[0];
            const dayOfWeek = current.getDay();
            const isWorkingDay = ![5, 6].includes(dayOfWeek);
            const isPast = current < new Date();
            const day = {
                date: dateStr,
                isWorkingDay,
                dayType: isWorkingDay ? 'WORKING' : 'WEEKEND'
            };
            if (isWorkingDay) {
                if (isPast) {
                    day.completedShifts = await this.getCompletedShifts(machineId, dateStr);
                }
                else {
                    day.plannedOperation = await this.getPlannedOperation(machineId, dateStr);
                }
            }
            days.push(day);
            current.setDate(current.getDate() + 1);
        }
        return days;
    }
    async getCompletedShifts(machineId, date) {
        try {
            const shifts = await this.machineRepository.query(`
        SELECT 
          sr."shiftType",
          sr."dayShiftOperator",
          sr."nightShiftOperator", 
          sr."dayShiftQuantity",
          sr."nightShiftQuantity",
          sr."dayShiftTimePerUnit",
          sr."nightShiftTimePerUnit",
          sr."setupTime",
          sr."drawingNumber" as drawing_number,
          COALESCE(o."operationNumber", 1) as operation_number
        FROM shift_records sr
        LEFT JOIN operations o ON sr."operationId" = o.id
        WHERE sr."machineId" = $1 AND sr.date = $2
      `, [machineId, date]);
            const completedShifts = [];
            for (const shift of shifts) {
                if (shift.dayShiftQuantity > 0) {
                    const totalTime = shift.dayShiftQuantity * shift.dayShiftTimePerUnit;
                    const planTime = 15;
                    const efficiency = shift.dayShiftTimePerUnit > 0
                        ? (planTime / shift.dayShiftTimePerUnit) * 100
                        : 0;
                    completedShifts.push({
                        shiftType: 'DAY',
                        operatorName: shift.dayShiftOperator || 'Не указан',
                        drawingNumber: shift.drawing_number || 'Не указан',
                        operationNumber: shift.operation_number || 1,
                        quantityProduced: shift.dayShiftQuantity,
                        timePerPart: shift.dayShiftTimePerUnit,
                        setupTime: shift.setupTime || 0,
                        totalTime: totalTime + (shift.setupTime || 0),
                        efficiency: Math.min(100, Math.max(0, efficiency))
                    });
                }
                if (shift.nightShiftQuantity > 0) {
                    const totalTime = shift.nightShiftQuantity * shift.nightShiftTimePerUnit;
                    const planTime = 15;
                    const efficiency = shift.nightShiftTimePerUnit > 0
                        ? (planTime / shift.nightShiftTimePerUnit) * 100
                        : 0;
                    completedShifts.push({
                        shiftType: 'NIGHT',
                        operatorName: shift.nightShiftOperator || 'Не указан',
                        drawingNumber: shift.drawing_number || 'Не указан',
                        operationNumber: shift.operation_number || 1,
                        quantityProduced: shift.nightShiftQuantity,
                        timePerPart: shift.nightShiftTimePerUnit,
                        totalTime: totalTime,
                        efficiency: Math.min(100, Math.max(0, efficiency))
                    });
                }
            }
            return completedShifts;
        }
        catch (error) {
            console.error(`Ошибка получения смен для станка ${machineId} на ${date}:`, error);
            return [];
        }
    }
    async getPlannedOperation(machineId, date) {
        try {
            const current = await this.machineRepository.query(`
        SELECT 
          o.id as operation_id,
          ord."drawingNumber" as drawing_number,
          o."operationNumber" as operation_number,
          o."estimatedTime" as time_per_part,
          ord.quantity as total_quantity,
          o.status,
          o."createdAt" as created_at,
          COALESCE(SUM(sr."dayShiftQuantity" + sr."nightShiftQuantity"), 0) as completed_quantity
        FROM operations o
        JOIN orders ord ON o."orderId" = ord.id
        LEFT JOIN shift_records sr ON sr."operationId" = o.id
        WHERE o."machineId" = $1 AND o.status IN ('PENDING', 'IN_PROGRESS')
        GROUP BY o.id, ord.id
        ORDER BY o."createdAt" ASC
        LIMIT 1
      `, [machineId]);
            if (current.length === 0)
                return undefined;
            const op = current[0];
            const estimatedDurationDays = this.calculateOperationDuration(op.time_per_part, op.total_quantity);
            const remainingQuantity = Math.max(0, op.total_quantity - op.completed_quantity);
            if (remainingQuantity === 0) {
                console.log(`Операция ${op.operation_id} завершена на станке ${machineId}`);
                return undefined;
            }
            return {
                operationId: op.operation_id,
                drawingNumber: op.drawing_number,
                operationNumber: op.operation_number,
                estimatedTimePerPart: op.time_per_part,
                totalQuantity: op.total_quantity,
                estimatedDurationDays,
                startDate: date,
                endDate: new Date(new Date(date).getTime() + estimatedDurationDays * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                currentProgress: {
                    completedQuantity: op.completed_quantity,
                    remainingQuantity: remainingQuantity,
                    progressPercent: (op.completed_quantity / op.total_quantity) * 100
                }
            };
        }
        catch (error) {
            console.error(`Ошибка получения операции для станка ${machineId}:`, error);
            return undefined;
        }
    }
    calculateOperationDuration(timePerPart, quantity) {
        const totalMinutes = timePerPart * quantity;
        const minutesPerWorkDay = 16 * 60;
        const baseDays = Math.ceil(totalMinutes / minutesPerWorkDay);
        return Math.max(1, baseDays);
    }
    async getUpcomingDeadlines(days = 7) {
        try {
            console.log('Upcoming deadlines request:', { days });
            const orders = await this.orderRepository.find({
                take: 5,
                relations: ['operations'],
            });
            console.log(`Found ${orders.length} orders`);
            const deadlines = orders.map(order => ({
                orderId: String(order.id),
                drawingNumber: order.drawingNumber,
                deadline: order.deadline,
                daysUntilDeadline: 5,
                completedOperations: 0,
                totalOperations: order.operations?.length || 0,
                isAtRisk: false,
            }));
            return deadlines;
        }
        catch (error) {
            console.error('Upcoming deadlines error:', error);
            return [];
        }
    }
    async getMachineUtilization(startDate, endDate) {
        try {
            console.log('Machine utilization request:', { startDate, endDate });
            const machines = await this.machineRepository.find({
                where: { isActive: true },
                take: 10,
            });
            console.log(`Found ${machines.length} machines`);
            const utilization = machines.map(machine => ({
                machineId: String(machine.id),
                machineCode: machine.code,
                totalCapacityMinutes: 9600,
                usedMinutes: Math.floor(Math.random() * 8000),
                utilizationPercent: Math.floor(Math.random() * 100),
            }));
            return utilization;
        }
        catch (error) {
            console.error('Machine utilization error:', error);
            return [];
        }
    }
};
exports.CalendarController = CalendarController;
__decorate([
    (0, common_1.Get)('test'),
    (0, swagger_1.ApiOperation)({ summary: 'Тестовый endpoint' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], CalendarController.prototype, "test", null);
__decorate([
    (0, common_1.Get)('debug'),
    (0, swagger_1.ApiOperation)({ summary: 'Отладочная информация' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], CalendarController.prototype, "debug", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Производственный календарь с данными из БД' }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], CalendarController.prototype, "getCalendarView", null);
__decorate([
    (0, common_1.Get)('upcoming-deadlines'),
    (0, swagger_1.ApiOperation)({ summary: 'Упрощенные дедлайны' }),
    __param(0, (0, common_1.Query)('days')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", Promise)
], CalendarController.prototype, "getUpcomingDeadlines", null);
__decorate([
    (0, common_1.Get)('machine-utilization'),
    (0, swagger_1.ApiOperation)({ summary: 'Упрощенная загруженность станков' }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], CalendarController.prototype, "getMachineUtilization", null);
exports.CalendarController = CalendarController = __decorate([
    (0, swagger_1.ApiTags)('calendar'),
    (0, common_1.Controller)('calendar'),
    __param(0, (0, typeorm_1.InjectRepository)(machine_entity_1.Machine)),
    __param(1, (0, typeorm_1.InjectRepository)(operation_entity_1.Operation)),
    __param(2, (0, typeorm_1.InjectRepository)(order_entity_1.Order)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], CalendarController);
//# sourceMappingURL=calendar.controller.backup.js.map