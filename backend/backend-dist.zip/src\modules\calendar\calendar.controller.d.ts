import { Repository } from 'typeorm';
import { Machine } from '../../database/entities/machine.entity';
import { Operation } from '../../database/entities/operation.entity';
import { Order } from '../../database/entities/order.entity';
interface CalendarDay {
    date: string;
    isWorkingDay: boolean;
    dayType: string;
    completedShifts?: any[];
    plannedOperation?: any;
}
interface MachineSchedule {
    machineId: number;
    machineName: string;
    machineType: string;
    currentOperation?: any;
    days: CalendarDay[];
}
export declare class CalendarController {
    private readonly machineRepository;
    private readonly operationRepository;
    private readonly orderRepository;
    constructor(machineRepository: Repository<Machine>, operationRepository: Repository<Operation>, orderRepository: Repository<Order>);
    getCalendarView(startDate: string, endDate: string): Promise<{
        success: boolean;
        period: {
            startDate: string;
            endDate: string;
        };
        totalWorkingDays: number;
        machineSchedules: MachineSchedule[];
        timestamp: string;
        error?: undefined;
    } | {
        success: boolean;
        error: any;
        period: {
            startDate: string;
            endDate: string;
        };
        totalWorkingDays: number;
        machineSchedules: any[];
        timestamp: string;
    }>;
    private calculateWorkingDays;
    private getCurrentOperation;
    private getOperationProgress;
    private generateDaysForMachine;
    private getCompletedShifts;
    private getPlannedOperationForDay;
    private calculateOperationDuration;
    getMachineSummary(startDate: string, endDate: string): Promise<{
        success: boolean;
        period: {
            startDate: string;
            endDate: string;
        };
        totalWorkingDays: number;
        summary: {
            totalMachines: number;
            activeMachines: number;
            averageUtilization: number;
        };
        machines: any[];
        error?: undefined;
    } | {
        success: boolean;
        error: any;
        machines: any[];
        period?: undefined;
        totalWorkingDays?: undefined;
        summary?: undefined;
    }>;
    getUpcomingDeadlines(days?: number): Promise<any[]>;
}
export {};
