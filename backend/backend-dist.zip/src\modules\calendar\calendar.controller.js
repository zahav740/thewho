"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CalendarController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const machine_entity_1 = require("../../database/entities/machine.entity");
const operation_entity_1 = require("../../database/entities/operation.entity");
const order_entity_1 = require("../../database/entities/order.entity");
let CalendarController = class CalendarController {
    constructor(machineRepository, operationRepository, orderRepository) {
        this.machineRepository = machineRepository;
        this.operationRepository = operationRepository;
        this.orderRepository = orderRepository;
    }
    async getCalendarView(startDate, endDate) {
        try {
            console.log('📅 Calendar request:', { startDate, endDate });
            if (!startDate || !endDate) {
                throw new Error('startDate и endDate обязательны');
            }
            const machines = await this.machineRepository.find({
                where: { isActive: true },
                order: { code: 'ASC' },
            });
            console.log(`🔧 Найдено ${machines.length} активных станков`);
            const totalWorkingDays = this.calculateWorkingDays(startDate, endDate);
            const machineSchedules = [];
            for (const machine of machines) {
                const currentOperation = await this.getCurrentOperation(machine.id);
                const days = await this.generateDaysForMachine(machine.id, startDate, endDate);
                machineSchedules.push({
                    machineId: machine.id,
                    machineName: machine.code,
                    machineType: machine.type,
                    currentOperation,
                    days: days
                });
            }
            console.log(`📊 Сгенерировано календарей для ${machineSchedules.length} станков`);
            return {
                success: true,
                period: { startDate, endDate },
                totalWorkingDays,
                machineSchedules,
                timestamp: new Date().toISOString(),
            };
        }
        catch (error) {
            console.error('❌ Calendar error:', error);
            return {
                success: false,
                error: error.message,
                period: { startDate, endDate },
                totalWorkingDays: 0,
                machineSchedules: [],
                timestamp: new Date().toISOString(),
            };
        }
    }
    calculateWorkingDays(startDate, endDate) {
        const start = new Date(startDate);
        const end = new Date(endDate);
        let workingDays = 0;
        const current = new Date(start);
        while (current <= end) {
            const dayOfWeek = current.getDay();
            if (![5, 6].includes(dayOfWeek)) {
                workingDays++;
            }
            current.setDate(current.getDate() + 1);
        }
        return workingDays;
    }
    async getCurrentOperation(machineId) {
        try {
            const operation = await this.operationRepository
                .createQueryBuilder('operation')
                .leftJoinAndSelect('operation.order', 'order')
                .where('operation.assignedMachine = :machineId', { machineId })
                .andWhere('operation.status IN (:...statuses)', { statuses: ['ASSIGNED', 'IN_PROGRESS'] })
                .orderBy('operation.assignedAt', 'ASC')
                .getOne();
            if (!operation)
                return null;
            const progress = await this.getOperationProgress(operation.id);
            return {
                operationId: operation.id,
                drawingNumber: operation.order?.drawingNumber || 'Не указан',
                operationNumber: operation.operationNumber,
                estimatedTime: operation.estimatedTime,
                totalQuantity: operation.order?.quantity || 0,
                status: operation.status,
                assignedAt: operation.assignedAt,
                ...progress
            };
        }
        catch (error) {
            console.error(`Ошибка получения операции для станка ${machineId}:`, error);
            return null;
        }
    }
    async getOperationProgress(operationId) {
        try {
            const result = await this.machineRepository.query(`
        SELECT 
          COALESCE(SUM(COALESCE("dayShiftQuantity", 0) + COALESCE("nightShiftQuantity", 0)), 0) as completed_quantity,
          COUNT(*) as shift_count
        FROM shift_records 
        WHERE "operationId" = $1 AND archived = false
      `, [operationId]);
            const completedQuantity = parseInt(result[0]?.completed_quantity || '0');
            const shiftCount = parseInt(result[0]?.shift_count || '0');
            return {
                completedQuantity,
                shiftCount,
                progressPercent: 0
            };
        }
        catch (error) {
            console.error(`Ошибка получения прогресса операции ${operationId}:`, error);
            return {
                completedQuantity: 0,
                shiftCount: 0,
                progressPercent: 0
            };
        }
    }
    async generateDaysForMachine(machineId, startDate, endDate) {
        const days = [];
        const start = new Date(startDate);
        const end = new Date(endDate);
        const current = new Date(start);
        while (current <= end) {
            const dateStr = current.toISOString().split('T')[0];
            const dayOfWeek = current.getDay();
            const isWorkingDay = ![5, 6].includes(dayOfWeek);
            const isPast = current < new Date();
            const day = {
                date: dateStr,
                isWorkingDay,
                dayType: isWorkingDay ? 'WORKING' : 'WEEKEND'
            };
            if (isWorkingDay) {
                const completedShifts = await this.getCompletedShifts(machineId, dateStr);
                if (completedShifts.length > 0) {
                    day.completedShifts = completedShifts;
                }
                if (!isPast || completedShifts.length === 0) {
                    const plannedOperation = await this.getPlannedOperationForDay(machineId, dateStr);
                    if (plannedOperation) {
                        day.plannedOperation = plannedOperation;
                    }
                }
            }
            days.push(day);
            current.setDate(current.getDate() + 1);
        }
        return days;
    }
    async getCompletedShifts(machineId, date) {
        try {
            const shifts = await this.machineRepository.query(`
        SELECT 
          sr."shiftType",
          sr."dayShiftOperator",
          sr."nightShiftOperator", 
          sr."dayShiftQuantity",
          sr."nightShiftQuantity",
          sr."dayShiftTimePerUnit",
          sr."nightShiftTimePerUnit",
          sr."setupTime",
          sr."drawingnumber" as drawing_number,
          o."operationNumber" as operation_number
        FROM shift_records sr
        LEFT JOIN operations o ON sr."operationId" = o.id
        WHERE sr."machineId" = $1 AND sr.date = $2 AND sr.archived = false
      `, [machineId, date]);
            const completedShifts = [];
            for (const shift of shifts) {
                if (shift.dayShiftQuantity > 0) {
                    const totalTime = shift.dayShiftQuantity * (shift.dayShiftTimePerUnit || 0);
                    const planTime = 15;
                    const efficiency = shift.dayShiftTimePerUnit > 0
                        ? Math.min(100, Math.max(0, (planTime / shift.dayShiftTimePerUnit) * 100))
                        : 0;
                    completedShifts.push({
                        shiftType: 'DAY',
                        operatorName: shift.dayShiftOperator || 'Не указан',
                        drawingNumber: shift.drawing_number || 'Не указан',
                        operationNumber: shift.operation_number || 1,
                        quantityProduced: shift.dayShiftQuantity,
                        timePerPart: shift.dayShiftTimePerUnit || 0,
                        setupTime: shift.setupTime || 0,
                        totalTime: totalTime + (shift.setupTime || 0),
                        efficiency: Math.round(efficiency * 10) / 10
                    });
                }
                if (shift.nightShiftQuantity > 0) {
                    const totalTime = shift.nightShiftQuantity * (shift.nightShiftTimePerUnit || 0);
                    const planTime = 15;
                    const efficiency = shift.nightShiftTimePerUnit > 0
                        ? Math.min(100, Math.max(0, (planTime / shift.nightShiftTimePerUnit) * 100))
                        : 0;
                    completedShifts.push({
                        shiftType: 'NIGHT',
                        operatorName: shift.nightShiftOperator || 'Не указан',
                        drawingNumber: shift.drawing_number || 'Не указан',
                        operationNumber: shift.operation_number || 1,
                        quantityProduced: shift.nightShiftQuantity,
                        timePerPart: shift.nightShiftTimePerUnit || 0,
                        totalTime: totalTime,
                        efficiency: Math.round(efficiency * 10) / 10
                    });
                }
            }
            return completedShifts;
        }
        catch (error) {
            console.error(`Ошибка получения смен для станка ${machineId} на ${date}:`, error);
            return [];
        }
    }
    async getPlannedOperationForDay(machineId, date) {
        try {
            const operation = await this.operationRepository
                .createQueryBuilder('operation')
                .leftJoinAndSelect('operation.order', 'order')
                .where('operation.assignedMachine = :machineId', { machineId })
                .andWhere('operation.status IN (:...statuses)', { statuses: ['ASSIGNED', 'IN_PROGRESS'] })
                .orderBy('operation.assignedAt', 'ASC')
                .getOne();
            if (!operation || !operation.order)
                return null;
            const progress = await this.getOperationProgress(operation.id);
            const totalQuantity = operation.order.quantity;
            const remainingQuantity = Math.max(0, totalQuantity - progress.completedQuantity);
            if (remainingQuantity === 0) {
                return null;
            }
            const estimatedDurationDays = this.calculateOperationDuration(operation.estimatedTime, remainingQuantity);
            return {
                operationId: operation.id,
                drawingNumber: operation.order.drawingNumber,
                operationNumber: operation.operationNumber,
                estimatedTimePerPart: operation.estimatedTime,
                totalQuantity: totalQuantity,
                estimatedDurationDays,
                startDate: date,
                endDate: new Date(new Date(date).getTime() + estimatedDurationDays * 24 * 60 * 60 * 1000)
                    .toISOString().split('T')[0],
                currentProgress: {
                    completedQuantity: progress.completedQuantity,
                    remainingQuantity: remainingQuantity,
                    progressPercent: totalQuantity > 0 ? Math.round((progress.completedQuantity / totalQuantity) * 100) : 0
                }
            };
        }
        catch (error) {
            console.error(`Ошибка получения операции для станка ${machineId}:`, error);
            return null;
        }
    }
    calculateOperationDuration(timePerPart, quantity) {
        const totalMinutes = timePerPart * quantity;
        const minutesPerWorkDay = 16 * 60;
        const baseDays = Math.ceil(totalMinutes / minutesPerWorkDay);
        return Math.max(1, baseDays);
    }
    async getMachineSummary(startDate, endDate) {
        try {
            const machines = await this.machineRepository.find({
                where: { isActive: true },
                order: { code: 'ASC' },
            });
            const summary = [];
            for (const machine of machines) {
                const currentOperation = await this.getCurrentOperation(machine.id);
                const workingDays = this.calculateWorkingDays(startDate, endDate);
                const shiftsCount = await this.machineRepository.query(`
          SELECT COUNT(DISTINCT date) as days_with_shifts
          FROM shift_records 
          WHERE "machineId" = $1 
            AND date BETWEEN $2 AND $3 
            AND archived = false
        `, [machine.id, startDate, endDate]);
                const daysWithOperations = parseInt(shiftsCount[0]?.days_with_shifts || '0');
                const utilizationPercent = workingDays > 0 ? Math.round((daysWithOperations / workingDays) * 100) : 0;
                summary.push({
                    machineId: machine.id,
                    machineName: machine.code,
                    machineType: machine.type,
                    isOccupied: machine.isOccupied,
                    currentOperation: currentOperation,
                    workingDays,
                    daysWithOperations,
                    utilizationPercent,
                    status: currentOperation ? 'busy' : utilizationPercent > 50 ? 'moderate' : 'available'
                });
            }
            return {
                success: true,
                period: { startDate, endDate },
                totalWorkingDays: this.calculateWorkingDays(startDate, endDate),
                summary: {
                    totalMachines: machines.length,
                    activeMachines: summary.filter(m => m.status === 'busy').length,
                    averageUtilization: Math.round(summary.reduce((acc, m) => acc + m.utilizationPercent, 0) / machines.length)
                },
                machines: summary
            };
        }
        catch (error) {
            console.error('Ошибка получения сводки по станкам:', error);
            return {
                success: false,
                error: error.message,
                machines: []
            };
        }
    }
    async getUpcomingDeadlines(days = 14) {
        try {
            const futureDate = new Date();
            futureDate.setDate(futureDate.getDate() + days);
            const orders = await this.orderRepository
                .createQueryBuilder('order')
                .leftJoinAndSelect('order.operations', 'operation')
                .where('order.deadline <= :futureDate', { futureDate })
                .andWhere('order.deadline >= :today', { today: new Date() })
                .orderBy('order.deadline', 'ASC')
                .take(20)
                .getMany();
            const deadlines = [];
            for (const order of orders) {
                const totalOperations = order.operations?.length || 0;
                const completedOperations = order.operations?.filter(op => op.status === 'COMPLETED').length || 0;
                const daysUntil = Math.ceil((new Date(order.deadline).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
                const isAtRisk = daysUntil <= 3 && completedOperations < totalOperations;
                deadlines.push({
                    orderId: order.id.toString(),
                    drawingNumber: order.drawingNumber,
                    deadline: order.deadline,
                    daysUntilDeadline: daysUntil,
                    completedOperations,
                    totalOperations,
                    isAtRisk,
                    priority: order.priority
                });
            }
            return deadlines;
        }
        catch (error) {
            console.error('Ошибка получения дедлайнов:', error);
            return [];
        }
    }
};
exports.CalendarController = CalendarController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Производственный календарь с реальными данными из БД' }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', description: 'Дата начала (YYYY-MM-DD)', example: '2025-06-16' }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', description: 'Дата окончания (YYYY-MM-DD)', example: '2025-06-30' }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], CalendarController.prototype, "getCalendarView", null);
__decorate([
    (0, common_1.Get)('machine-summary'),
    (0, swagger_1.ApiOperation)({ summary: 'Сводка по станкам' }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], CalendarController.prototype, "getMachineSummary", null);
__decorate([
    (0, common_1.Get)('upcoming-deadlines'),
    (0, swagger_1.ApiOperation)({ summary: 'Предстоящие дедлайны' }),
    __param(0, (0, common_1.Query)('days')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", Promise)
], CalendarController.prototype, "getUpcomingDeadlines", null);
exports.CalendarController = CalendarController = __decorate([
    (0, swagger_1.ApiTags)('calendar'),
    (0, common_1.Controller)('calendar'),
    __param(0, (0, typeorm_1.InjectRepository)(machine_entity_1.Machine)),
    __param(1, (0, typeorm_1.InjectRepository)(operation_entity_1.Operation)),
    __param(2, (0, typeorm_1.InjectRepository)(order_entity_1.Order)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], CalendarController);
//# sourceMappingURL=calendar.controller.js.map