export declare class CalendarModule {
}
