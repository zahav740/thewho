"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CalendarModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const operation_entity_1 = require("../../database/entities/operation.entity");
const machine_entity_1 = require("../../database/entities/machine.entity");
const order_entity_1 = require("../../database/entities/order.entity");
const shift_record_entity_1 = require("../../database/entities/shift-record.entity");
const calendar_controller_1 = require("./calendar.controller");
const calendar_service_1 = require("./calendar.service");
const working_days_service_1 = require("./working-days.service");
const enhanced_calendar_controller_1 = require("./enhanced-calendar.controller");
const enhanced_calendar_service_1 = require("./enhanced-calendar.service");
let CalendarModule = class CalendarModule {
};
exports.CalendarModule = CalendarModule;
exports.CalendarModule = CalendarModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([operation_entity_1.Operation, machine_entity_1.Machine, order_entity_1.Order, shift_record_entity_1.ShiftRecord])],
        controllers: [calendar_controller_1.CalendarController, enhanced_calendar_controller_1.EnhancedCalendarController],
        providers: [calendar_service_1.CalendarServiceFixed, working_days_service_1.WorkingDaysService, enhanced_calendar_service_1.EnhancedCalendarService],
        exports: [calendar_service_1.CalendarServiceFixed, working_days_service_1.WorkingDaysService, enhanced_calendar_service_1.EnhancedCalendarService],
    })
], CalendarModule);
//# sourceMappingURL=calendar.module.js.map