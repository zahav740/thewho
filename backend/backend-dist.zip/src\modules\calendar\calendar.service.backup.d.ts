import { Repository } from 'typeorm';
import { Operation } from '../../database/entities/operation.entity';
import { Order } from '../../database/entities/order.entity';
import { MachineScheduleDto } from './dto/machine-schedule.dto';
import { ScheduleOperationDto } from './dto/schedule-operation.dto';
interface CalendarViewItem {
    date: string;
    machine: string;
    operation: {
        id: string;
        drawingNumber: string;
        operationNumber: number;
        estimatedTime: number;
        status: string;
    };
}
interface MachineUtilization {
    machine: string;
    totalHours: number;
    utilization: number;
}
interface UpcomingDeadline {
    orderId: string;
    drawingNumber: string;
    deadline: Date;
    daysRemaining: number;
    priority: number;
}
export declare class CalendarService {
    private readonly operationRepository;
    private readonly orderRepository;
    constructor(operationRepository: Repository<Operation>, orderRepository: Repository<Order>);
    getMachineSchedule(machineId: string, date: string): Promise<MachineScheduleDto>;
    scheduleOperation(scheduleDto: ScheduleOperationDto): Promise<Operation>;
    getCalendarView(startDate: string, endDate: string): Promise<CalendarViewItem[]>;
    getMachineUtilization(startDate: string, endDate: string): Promise<MachineUtilization[]>;
    getUpcomingDeadlines(days?: number): Promise<UpcomingDeadline[]>;
}
export {};
