"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CalendarService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const operation_entity_1 = require("../../database/entities/operation.entity");
const order_entity_1 = require("../../database/entities/order.entity");
let CalendarService = class CalendarService {
    constructor(operationRepository, orderRepository) {
        this.operationRepository = operationRepository;
        this.orderRepository = orderRepository;
    }
    async getMachineSchedule(machineId, date) {
        try {
            const operations = await this.operationRepository.find({
                where: {
                    status: 'in_progress',
                    machineAxes: parseInt(machineId) || 3,
                },
                relations: ['order'],
            });
            const schedule = {
                machineId: machineId,
                date: date,
                daySchedule: [{
                        date: date,
                        shifts: [],
                        currentOperation: operations.length > 0 ? {
                            operationId: operations[0].id.toString(),
                            orderDrawingNumber: operations[0].order?.drawingNumber || 'N/A',
                            operationNumber: operations[0].operationNumber,
                            estimatedTime: operations[0].estimatedTime,
                        } : undefined,
                    }],
            };
            return schedule;
        }
        catch (error) {
            console.error('CalendarService.getMachineSchedule Ошибка:', error);
            throw error;
        }
    }
    async scheduleOperation(scheduleDto) {
        const operation = await this.operationRepository.findOne({
            where: { id: parseInt(scheduleDto.operationId) },
            relations: ['order'],
        });
        if (!operation) {
            throw new common_1.NotFoundException(`Операция с ID ${scheduleDto.operationId} не найдена`);
        }
        operation.status = 'in_progress';
        return this.operationRepository.save(operation);
    }
    async getCalendarView(startDate, endDate) {
        try {
            const start = new Date(startDate);
            const end = new Date(endDate);
            const operations = await this.operationRepository.find({
                where: {
                    createdAt: (0, typeorm_2.Between)(start, end),
                    status: 'in_progress'
                },
                relations: ['order'],
                order: { createdAt: 'ASC' }
            });
            return operations.map(op => ({
                date: op.createdAt.toISOString().split('T')[0],
                machine: op.machineAxes ? `${op.machineAxes}-axis` : 'N/A',
                operation: {
                    id: op.id.toString(),
                    drawingNumber: op.order?.drawingNumber || 'N/A',
                    operationNumber: op.operationNumber,
                    estimatedTime: op.estimatedTime,
                    status: op.status
                }
            }));
        }
        catch (error) {
            console.error('CalendarService.getCalendarView Ошибка:', error);
            return [];
        }
    }
    async getMachineUtilization(startDate, endDate) {
        try {
            const start = new Date(startDate);
            const end = new Date(endDate);
            const totalDays = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
            const workingHoursPerDay = 8;
            const totalPossibleHours = totalDays * workingHoursPerDay;
            const operations = await this.operationRepository
                .createQueryBuilder('operation')
                .select('operation.machineAxes', 'machine')
                .addSelect('SUM(operation.estimatedTime)', 'totalMinutes')
                .where('operation.createdAt BETWEEN :start AND :end', { start, end })
                .andWhere('operation.machineAxes IS NOT NULL')
                .groupBy('operation.machineAxes')
                .getRawMany();
            return operations.map(op => ({
                machine: `${op.machine}-axis`,
                totalHours: Math.round(op.totalMinutes / 60 * 100) / 100,
                utilization: Math.round((op.totalMinutes / 60 / totalPossibleHours) * 100)
            }));
        }
        catch (error) {
            console.error('CalendarService.getMachineUtilization Ошибка:', error);
            return [];
        }
    }
    async getUpcomingDeadlines(days = 7) {
        try {
            const today = new Date();
            const futureDate = new Date(today.getTime() + days * 24 * 60 * 60 * 1000);
            const orders = await this.orderRepository.find({
                where: {
                    deadline: (0, typeorm_2.Between)(today, futureDate)
                },
                order: { deadline: 'ASC' }
            });
            return orders.map(order => {
                const daysRemaining = Math.ceil((order.deadline.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
                return {
                    orderId: order.id.toString(),
                    drawingNumber: order.drawingNumber || 'N/A',
                    deadline: order.deadline,
                    daysRemaining,
                    priority: order.priority
                };
            });
        }
        catch (error) {
            console.error('CalendarService.getUpcomingDeadlines Ошибка:', error);
            return [];
        }
    }
};
exports.CalendarService = CalendarService;
exports.CalendarService = CalendarService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(operation_entity_1.Operation)),
    __param(1, (0, typeorm_1.InjectRepository)(order_entity_1.Order)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository])
], CalendarService);
//# sourceMappingURL=calendar.service.backup.js.map