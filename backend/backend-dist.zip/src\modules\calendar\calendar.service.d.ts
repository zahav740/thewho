import { Repository } from 'typeorm';
import { Operation } from '../../database/entities/operation.entity';
import { Order } from '../../database/entities/order.entity';
import { Machine } from '../../database/entities/machine.entity';
import { ShiftRecord } from '../../database/entities/shift-record.entity';
interface CalendarDay {
    date: string;
    isWorkingDay: boolean;
    dayType: 'WORKING' | 'WEEKEND' | 'HOLIDAY';
    plannedOperation?: PlannedOperation;
    completedShifts?: CompletedShift[];
    machineStatus: 'FREE' | 'BUSY' | 'SETUP';
}
interface PlannedOperation {
    operationId: number;
    drawingNumber: string;
    operationNumber: number;
    estimatedTimePerPart: number;
    totalQuantity: number;
    estimatedDurationDays: number;
    startDate: string;
    endDate: string;
    currentProgress?: {
        completedQuantity: number;
        remainingQuantity: number;
        progressPercent: number;
    };
}
interface CompletedShift {
    shiftType: 'DAY' | 'NIGHT';
    operatorName: string;
    drawingNumber: string;
    operationNumber: number;
    quantityProduced: number;
    timePerPart: number;
    setupTime?: number;
    totalTime: number;
    efficiency: number;
}
interface MachineSchedule {
    machineId: number;
    machineName: string;
    machineType: string;
    days: CalendarDay[];
}
interface EnhancedCalendarData {
    period: {
        startDate: string;
        endDate: string;
    };
    totalWorkingDays: number;
    machineSchedules: MachineSchedule[];
}
export declare class CalendarServiceFixed {
    private readonly operationRepository;
    private readonly orderRepository;
    private readonly machineRepository;
    private readonly shiftRecordRepository;
    constructor(operationRepository: Repository<Operation>, orderRepository: Repository<Order>, machineRepository: Repository<Machine>, shiftRecordRepository: Repository<ShiftRecord>);
    getEnhancedCalendarView(startDate: string, endDate: string): Promise<EnhancedCalendarData>;
    private getMachineDays;
    private formatCompletedShifts;
    private calculateMachineStatus;
    private calculateTotalProduced;
    private findPlannedOperation;
    private calculateEfficiency;
    private isWorkingDay;
    private calculateWorkingDays;
    private addDays;
}
export {};
