"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CalendarServiceFixed = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const operation_entity_1 = require("../../database/entities/operation.entity");
const order_entity_1 = require("../../database/entities/order.entity");
const machine_entity_1 = require("../../database/entities/machine.entity");
const shift_record_entity_1 = require("../../database/entities/shift-record.entity");
let CalendarServiceFixed = class CalendarServiceFixed {
    constructor(operationRepository, orderRepository, machineRepository, shiftRecordRepository) {
        this.operationRepository = operationRepository;
        this.orderRepository = orderRepository;
        this.machineRepository = machineRepository;
        this.shiftRecordRepository = shiftRecordRepository;
    }
    async getEnhancedCalendarView(startDate, endDate) {
        try {
            console.log(`Получение календаря за период: ${startDate} - ${endDate}`);
            const machines = await this.machineRepository.find({
                where: { isActive: true }
            });
            if (!machines || machines.length === 0) {
                console.warn('Не найдено активных станков');
                return {
                    period: { startDate, endDate },
                    totalWorkingDays: this.calculateWorkingDays(startDate, endDate),
                    machineSchedules: []
                };
            }
            const machineSchedules = await Promise.all(machines.map(async (machine) => {
                const days = await this.getMachineDays(machine, startDate, endDate);
                return {
                    machineId: machine.id,
                    machineName: machine.code,
                    machineType: machine.type,
                    days
                };
            }));
            const totalWorkingDays = this.calculateWorkingDays(startDate, endDate);
            return {
                period: { startDate, endDate },
                totalWorkingDays,
                machineSchedules
            };
        }
        catch (error) {
            console.error('Ошибка получения календаря:', error);
            throw error;
        }
    }
    async getMachineDays(machine, startDate, endDate) {
        const start = new Date(startDate);
        const end = new Date(endDate);
        const days = [];
        const operations = await this.operationRepository.find({
            where: {
                assignedMachine: machine.id,
            },
            relations: ['order']
        });
        const shiftRecords = await this.shiftRecordRepository.find({
            where: {
                machineId: machine.id,
                date: (0, typeorm_2.Between)(start, end)
            },
            relations: ['operation', 'operation.order']
        });
        const current = new Date(start);
        while (current <= end) {
            const dateStr = current.toISOString().split('T')[0];
            const dayDate = new Date(current);
            const calendarDay = {
                date: dateStr,
                isWorkingDay: this.isWorkingDay(dayDate),
                dayType: this.isWorkingDay(dayDate) ? 'WORKING' : 'WEEKEND',
                machineStatus: 'FREE'
            };
            const dayShifts = shiftRecords.filter(shift => shift.date.toISOString().split('T')[0] === dateStr);
            if (dayShifts.length > 0) {
                calendarDay.completedShifts = this.formatCompletedShifts(dayShifts);
                calendarDay.machineStatus = this.calculateMachineStatus(dayShifts, operations);
            }
            else {
                const plannedOp = this.findPlannedOperation(operations, dateStr);
                if (plannedOp) {
                    calendarDay.plannedOperation = plannedOp;
                    calendarDay.machineStatus = 'BUSY';
                }
            }
            days.push(calendarDay);
            current.setDate(current.getDate() + 1);
        }
        return days;
    }
    formatCompletedShifts(dayShifts) {
        return dayShifts.map(shift => {
            const dayQuantity = shift.dayShiftQuantity || 0;
            const nightQuantity = shift.nightShiftQuantity || 0;
            const dayTime = shift.dayShiftTimePerUnit || 0;
            const nightTime = shift.nightShiftTimePerUnit || 0;
            const shifts = [];
            if (dayQuantity > 0) {
                shifts.push({
                    shiftType: 'DAY',
                    operatorName: shift.dayShiftOperator || 'Не указан',
                    drawingNumber: shift.operation?.order?.drawingNumber || 'N/A',
                    operationNumber: shift.operation?.operationNumber || 0,
                    quantityProduced: dayQuantity,
                    timePerPart: dayTime,
                    setupTime: shift.setupTime || undefined,
                    totalTime: dayQuantity * dayTime + (shift.setupTime || 0),
                    efficiency: this.calculateEfficiency(dayTime, shift.operation?.estimatedTime || dayTime)
                });
            }
            if (nightQuantity > 0) {
                shifts.push({
                    shiftType: 'NIGHT',
                    operatorName: shift.nightShiftOperator || 'Не указан',
                    drawingNumber: shift.operation?.order?.drawingNumber || 'N/A',
                    operationNumber: shift.operation?.operationNumber || 0,
                    quantityProduced: nightQuantity,
                    timePerPart: nightTime,
                    totalTime: nightQuantity * nightTime,
                    efficiency: this.calculateEfficiency(nightTime, shift.operation?.estimatedTime || nightTime)
                });
            }
            return shifts;
        }).flat();
    }
    calculateMachineStatus(dayShifts, operations) {
        const activeOperations = operations.filter(op => op.status === 'IN_PROGRESS' || op.status === 'PENDING');
        if (activeOperations.length === 0) {
            return 'FREE';
        }
        for (const operation of activeOperations) {
            if (!operation.order)
                continue;
            const totalProduced = this.calculateTotalProduced(operation, dayShifts);
            const requiredQuantity = operation.order.quantity;
            if (totalProduced >= requiredQuantity) {
                continue;
            }
            else {
                return 'BUSY';
            }
        }
        return 'FREE';
    }
    calculateTotalProduced(operation, allShifts) {
        const operationShifts = allShifts.filter(shift => shift.operationId === operation.id);
        return operationShifts.reduce((total, shift) => {
            return total + (shift.dayShiftQuantity || 0) + (shift.nightShiftQuantity || 0);
        }, 0);
    }
    findPlannedOperation(operations, dateStr) {
        const activeOp = operations.find(op => op.status === 'PENDING' || op.status === 'IN_PROGRESS');
        if (!activeOp?.order)
            return undefined;
        return {
            operationId: activeOp.id,
            drawingNumber: activeOp.order.drawingNumber,
            operationNumber: activeOp.operationNumber,
            estimatedTimePerPart: activeOp.estimatedTime,
            totalQuantity: activeOp.order.quantity,
            estimatedDurationDays: Math.ceil(activeOp.estimatedTime * activeOp.order.quantity / (8 * 60)),
            startDate: dateStr,
            endDate: this.addDays(dateStr, 3),
        };
    }
    calculateEfficiency(actualTime, estimatedTime) {
        if (actualTime === 0 || estimatedTime === 0)
            return 100;
        return Math.round((estimatedTime / actualTime) * 100);
    }
    isWorkingDay(date) {
        const dayOfWeek = date.getDay();
        return ![5, 6].includes(dayOfWeek);
    }
    calculateWorkingDays(startDate, endDate) {
        const start = new Date(startDate);
        const end = new Date(endDate);
        let workingDays = 0;
        const current = new Date(start);
        while (current <= end) {
            if (this.isWorkingDay(current)) {
                workingDays++;
            }
            current.setDate(current.getDate() + 1);
        }
        return workingDays;
    }
    addDays(dateStr, days) {
        const date = new Date(dateStr);
        date.setDate(date.getDate() + days);
        return date.toISOString().split('T')[0];
    }
};
exports.CalendarServiceFixed = CalendarServiceFixed;
exports.CalendarServiceFixed = CalendarServiceFixed = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(operation_entity_1.Operation)),
    __param(1, (0, typeorm_1.InjectRepository)(order_entity_1.Order)),
    __param(2, (0, typeorm_1.InjectRepository)(machine_entity_1.Machine)),
    __param(3, (0, typeorm_1.InjectRepository)(shift_record_entity_1.ShiftRecord)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], CalendarServiceFixed);
//# sourceMappingURL=calendar.service.js.map