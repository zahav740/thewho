export declare class CalendarFilterDto {
    startDate: string;
    endDate: string;
}
