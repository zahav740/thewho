import { MachineScheduleDto } from './machine-schedule.dto';
export declare class CalendarViewDto {
    startDate: Date;
    endDate: Date;
    totalWorkingDays: number;
    machineSchedules: MachineScheduleDto[];
}
