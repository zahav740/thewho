import { ShiftType } from '../../../database/entities/shift-record.entity';
export declare class ShiftInfoDto {
    shiftType: ShiftType;
    operationId: string;
    orderDrawingNumber: string;
    quantity: number;
    operator: string;
}
export declare class CurrentOperationDto {
    operationId: string;
    orderDrawingNumber: string;
    operationNumber: number;
    estimatedTime: number;
}
export declare class DayScheduleDto {
    date: string;
    shifts: ShiftInfoDto[];
    currentOperation?: CurrentOperationDto;
}
export declare class MachineScheduleDto {
    machineId: string;
    date: string;
    daySchedule: DayScheduleDto[];
}
