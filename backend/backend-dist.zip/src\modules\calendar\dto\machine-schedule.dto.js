"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MachineScheduleDto = exports.DayScheduleDto = exports.CurrentOperationDto = exports.ShiftInfoDto = void 0;
const swagger_1 = require("@nestjs/swagger");
const shift_record_entity_1 = require("../../../database/entities/shift-record.entity");
class ShiftInfoDto {
}
exports.ShiftInfoDto = ShiftInfoDto;
__decorate([
    (0, swagger_1.ApiProperty)({ enum: shift_record_entity_1.ShiftType }),
    __metadata("design:type", String)
], ShiftInfoDto.prototype, "shiftType", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], ShiftInfoDto.prototype, "operationId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], ShiftInfoDto.prototype, "orderDrawingNumber", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], ShiftInfoDto.prototype, "quantity", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], ShiftInfoDto.prototype, "operator", void 0);
class CurrentOperationDto {
}
exports.CurrentOperationDto = CurrentOperationDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], CurrentOperationDto.prototype, "operationId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], CurrentOperationDto.prototype, "orderDrawingNumber", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], CurrentOperationDto.prototype, "operationNumber", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], CurrentOperationDto.prototype, "estimatedTime", void 0);
class DayScheduleDto {
}
exports.DayScheduleDto = DayScheduleDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], DayScheduleDto.prototype, "date", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Array)
], DayScheduleDto.prototype, "shifts", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ type: CurrentOperationDto, required: false }),
    __metadata("design:type", CurrentOperationDto)
], DayScheduleDto.prototype, "currentOperation", void 0);
class MachineScheduleDto {
}
exports.MachineScheduleDto = MachineScheduleDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], MachineScheduleDto.prototype, "machineId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], MachineScheduleDto.prototype, "date", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ type: [DayScheduleDto] }),
    __metadata("design:type", Array)
], MachineScheduleDto.prototype, "daySchedule", void 0);
//# sourceMappingURL=machine-schedule.dto.js.map