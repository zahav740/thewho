export declare class ScheduleOperationDto {
    operationId: string;
    machineId: string;
    startDate?: string;
}
