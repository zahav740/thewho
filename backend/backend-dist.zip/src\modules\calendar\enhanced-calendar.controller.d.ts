import { EnhancedCalendarService, EnhancedCalendarData } from './enhanced-calendar.service';
export declare class EnhancedCalendarController {
    private readonly enhancedCalendarService;
    private readonly logger;
    constructor(enhancedCalendarService: EnhancedCalendarService);
    getEnhancedCalendarView(startDate: string, endDate: string): Promise<{
        success: boolean;
        data: EnhancedCalendarData;
        message: string;
    }>;
    calculateWorkingDays(startDate: string, endDate: string): Promise<{
        success: boolean;
        data: {
            startDate: string;
            endDate: string;
            totalDays: number;
            workingDays: number;
            weekendDays: number;
            workingDaysPercent: number;
        };
        message: string;
    }>;
    calculateOperationDuration(timePerPart: number, quantity: number, setupTime?: number): Promise<{
        success: boolean;
        data: {
            input: {
                timePerPart: number;
                quantity: number;
                setupTime: number;
            };
            calculation: {
                productionTimeMinutes: number;
                totalTimeMinutes: number;
                estimatedDays: number;
                setupDays: number;
                efficiency: number;
            };
            breakdown: {
                hoursPerDay: number;
                minutesPerDay: number;
                totalHours: number;
                productionHours: number;
                setupHours: number;
            };
        };
        message: string;
    }>;
    getMachineSummary(startDate: string, endDate: string): Promise<{
        success: boolean;
        data: {
            period: {
                startDate: string;
                endDate: string;
            };
            totalWorkingDays: number;
            summary: {
                totalMachines: number;
                activeMachines: number;
                averageUtilization: number;
            };
            machines: {
                machineId: number;
                machineName: string;
                machineType: string;
                workingDays: number;
                daysWithOperations: number;
                daysWithShifts: number;
                utilizationPercent: number;
                totalProduced: number;
                status: string;
            }[];
        };
        message: string;
    }>;
}
