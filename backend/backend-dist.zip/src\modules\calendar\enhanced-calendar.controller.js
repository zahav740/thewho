"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var EnhancedCalendarController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnhancedCalendarController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const enhanced_calendar_service_1 = require("./enhanced-calendar.service");
const dayjs = require("dayjs");
let EnhancedCalendarController = EnhancedCalendarController_1 = class EnhancedCalendarController {
    constructor(enhancedCalendarService) {
        this.enhancedCalendarService = enhancedCalendarService;
        this.logger = new common_1.Logger(EnhancedCalendarController_1.name);
    }
    async getEnhancedCalendarView(startDate, endDate) {
        try {
            this.logger.log(`Запрос улучшенного календаря: ${startDate} - ${endDate}`);
            if (!startDate || !endDate) {
                throw new common_1.BadRequestException('Параметры startDate и endDate обязательны');
            }
            if (!dayjs(startDate, 'YYYY-MM-DD', true).isValid()) {
                throw new common_1.BadRequestException('Неверный формат startDate. Используйте YYYY-MM-DD');
            }
            if (!dayjs(endDate, 'YYYY-MM-DD', true).isValid()) {
                throw new common_1.BadRequestException('Неверный формат endDate. Используйте YYYY-MM-DD');
            }
            const start = dayjs(startDate);
            const end = dayjs(endDate);
            if (end.isBefore(start)) {
                throw new common_1.BadRequestException('endDate не может быть раньше startDate');
            }
            if (end.diff(start, 'day') > 90) {
                throw new common_1.BadRequestException('Максимальный период: 90 дней');
            }
            const calendarData = await this.enhancedCalendarService.getEnhancedCalendarView(startDate, endDate);
            this.logger.log(`Календарь загружен: ${calendarData.machineSchedules.length} станков, ${calendarData.totalWorkingDays} рабочих дней`);
            return {
                success: true,
                data: calendarData,
                message: `Календарь за период ${startDate} - ${endDate} успешно загружен`
            };
        }
        catch (error) {
            this.logger.error('Ошибка при получении улучшенного календаря:', error);
            if (error instanceof common_1.BadRequestException) {
                throw error;
            }
            throw new common_1.BadRequestException(`Ошибка загрузки календаря: ${error.message}`);
        }
    }
    async calculateWorkingDays(startDate, endDate) {
        try {
            if (!startDate || !endDate) {
                throw new common_1.BadRequestException('Параметры startDate и endDate обязательны');
            }
            const start = dayjs(startDate);
            const end = dayjs(endDate);
            let workingDays = 0;
            let weekendDays = 0;
            let totalDays = 0;
            let current = start;
            while (current.isBefore(end) || current.isSame(end, 'day')) {
                totalDays++;
                const dayOfWeek = current.day();
                if (![5, 6].includes(dayOfWeek)) {
                    workingDays++;
                }
                else {
                    weekendDays++;
                }
                current = current.add(1, 'day');
            }
            return {
                success: true,
                data: {
                    startDate,
                    endDate,
                    totalDays,
                    workingDays,
                    weekendDays,
                    workingDaysPercent: Math.round((workingDays / totalDays) * 100)
                },
                message: `Расчет выполнен для периода ${startDate} - ${endDate}`
            };
        }
        catch (error) {
            this.logger.error('Ошибка расчета рабочих дней:', error);
            throw new common_1.BadRequestException(`Ошибка расчета: ${error.message}`);
        }
    }
    async calculateOperationDuration(timePerPart, quantity, setupTime) {
        try {
            if (!timePerPart || !quantity) {
                throw new common_1.BadRequestException('Параметры timePerPart и quantity обязательны');
            }
            if (timePerPart <= 0 || quantity <= 0) {
                throw new common_1.BadRequestException('timePerPart и quantity должны быть больше 0');
            }
            const productionTime = timePerPart * quantity;
            const totalTime = productionTime + (setupTime || 0);
            const minutesPerWorkDay = 16 * 60;
            const baseDays = Math.ceil(totalTime / minutesPerWorkDay);
            const setupDays = (setupTime || 0) > 0 ? 1 : 0;
            const totalDays = Math.max(1, baseDays);
            const theoreticalDays = productionTime / minutesPerWorkDay;
            const efficiency = theoreticalDays > 0 ? (theoreticalDays / totalDays) * 100 : 0;
            return {
                success: true,
                data: {
                    input: {
                        timePerPart,
                        quantity,
                        setupTime: setupTime || 0
                    },
                    calculation: {
                        productionTimeMinutes: productionTime,
                        totalTimeMinutes: totalTime,
                        estimatedDays: totalDays,
                        setupDays,
                        efficiency: Math.round(efficiency * 10) / 10
                    },
                    breakdown: {
                        hoursPerDay: 16,
                        minutesPerDay: minutesPerWorkDay,
                        totalHours: Math.round(totalTime / 60 * 10) / 10,
                        productionHours: Math.round(productionTime / 60 * 10) / 10,
                        setupHours: setupTime ? Math.round(setupTime / 60 * 10) / 10 : 0
                    }
                },
                message: `Операция займет ${totalDays} рабочих дня(ей)`
            };
        }
        catch (error) {
            this.logger.error('Ошибка расчета продолжительности операции:', error);
            throw new common_1.BadRequestException(`Ошибка расчета: ${error.message}`);
        }
    }
    async getMachineSummary(startDate, endDate) {
        try {
            this.logger.log(`Запрос сводки по станкам: ${startDate} - ${endDate}`);
            const calendarData = await this.enhancedCalendarService.getEnhancedCalendarView(startDate, endDate);
            const machineSummary = calendarData.machineSchedules.map(machine => {
                const workingDays = machine.days.filter(day => day.isWorkingDay).length;
                const daysWithShifts = machine.days.filter(day => day.completedShifts && day.completedShifts.length > 0).length;
                const daysWithOperations = machine.days.filter(day => day.plannedOperation || (day.completedShifts && day.completedShifts.length > 0)).length;
                const totalProduced = machine.days.reduce((sum, day) => {
                    if (day.completedShifts) {
                        return sum + day.completedShifts.reduce((daySum, shift) => daySum + shift.quantityProduced, 0);
                    }
                    return sum;
                }, 0);
                const utilization = workingDays > 0 ? (daysWithOperations / workingDays) * 100 : 0;
                return {
                    machineId: machine.machineId,
                    machineName: machine.machineName,
                    machineType: machine.machineType,
                    workingDays,
                    daysWithOperations,
                    daysWithShifts,
                    utilizationPercent: Math.round(utilization * 10) / 10,
                    totalProduced,
                    status: utilization > 80 ? 'busy' : utilization > 50 ? 'moderate' : 'available'
                };
            });
            const totalMachines = machineSummary.length;
            const activeMachines = machineSummary.filter(m => m.daysWithOperations > 0).length;
            const averageUtilization = totalMachines > 0
                ? machineSummary.reduce((sum, m) => sum + m.utilizationPercent, 0) / totalMachines
                : 0;
            return {
                success: true,
                data: {
                    period: calendarData.period,
                    totalWorkingDays: calendarData.totalWorkingDays,
                    summary: {
                        totalMachines,
                        activeMachines,
                        averageUtilization: Math.round(averageUtilization * 10) / 10
                    },
                    machines: machineSummary
                },
                message: `Сводка по ${totalMachines} станкам за период ${startDate} - ${endDate}`
            };
        }
        catch (error) {
            this.logger.error('Ошибка получения сводки по станкам:', error);
            throw new common_1.BadRequestException(`Ошибка получения сводки: ${error.message}`);
        }
    }
};
exports.EnhancedCalendarController = EnhancedCalendarController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({
        summary: 'Получить улучшенное представление производственного календаря',
        description: 'Возвращает детализированный календарь с информацией о сменах, операциях и рабочих днях'
    }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: true, description: 'Дата начала (YYYY-MM-DD)' }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: true, description: 'Дата окончания (YYYY-MM-DD)' }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], EnhancedCalendarController.prototype, "getEnhancedCalendarView", null);
__decorate([
    (0, common_1.Get)('working-days'),
    (0, swagger_1.ApiOperation)({
        summary: 'Рассчитать количество рабочих дней',
        description: 'Возвращает количество рабочих дней между датами (исключая пятницу и субботу)'
    }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: true, description: 'Дата начала (YYYY-MM-DD)' }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: true, description: 'Дата окончания (YYYY-MM-DD)' }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], EnhancedCalendarController.prototype, "calculateWorkingDays", null);
__decorate([
    (0, common_1.Get)('operation-duration'),
    (0, swagger_1.ApiOperation)({
        summary: 'Рассчитать продолжительность операции',
        description: 'Возвращает расчетную продолжительность операции в рабочих днях'
    }),
    (0, swagger_1.ApiQuery)({ name: 'timePerPart', required: true, description: 'Время на одну деталь (минуты)' }),
    (0, swagger_1.ApiQuery)({ name: 'quantity', required: true, description: 'Количество деталей' }),
    (0, swagger_1.ApiQuery)({ name: 'setupTime', required: false, description: 'Время наладки (минуты)', example: 120 }),
    __param(0, (0, common_1.Query)('timePerPart')),
    __param(1, (0, common_1.Query)('quantity')),
    __param(2, (0, common_1.Query)('setupTime')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Number, Number]),
    __metadata("design:returntype", Promise)
], EnhancedCalendarController.prototype, "calculateOperationDuration", null);
__decorate([
    (0, common_1.Get)('machine-summary'),
    (0, swagger_1.ApiOperation)({
        summary: 'Сводка по станкам за период',
        description: 'Возвращает сводную информацию о загруженности станков'
    }),
    (0, swagger_1.ApiQuery)({ name: 'startDate', required: true, description: 'Дата начала (YYYY-MM-DD)' }),
    (0, swagger_1.ApiQuery)({ name: 'endDate', required: true, description: 'Дата окончания (YYYY-MM-DD)' }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], EnhancedCalendarController.prototype, "getMachineSummary", null);
exports.EnhancedCalendarController = EnhancedCalendarController = EnhancedCalendarController_1 = __decorate([
    (0, swagger_1.ApiTags)('enhanced-calendar'),
    (0, common_1.Controller)('enhanced-calendar'),
    __metadata("design:paramtypes", [enhanced_calendar_service_1.EnhancedCalendarService])
], EnhancedCalendarController);
//# sourceMappingURL=enhanced-calendar.controller.js.map