import { DataSource } from 'typeorm';
export interface EnhancedCalendarData {
    period: {
        startDate: string;
        endDate: string;
    };
    totalWorkingDays: number;
    machineSchedules: MachineSchedule[];
}
export interface MachineSchedule {
    machineId: number;
    machineName: string;
    machineType: string;
    days: CalendarDay[];
}
export interface CalendarDay {
    date: string;
    isWorkingDay: boolean;
    dayType: 'WORKING' | 'WEEKEND' | 'HOLIDAY';
    plannedOperation?: PlannedOperation;
    completedShifts?: CompletedShift[];
}
export interface PlannedOperation {
    operationId: number;
    drawingNumber: string;
    operationNumber: number;
    estimatedTimePerPart: number;
    totalQuantity: number;
    estimatedDurationDays: number;
    startDate: string;
    endDate: string;
    currentProgress?: {
        completedQuantity: number;
        remainingQuantity: number;
        progressPercent: number;
    };
}
export interface CompletedShift {
    shiftType: 'DAY' | 'NIGHT';
    operatorName: string;
    drawingNumber: string;
    operationNumber: number;
    quantityProduced: number;
    timePerPart: number;
    setupTime?: number;
    totalTime: number;
    efficiency: number;
}
export declare class EnhancedCalendarService {
    private readonly dataSource;
    private readonly logger;
    constructor(dataSource: DataSource);
    getEnhancedCalendarView(startDate: string, endDate: string): Promise<EnhancedCalendarData>;
    private generateMachineDays;
    private getCompletedShifts;
    private getCurrentOperation;
    private getPlannedOperation;
    private getOperationProgress;
    private calculateOperationDuration;
    private calculateWorkingDaysBetween;
    private isWorkingDay;
    private getDayType;
}
