"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var EnhancedCalendarService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnhancedCalendarService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const dayjs = require("dayjs");
const isoWeek = require("dayjs/plugin/isoWeek");
const customParseFormat = require("dayjs/plugin/customParseFormat");
dayjs.extend(isoWeek);
dayjs.extend(customParseFormat);
let EnhancedCalendarService = EnhancedCalendarService_1 = class EnhancedCalendarService {
    constructor(dataSource) {
        this.dataSource = dataSource;
        this.logger = new common_1.Logger(EnhancedCalendarService_1.name);
    }
    async getEnhancedCalendarView(startDate, endDate) {
        try {
            this.logger.log(`Загрузка календаря: ${startDate} - ${endDate}`);
            const machines = await this.dataSource.query(`
        SELECT id, code as name, type 
        FROM machines 
        WHERE is_active = true 
        ORDER BY code
      `);
            const totalWorkingDays = this.calculateWorkingDaysBetween(startDate, endDate);
            const machineSchedules = [];
            for (const machine of machines) {
                const days = await this.generateMachineDays(machine.id, startDate, endDate);
                machineSchedules.push({
                    machineId: machine.id,
                    machineName: machine.name,
                    machineType: machine.type,
                    days
                });
            }
            return {
                period: { startDate, endDate },
                totalWorkingDays,
                machineSchedules
            };
        }
        catch (error) {
            this.logger.error('Ошибка получения календаря:', error);
            throw error;
        }
    }
    async generateMachineDays(machineId, startDate, endDate) {
        const days = [];
        const current = dayjs(startDate);
        const end = dayjs(endDate);
        while (current.isBefore(end) || current.isSame(end, 'day')) {
            const dateStr = current.format('YYYY-MM-DD');
            const isWorkingDay = this.isWorkingDay(current.toDate());
            const isPast = current.isBefore(dayjs(), 'day');
            const isToday = current.isSame(dayjs(), 'day');
            let day = {
                date: dateStr,
                isWorkingDay,
                dayType: this.getDayType(current.toDate())
            };
            if (isWorkingDay) {
                if (isPast) {
                    day.completedShifts = await this.getCompletedShifts(machineId, dateStr);
                }
                else if (isToday) {
                    day.plannedOperation = await this.getCurrentOperation(machineId);
                    day.completedShifts = await this.getCompletedShifts(machineId, dateStr);
                }
                else {
                    day.plannedOperation = await this.getPlannedOperation(machineId, dateStr);
                }
            }
            days.push(day);
            current.add(1, 'day');
        }
        return days;
    }
    async getCompletedShifts(machineId, date) {
        try {
            const shifts = await this.dataSource.query(`
        SELECT 
          sr.shift_type,
          sr.day_shift_operator as day_operator,
          sr.night_shift_operator as night_operator,
          sr.day_shift_quantity,
          sr.night_shift_quantity,
          sr.day_shift_time_per_unit,
          sr.night_shift_time_per_unit,
          sr.setup_time,
          ord.drawing_number,
          o.operation_number
        FROM shift_records sr
        JOIN operations o ON sr.operation_id = o.id
        JOIN orders ord ON o.order_id = ord.id
        WHERE sr.machine_id = $1 AND sr.date = $2
      `, [machineId, date]);
            const completedShifts = [];
            for (const shift of shifts) {
                if (shift.day_shift_quantity > 0) {
                    const totalTime = shift.day_shift_quantity * shift.day_shift_time_per_unit;
                    const planTime = 15;
                    const efficiency = shift.day_shift_time_per_unit > 0
                        ? (planTime / shift.day_shift_time_per_unit) * 100
                        : 0;
                    completedShifts.push({
                        shiftType: 'DAY',
                        operatorName: shift.day_operator || 'Не указан',
                        drawingNumber: shift.drawing_number,
                        operationNumber: shift.operation_number,
                        quantityProduced: shift.day_shift_quantity,
                        timePerPart: shift.day_shift_time_per_unit,
                        setupTime: shift.setup_time || 0,
                        totalTime: totalTime + (shift.setup_time || 0),
                        efficiency: Math.min(100, Math.max(0, efficiency))
                    });
                }
                if (shift.night_shift_quantity > 0) {
                    const totalTime = shift.night_shift_quantity * shift.night_shift_time_per_unit;
                    const planTime = 15;
                    const efficiency = shift.night_shift_time_per_unit > 0
                        ? (planTime / shift.night_shift_time_per_unit) * 100
                        : 0;
                    completedShifts.push({
                        shiftType: 'NIGHT',
                        operatorName: shift.night_operator || 'Не указан',
                        drawingNumber: shift.drawing_number,
                        operationNumber: shift.operation_number,
                        quantityProduced: shift.night_shift_quantity,
                        timePerPart: shift.night_shift_time_per_unit,
                        totalTime: totalTime,
                        efficiency: Math.min(100, Math.max(0, efficiency))
                    });
                }
            }
            return completedShifts;
        }
        catch (error) {
            this.logger.error(`Ошибка получения смен для станка ${machineId} на ${date}:`, error);
            return [];
        }
    }
    async getCurrentOperation(machineId) {
        try {
            const current = await this.dataSource.query(`
        SELECT 
          o.id as operation_id,
          ord.drawing_number,
          o.operation_number,
          o.estimated_time as time_per_part,
          ord.quantity as total_quantity,
          o.status,
          o.created_at
        FROM operations o
        JOIN orders ord ON o.order_id = ord.id
        WHERE o.machine_id = $1 AND o.status = 'in_progress'
        LIMIT 1
      `, [machineId]);
            if (current.length === 0)
                return undefined;
            const op = current[0];
            const estimatedDurationDays = this.calculateOperationDuration(op.time_per_part, op.total_quantity);
            const progress = await this.getOperationProgress(op.operation_id);
            return {
                operationId: op.operation_id,
                drawingNumber: op.drawing_number,
                operationNumber: op.operation_number,
                estimatedTimePerPart: op.time_per_part,
                totalQuantity: op.total_quantity,
                estimatedDurationDays,
                startDate: dayjs(op.created_at).format('YYYY-MM-DD'),
                endDate: dayjs(op.created_at).add(estimatedDurationDays, 'day').format('YYYY-MM-DD'),
                currentProgress: progress
            };
        }
        catch (error) {
            this.logger.error(`Ошибка получения текущей операции для станка ${machineId}:`, error);
            return undefined;
        }
    }
    async getPlannedOperation(machineId, date) {
        return undefined;
    }
    async getOperationProgress(operationId) {
        try {
            const progress = await this.dataSource.query(`
        SELECT 
          SUM(day_shift_quantity + night_shift_quantity) as completed_quantity
        FROM shift_records 
        WHERE operation_id = $1
      `, [operationId]);
            const completedQuantity = parseInt(progress[0]?.completed_quantity || '0');
            const operation = await this.dataSource.query(`
        SELECT ord.quantity as total_quantity
        FROM operations o
        JOIN orders ord ON o.order_id = ord.id
        WHERE o.id = $1
      `, [operationId]);
            const totalQuantity = operation[0]?.total_quantity || 0;
            const remainingQuantity = Math.max(0, totalQuantity - completedQuantity);
            const progressPercent = totalQuantity > 0 ? (completedQuantity / totalQuantity) * 100 : 0;
            return {
                completedQuantity,
                remainingQuantity,
                progressPercent: Math.min(100, progressPercent)
            };
        }
        catch (error) {
            this.logger.error(`Ошибка получения прогресса операции ${operationId}:`, error);
            return {
                completedQuantity: 0,
                remainingQuantity: 0,
                progressPercent: 0
            };
        }
    }
    calculateOperationDuration(timePerPart, quantity) {
        const totalMinutes = timePerPart * quantity;
        const minutesPerWorkDay = 16 * 60;
        const baseDays = Math.ceil(totalMinutes / minutesPerWorkDay);
        const setupDays = totalMinutes > 480 ? 1 : 0;
        return Math.max(1, baseDays + setupDays);
    }
    calculateWorkingDaysBetween(startDate, endDate) {
        const start = dayjs(startDate);
        const end = dayjs(endDate);
        let workingDays = 0;
        let current = start;
        while (current.isBefore(end) || current.isSame(end, 'day')) {
            if (this.isWorkingDay(current.toDate())) {
                workingDays++;
            }
            current = current.add(1, 'day');
        }
        return workingDays;
    }
    isWorkingDay(date) {
        const dayOfWeek = date.getDay();
        return ![5, 6].includes(dayOfWeek);
    }
    getDayType(date) {
        const dayOfWeek = date.getDay();
        const holidays = [
            '2025-01-01',
            '2025-05-01',
        ];
        const dateStr = dayjs(date).format('YYYY-MM-DD');
        if (holidays.includes(dateStr)) {
            return 'HOLIDAY';
        }
        return this.isWorkingDay(date) ? 'WORKING' : 'WEEKEND';
    }
};
exports.EnhancedCalendarService = EnhancedCalendarService;
exports.EnhancedCalendarService = EnhancedCalendarService = EnhancedCalendarService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectDataSource)()),
    __metadata("design:paramtypes", [typeorm_2.DataSource])
], EnhancedCalendarService);
//# sourceMappingURL=enhanced-calendar.service.js.map