export declare class WorkingDaysService {
    isWorkingDay(date: Date): boolean;
    getNextWorkingDay(date: Date): Date;
    getPreviousWorkingDay(date: Date): Date;
    countWorkingDays(startDate: Date, endDate: Date): number;
    addWorkingDays(date: Date, days: number): Date;
    getWorkingDaysInPeriod(startDate: Date, endDate: Date): Date[];
    calculateWorkingHours(totalMinutes: number): {
        days: number;
        hours: number;
        minutes: number;
    };
    isHoliday(date: Date): boolean;
}
