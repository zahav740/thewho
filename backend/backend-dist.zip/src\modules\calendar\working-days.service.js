"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WorkingDaysService = void 0;
const common_1 = require("@nestjs/common");
let WorkingDaysService = class WorkingDaysService {
    isWorkingDay(date) {
        const dayOfWeek = date.getDay();
        return dayOfWeek !== 5 && dayOfWeek !== 6;
    }
    getNextWorkingDay(date) {
        const nextDay = new Date(date);
        do {
            nextDay.setDate(nextDay.getDate() + 1);
        } while (!this.isWorkingDay(nextDay));
        return nextDay;
    }
    getPreviousWorkingDay(date) {
        const prevDay = new Date(date);
        do {
            prevDay.setDate(prevDay.getDate() - 1);
        } while (!this.isWorkingDay(prevDay));
        return prevDay;
    }
    countWorkingDays(startDate, endDate) {
        let count = 0;
        const currentDate = new Date(startDate);
        while (currentDate <= endDate) {
            if (this.isWorkingDay(currentDate)) {
                count++;
            }
            currentDate.setDate(currentDate.getDate() + 1);
        }
        return count;
    }
    addWorkingDays(date, days) {
        const result = new Date(date);
        let addedDays = 0;
        while (addedDays < days) {
            result.setDate(result.getDate() + 1);
            if (this.isWorkingDay(result)) {
                addedDays++;
            }
        }
        return result;
    }
    getWorkingDaysInPeriod(startDate, endDate) {
        const workingDays = [];
        const currentDate = new Date(startDate);
        while (currentDate <= endDate) {
            if (this.isWorkingDay(currentDate)) {
                workingDays.push(new Date(currentDate));
            }
            currentDate.setDate(currentDate.getDate() + 1);
        }
        return workingDays;
    }
    calculateWorkingHours(totalMinutes) {
        const minutesPerDay = 480 * 2;
        const days = Math.floor(totalMinutes / minutesPerDay);
        const remainingMinutes = totalMinutes % minutesPerDay;
        const hours = Math.floor(remainingMinutes / 60);
        const minutes = remainingMinutes % 60;
        return { days, hours, minutes };
    }
    isHoliday(date) {
        return !this.isWorkingDay(date);
    }
};
exports.WorkingDaysService = WorkingDaysService;
exports.WorkingDaysService = WorkingDaysService = __decorate([
    (0, common_1.Injectable)()
], WorkingDaysService);
//# sourceMappingURL=working-days.service.js.map