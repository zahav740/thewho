import { StreamableFile } from '@nestjs/common';
import { Response } from 'express';
import { FilesService } from './files.service';
import type { Express } from 'express';
export declare class FilesController {
    private readonly filesService;
    constructor(filesService: FilesService);
    uploadFile(file: Express.Multer.File, folder?: string): Promise<{
        filename: string;
        originalName: any;
        size: any;
        mimetype: any;
    }>;
    parseExcel(file: Express.Multer.File): Promise<{
        headers: string[];
        rows: any[];
        sheetsCount: number;
    }>;
    getFile(filename: string, folder: string, res: Response): Promise<StreamableFile>;
    deleteFile(filename: string, folder?: string): Promise<{
        message: string;
    }>;
    generatePdfPreview(file: Express.Multer.File): Promise<{
        preview: string;
    }>;
    listFiles(folder?: string): Promise<{
        filename: string;
        size: number;
        createdAt: Date;
    }[]>;
    getFileInfo(filename: string, folder?: string): Promise<{
        filename: string;
        size: number;
        createdAt: Date;
        modifiedAt: Date;
        isFile: boolean;
        extension: string;
    }>;
}
