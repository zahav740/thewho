"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.FilesController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const express_1 = require("express");
const files_service_1 = require("./files.service");
let FilesController = class FilesController {
    constructor(filesService) {
        this.filesService = filesService;
    }
    async uploadFile(file, folder) {
        const filename = await this.filesService.uploadFile(file, folder);
        return {
            filename,
            originalName: file.originalname,
            size: file.size,
            mimetype: file.mimetype,
        };
    }
    async parseExcel(file) {
        console.log('📁 ИСПРАВЛЕННЫЙ FILES CONTROLLER: Получен файл:', {
            originalname: file?.originalname,
            size: file?.size,
            mimetype: file?.mimetype,
            hasBuffer: !!file?.buffer,
            bufferSize: file?.buffer?.length,
            fieldname: file?.fieldname
        });
        if (!file) {
            console.error('❌ ИСПРАВЛЕННЫЙ: Файл вообще не получен!');
            throw new Error('Файл не получен контроллером');
        }
        if (!file.buffer) {
            console.error('❌ ИСПРАВЛЕННЫЙ: Файл получен, но buffer отсутствует!');
            console.error('📊 Детали файла:', {
                originalname: file.originalname,
                size: file.size,
                mimetype: file.mimetype,
                fieldname: file.fieldname,
                encoding: file.encoding,
                hasPath: !!file.path,
                hasDestination: !!file.destination
            });
            throw new Error('Файл получен без buffer - проблема конфигурации multer');
        }
        if (file.buffer.length === 0) {
            console.error('❌ ИСПРАВЛЕННЫЙ: Buffer пустой!');
            throw new Error('Получен пустой файл');
        }
        console.log('✅ ИСПРАВЛЕННЫЙ: Файл прошел все проверки, передаем в сервис');
        return this.filesService.parseExcel(file);
    }
    async getFile(filename, folder, res) {
        const buffer = await this.filesService.getFile(filename, folder);
        const extension = filename.split('.').pop()?.toLowerCase();
        let contentType = 'application/octet-stream';
        switch (extension) {
            case 'pdf':
                contentType = 'application/pdf';
                break;
            case 'xlsx':
            case 'xls':
                contentType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
                break;
            case 'jpg':
            case 'jpeg':
                contentType = 'image/jpeg';
                break;
            case 'png':
                contentType = 'image/png';
                break;
        }
        res.set({
            'Content-Type': contentType,
            'Content-Disposition': `attachment; filename="${filename}"`,
        });
        return new common_1.StreamableFile(buffer);
    }
    async deleteFile(filename, folder) {
        await this.filesService.deleteFile(filename, folder);
        return { message: 'Файл успешно удален' };
    }
    async generatePdfPreview(file) {
        const preview = await this.filesService.generatePdfPreview(file.buffer);
        return { preview };
    }
    async listFiles(folder) {
        return this.filesService.listFiles(folder);
    }
    async getFileInfo(filename, folder) {
        return this.filesService.getFileInfo(filename, folder);
    }
};
exports.FilesController = FilesController;
__decorate([
    (0, common_1.Post)('upload'),
    (0, swagger_1.ApiOperation)({ summary: 'Загрузить файл' }),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Query)('folder')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, String]),
    __metadata("design:returntype", Promise)
], FilesController.prototype, "uploadFile", null);
__decorate([
    (0, common_1.Post)('excel/parse'),
    (0, swagger_1.ApiOperation)({ summary: 'ИСПРАВЛЕНО: Парсинг Excel файла с buffer' }),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', {
        fileFilter: (req, file, cb) => {
            console.log('🔍 ИСПРАВЛЕННЫЙ FileInterceptor проверка:', {
                originalname: file.originalname,
                mimetype: file.mimetype,
                size: file.size,
                hasFieldname: !!file.fieldname
            });
            const allowedTypes = [
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'application/vnd.ms-excel',
                'application/octet-stream'
            ];
            const isValidType = allowedTypes.includes(file.mimetype) || file.originalname.match(/\.(xlsx?|csv)$/);
            if (isValidType) {
                console.log('✅ ИСПРАВЛЕНО: Файл прошел проверку, будет сохранен в buffer');
                cb(null, true);
            }
            else {
                console.error('❌ Недопустимый тип файла:', file.mimetype);
                cb(new Error('Только Excel файлы (.xlsx, .xls) разрешены'), false);
            }
        },
        limits: {
            fileSize: 50 * 1024 * 1024,
            fieldSize: 50 * 1024 * 1024,
        },
    })),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], FilesController.prototype, "parseExcel", null);
__decorate([
    (0, common_1.Get)(':filename'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить файл' }),
    (0, swagger_1.ApiQuery)({ name: 'folder', required: false }),
    __param(0, (0, common_1.Param)('filename')),
    __param(1, (0, common_1.Query)('folder')),
    __param(2, (0, common_1.Res)({ passthrough: true })),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, typeof (_a = typeof express_1.Response !== "undefined" && express_1.Response) === "function" ? _a : Object]),
    __metadata("design:returntype", Promise)
], FilesController.prototype, "getFile", null);
__decorate([
    (0, common_1.Delete)(':filename'),
    (0, swagger_1.ApiOperation)({ summary: 'Удалить файл' }),
    (0, swagger_1.ApiQuery)({ name: 'folder', required: false }),
    __param(0, (0, common_1.Param)('filename')),
    __param(1, (0, common_1.Query)('folder')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], FilesController.prototype, "deleteFile", null);
__decorate([
    (0, common_1.Post)('pdf/preview'),
    (0, swagger_1.ApiOperation)({ summary: 'Генерация превью PDF' }),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], FilesController.prototype, "generatePdfPreview", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Список файлов' }),
    (0, swagger_1.ApiQuery)({ name: 'folder', required: false }),
    __param(0, (0, common_1.Query)('folder')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], FilesController.prototype, "listFiles", null);
__decorate([
    (0, common_1.Get)(':filename/info'),
    (0, swagger_1.ApiOperation)({ summary: 'Информация о файле' }),
    (0, swagger_1.ApiQuery)({ name: 'folder', required: false }),
    __param(0, (0, common_1.Param)('filename')),
    __param(1, (0, common_1.Query)('folder')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], FilesController.prototype, "getFileInfo", null);
exports.FilesController = FilesController = __decorate([
    (0, swagger_1.ApiTags)('files'),
    (0, common_1.Controller)('files'),
    __metadata("design:paramtypes", [files_service_1.FilesService])
], FilesController);
//# sourceMappingURL=files.controller.js.map