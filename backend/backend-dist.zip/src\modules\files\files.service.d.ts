import type { Express } from 'express';
export declare class FilesService {
    private readonly uploadsPath;
    private readonly pdfPath;
    private readonly excelPath;
    constructor();
    private ensureDirectories;
    uploadFile(file: Express.Multer.File, folder?: string): Promise<string>;
    getFile(filename: string, folder?: string): Promise<Buffer>;
    deleteFile(filename: string, folder?: string): Promise<void>;
    parseExcel(file: Express.Multer.File): Promise<{
        headers: string[];
        rows: any[];
        sheetsCount: number;
    }>;
    private safeCellValue;
    generatePdfPreview(pdfBuffer: Buffer): Promise<string>;
    listFiles(folder?: string): Promise<{
        filename: string;
        size: number;
        createdAt: Date;
    }[]>;
    getFileInfo(filename: string, folder?: string): Promise<{
        filename: string;
        size: number;
        createdAt: Date;
        modifiedAt: Date;
        isFile: boolean;
        extension: string;
    }>;
}
