"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FilesService = void 0;
const common_1 = require("@nestjs/common");
const fs_1 = require("fs");
const path_1 = require("path");
const ExcelJS = require("exceljs");
const pdf_lib_1 = require("pdf-lib");
let FilesService = class FilesService {
    constructor() {
        this.uploadsPath = (0, path_1.join)(process.cwd(), 'uploads');
        this.pdfPath = (0, path_1.join)(this.uploadsPath, 'pdf');
        this.excelPath = (0, path_1.join)(this.uploadsPath, 'excel');
        this.ensureDirectories();
    }
    async ensureDirectories() {
        const dirs = [this.uploadsPath, this.pdfPath, this.excelPath];
        for (const dir of dirs) {
            try {
                await fs_1.promises.access(dir);
            }
            catch {
                await fs_1.promises.mkdir(dir, { recursive: true });
            }
        }
    }
    async uploadFile(file, folder = '') {
        const targetPath = folder ? (0, path_1.join)(this.uploadsPath, folder) : this.uploadsPath;
        await fs_1.promises.mkdir(targetPath, { recursive: true });
        const filename = `${Date.now()}-${file.originalname}`;
        const filepath = (0, path_1.join)(targetPath, filename);
        await fs_1.promises.writeFile(filepath, file.buffer);
        return filename;
    }
    async getFile(filename, folder = '') {
        const filepath = folder
            ? (0, path_1.join)(this.uploadsPath, folder, filename)
            : (0, path_1.join)(this.uploadsPath, filename);
        try {
            return await fs_1.promises.readFile(filepath);
        }
        catch (error) {
            throw new common_1.NotFoundException('Файл не найден');
        }
    }
    async deleteFile(filename, folder = '') {
        const filepath = folder
            ? (0, path_1.join)(this.uploadsPath, folder, filename)
            : (0, path_1.join)(this.uploadsPath, filename);
        try {
            await fs_1.promises.unlink(filepath);
        }
        catch (error) {
            throw new common_1.NotFoundException('Файл не найден');
        }
    }
    async parseExcel(file) {
        console.log('🔍 ИСПРАВЛЕННЫЙ parseExcel: Начало обработки файла:', {
            originalname: file.originalname,
            size: file.size,
            mimetype: file.mimetype,
            hasBuffer: !!file.buffer,
            bufferSize: file.buffer?.length
        });
        try {
            if (!file || !file.buffer) {
                console.error('❌ Файл или buffer отсутствует');
                throw new common_1.BadRequestException('Файл не предоставлен или поврежден');
            }
            if (file.buffer.length === 0) {
                console.error('❌ Пустой файл');
                throw new common_1.BadRequestException('Файл пустой');
            }
            console.log('✅ Файл прошел базовые проверки, загружаем через ExcelJS...');
            const workbook = new ExcelJS.Workbook();
            try {
                await workbook.xlsx.load(file.buffer);
                console.log('✅ Excel файл успешно загружен через ExcelJS');
            }
            catch (loadError) {
                console.error('❌ Ошибка загрузки Excel через ExcelJS:', loadError);
                throw new common_1.BadRequestException(`Ошибка чтения Excel файла: ${loadError.message}`);
            }
            console.log(`📄 Количество листов в файле: ${workbook.worksheets.length}`);
            if (workbook.worksheets.length === 0) {
                throw new common_1.BadRequestException('Excel файл не содержит рабочих листов');
            }
            const worksheet = workbook.getWorksheet(1);
            if (!worksheet) {
                throw new common_1.BadRequestException('Первый рабочий лист не найден');
            }
            console.log('📊 Информация о рабочем листе:', {
                name: worksheet.name,
                rowCount: worksheet.rowCount,
                columnCount: worksheet.columnCount
            });
            const headers = [];
            const rows = [];
            try {
                const headerRow = worksheet.getRow(1);
                if (headerRow && headerRow.cellCount > 0) {
                    console.log(`📋 Обработка заголовков из ${headerRow.cellCount} ячеек...`);
                    for (let colNum = 1; colNum <= Math.min(headerRow.cellCount, 50); colNum++) {
                        try {
                            const cell = headerRow.getCell(colNum);
                            const cellValue = this.safeCellValue(cell);
                            const headerValue = cellValue !== null ? String(cellValue) : `Колонка ${colNum}`;
                            headers.push(headerValue);
                        }
                        catch (cellError) {
                            console.warn(`⚠️ Ошибка при чтении ячейки заголовка ${colNum}:`, cellError);
                            headers.push(`Колонка ${colNum}`);
                        }
                    }
                    console.log('✅ Заголовки получены:', headers.slice(0, 10));
                }
                else {
                    console.log('⚠️ Заголовки не найдены, создаем автоматически');
                    for (let i = 1; i <= 10; i++) {
                        headers.push(`Колонка ${i}`);
                    }
                }
                let processedRows = 0;
                const maxRows = Math.min(worksheet.rowCount, 1000);
                console.log(`📊 Начинаем обработку ${maxRows} строк данных...`);
                for (let rowNum = 2; rowNum <= maxRows; rowNum++) {
                    try {
                        const row = worksheet.getRow(rowNum);
                        if (!row || row.cellCount === 0) {
                            continue;
                        }
                        const rowData = {};
                        let hasData = false;
                        for (let colNum = 1; colNum <= headers.length; colNum++) {
                            try {
                                const cell = row.getCell(colNum);
                                const cellValue = this.safeCellValue(cell);
                                const header = headers[colNum - 1];
                                if (header && cellValue !== null && cellValue !== '') {
                                    rowData[header] = cellValue;
                                    hasData = true;
                                }
                            }
                            catch (cellError) {
                                console.warn(`⚠️ Ошибка при чтении ячейки [${rowNum},${colNum}]:`, cellError);
                            }
                        }
                        if (hasData) {
                            rows.push(rowData);
                            processedRows++;
                        }
                        if (processedRows % 100 === 0) {
                            console.log(`📈 Обработано ${processedRows} строк...`);
                        }
                    }
                    catch (rowError) {
                        console.warn(`⚠️ Ошибка при обработке строки ${rowNum}:`, rowError);
                    }
                }
                console.log('✅ ИСПРАВЛЕННЫЙ parseExcel: Обработка завершена:', {
                    headers: headers.length,
                    rows: rows.length,
                    sheetsCount: workbook.worksheets.length,
                    processedRows
                });
                return {
                    headers,
                    rows,
                    sheetsCount: workbook.worksheets.length,
                };
            }
            catch (processingError) {
                console.error('❌ Ошибка при обработке данных Excel:', processingError);
                throw new common_1.BadRequestException(`Ошибка обработки данных Excel: ${processingError.message}`);
            }
        }
        catch (error) {
            console.error('❌ КРИТИЧЕСКАЯ ошибка в parseExcel:', error);
            if (error instanceof common_1.BadRequestException) {
                throw error;
            }
            throw new common_1.BadRequestException(`Не удалось обработать Excel файл: ${error.message || 'Неизвестная ошибка'}`);
        }
    }
    safeCellValue(cell) {
        try {
            if (!cell) {
                return null;
            }
            const value = cell.value;
            if (value === null || value === undefined) {
                return null;
            }
            if (typeof value === 'string' || typeof value === 'number') {
                return value;
            }
            if (typeof value === 'object' && value !== null && 'result' in value) {
                const formulaValue = value;
                const result = formulaValue.result;
                if (typeof result === 'string' || typeof result === 'number') {
                    return result;
                }
                if (result === null || result === undefined) {
                    return null;
                }
                return String(result);
            }
            if (value instanceof Date) {
                return value.toISOString().split('T')[0];
            }
            if (typeof value === 'object' && value !== null && 'richText' in value) {
                const richTextValue = value;
                const richText = richTextValue.richText;
                if (Array.isArray(richText)) {
                    return richText.map((rt) => rt.text || '').join('') || null;
                }
                return null;
            }
            if (typeof value === 'boolean') {
                return value ? 'TRUE' : 'FALSE';
            }
            return String(value);
        }
        catch (error) {
            console.warn('⚠️ Ошибка при извлечении значения ячейки:', error);
            return null;
        }
    }
    async generatePdfPreview(pdfBuffer) {
        try {
            const pdfDoc = await pdf_lib_1.PDFDocument.load(pdfBuffer);
            const pages = pdfDoc.getPages();
            if (pages.length === 0) {
                throw new common_1.BadRequestException('PDF файл не содержит страниц');
            }
            const firstPage = pages[0];
            const { width, height } = firstPage.getSize();
            const previewDoc = await pdf_lib_1.PDFDocument.create();
            const [copiedPage] = await previewDoc.copyPages(pdfDoc, [0]);
            previewDoc.addPage(copiedPage);
            const previewBytes = await previewDoc.save();
            const previewBase64 = Buffer.from(previewBytes).toString('base64');
            return `data:application/pdf;base64,${previewBase64}`;
        }
        catch (error) {
            throw new common_1.BadRequestException('Не удалось создать превью PDF');
        }
    }
    async listFiles(folder = '') {
        const targetPath = folder
            ? (0, path_1.join)(this.uploadsPath, folder)
            : this.uploadsPath;
        try {
            const files = await fs_1.promises.readdir(targetPath);
            const fileInfo = [];
            for (const file of files) {
                const filepath = (0, path_1.join)(targetPath, file);
                const stats = await fs_1.promises.stat(filepath);
                if (stats.isFile()) {
                    fileInfo.push({
                        filename: file,
                        size: stats.size,
                        createdAt: stats.birthtime,
                    });
                }
            }
            return fileInfo;
        }
        catch (error) {
            return [];
        }
    }
    async getFileInfo(filename, folder = '') {
        const filepath = folder
            ? (0, path_1.join)(this.uploadsPath, folder, filename)
            : (0, path_1.join)(this.uploadsPath, filename);
        try {
            const stats = await fs_1.promises.stat(filepath);
            return {
                filename,
                size: stats.size,
                createdAt: stats.birthtime,
                modifiedAt: stats.mtime,
                isFile: stats.isFile(),
                extension: filename.split('.').pop(),
            };
        }
        catch (error) {
            throw new common_1.NotFoundException('Файл не найден');
        }
    }
};
exports.FilesService = FilesService;
exports.FilesService = FilesService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], FilesService);
//# sourceMappingURL=files.service.js.map