import { DataSource } from 'typeorm';
export declare class HealthController {
    private dataSource;
    constructor(dataSource: DataSource);
    check(): Promise<{
        status: string;
        timestamp: string;
        database: {
            connected: boolean;
            machinesCount: number;
            ordersCount: number;
            error?: undefined;
        };
    } | {
        status: string;
        timestamp: string;
        database: {
            connected: boolean;
            error: any;
            machinesCount?: undefined;
            ordersCount?: undefined;
        };
    }>;
    checkDatabase(): Promise<{
        status: string;
        tables: {};
        timestamp: string;
        error?: undefined;
    } | {
        status: string;
        error: any;
        timestamp: string;
        tables?: undefined;
    }>;
    getSampleData(): Promise<{
        status: string;
        sampleData: {
            machines: any;
            orders: any;
            operations: any;
        };
        timestamp: string;
        error?: undefined;
    } | {
        status: string;
        error: any;
        timestamp: string;
        sampleData?: undefined;
    }>;
}
