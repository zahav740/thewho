"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.HealthController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
let HealthController = class HealthController {
    constructor(dataSource) {
        this.dataSource = dataSource;
    }
    async check() {
        try {
            await this.dataSource.query('SELECT 1');
            const machinesCount = await this.dataSource.query('SELECT COUNT(*) FROM machines');
            const ordersCount = await this.dataSource.query('SELECT COUNT(*) FROM orders');
            return {
                status: 'ok',
                timestamp: new Date().toISOString(),
                database: {
                    connected: true,
                    machinesCount: parseInt(machinesCount[0].count),
                    ordersCount: parseInt(ordersCount[0].count),
                },
            };
        }
        catch (error) {
            return {
                status: 'error',
                timestamp: new Date().toISOString(),
                database: {
                    connected: false,
                    error: error.message,
                },
            };
        }
    }
    async checkDatabase() {
        try {
            const tables = await this.dataSource.query(`
        SELECT table_name 
        FROM information_schema.tables 
        WHERE table_schema = 'public'
        ORDER BY table_name
      `);
            const tableDetails = {};
            for (const table of tables) {
                const tableName = table.table_name;
                try {
                    const count = await this.dataSource.query(`SELECT COUNT(*) FROM "${tableName}"`);
                    tableDetails[tableName] = parseInt(count[0].count);
                }
                catch (err) {
                    tableDetails[tableName] = `Error: ${err.message}`;
                }
            }
            return {
                status: 'ok',
                tables: tableDetails,
                timestamp: new Date().toISOString(),
            };
        }
        catch (error) {
            return {
                status: 'error',
                error: error.message,
                timestamp: new Date().toISOString(),
            };
        }
    }
    async getSampleData() {
        try {
            const machines = await this.dataSource.query('SELECT * FROM machines LIMIT 5');
            const orders = await this.dataSource.query('SELECT * FROM orders LIMIT 5');
            const operations = await this.dataSource.query('SELECT * FROM operations LIMIT 5');
            return {
                status: 'ok',
                sampleData: {
                    machines,
                    orders,
                    operations,
                },
                timestamp: new Date().toISOString(),
            };
        }
        catch (error) {
            return {
                status: 'error',
                error: error.message,
                timestamp: new Date().toISOString(),
            };
        }
    }
};
exports.HealthController = HealthController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Проверка состояния сервиса' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], HealthController.prototype, "check", null);
__decorate([
    (0, common_1.Get)('db'),
    (0, swagger_1.ApiOperation)({ summary: 'Детальная проверка базы данных' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], HealthController.prototype, "checkDatabase", null);
__decorate([
    (0, common_1.Get)('sample-data'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить образцы данных' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], HealthController.prototype, "getSampleData", null);
exports.HealthController = HealthController = __decorate([
    (0, swagger_1.ApiTags)('health'),
    (0, common_1.Controller)('health'),
    __param(0, (0, typeorm_1.InjectDataSource)()),
    __metadata("design:paramtypes", [typeorm_2.DataSource])
], HealthController);
//# sourceMappingURL=health.controller.js.map