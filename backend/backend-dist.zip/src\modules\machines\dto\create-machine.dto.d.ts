import { MachineType } from '../../../database/entities/machine.entity';
export declare class CreateMachineDto {
    code: string;
    type: MachineType;
    axes: number;
}
