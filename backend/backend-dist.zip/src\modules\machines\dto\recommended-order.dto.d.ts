import { Priority } from '../../../database/entities/order.entity';
export declare class RecommendedOrderDto {
    orderId: number;
    operationId: string;
    drawingNumber: string;
    revision: string;
    quantity: number;
    operationNumber: number;
    operationType: string;
    estimatedTime: number;
    priority: Priority;
    deadline: Date;
    pdfUrl?: string;
    previewUrl?: string;
    previewHtml?: string;
}
