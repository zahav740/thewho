import { CreateMachineDto } from './create-machine.dto';
declare const UpdateMachineDto_base: import("@nestjs/common").Type<Partial<CreateMachineDto>>;
export declare class UpdateMachineDto extends UpdateMachineDto_base {
    isActive?: boolean;
    isOccupied?: boolean;
    currentOperation?: number;
    assignedAt?: Date;
}
export {};
