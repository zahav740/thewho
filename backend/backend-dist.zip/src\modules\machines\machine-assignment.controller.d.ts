import { Repository } from 'typeorm';
import { Machine } from '../../database/entities/machine.entity';
import { Operation } from '../../database/entities/operation.entity';
import { Order } from '../../database/entities/order.entity';
interface AssignOperationDto {
    operationId: number;
    machineName?: string;
    machineId?: number;
}
interface AssignmentResult {
    success: boolean;
    message: string;
    machine: {
        id: number;
        code: string;
        type: string;
        isOccupied: boolean;
        currentOperation: number;
    };
    operation: {
        id: number;
        operationNumber: number;
        operationType: string;
        orderDrawingNumber: string;
        status: string;
        assignedMachine: number;
    };
}
export declare class MachineAssignmentController {
    private readonly machineRepository;
    private readonly operationRepository;
    private readonly orderRepository;
    private readonly logger;
    constructor(machineRepository: Repository<Machine>, operationRepository: Repository<Operation>, orderRepository: Repository<Order>);
    assignOperation(machineIdentifier: string, dto: AssignOperationDto): Promise<AssignmentResult>;
    unassignOperation(machineIdentifier: string): Promise<any>;
    updateAvailability(machineIdentifier: string, body: {
        isAvailable: boolean;
    }): Promise<any>;
    private findMachine;
    private performAssignment;
    private isOperationCompatibleWithMachine;
}
export {};
