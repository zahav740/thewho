"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var MachineAssignmentController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MachineAssignmentController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const machine_entity_1 = require("../../database/entities/machine.entity");
const operation_entity_1 = require("../../database/entities/operation.entity");
const order_entity_1 = require("../../database/entities/order.entity");
let MachineAssignmentController = MachineAssignmentController_1 = class MachineAssignmentController {
    constructor(machineRepository, operationRepository, orderRepository) {
        this.machineRepository = machineRepository;
        this.operationRepository = operationRepository;
        this.orderRepository = orderRepository;
        this.logger = new common_1.Logger(MachineAssignmentController_1.name);
    }
    async assignOperation(machineIdentifier, dto) {
        try {
            this.logger.log(`Назначение операции ${dto.operationId} на станок ${machineIdentifier}`);
            const machine = await this.findMachine(machineIdentifier);
            if (!machine) {
                throw new common_1.BadRequestException(`Станок не найден: ${machineIdentifier}`);
            }
            if (machine.isOccupied || machine.currentOperation) {
                throw new common_1.BadRequestException(`Станок ${machine.code} уже занят операцией ${machine.currentOperation}`);
            }
            const operation = await this.operationRepository.findOne({
                where: { id: dto.operationId },
                relations: ['order']
            });
            if (!operation) {
                throw new common_1.BadRequestException(`Операция не найдена: ${dto.operationId}`);
            }
            if (operation.assignedMachine && operation.assignedMachine !== machine.id) {
                throw new common_1.BadRequestException(`Операция уже назначена на станок ${operation.assignedMachine}`);
            }
            if (!this.isOperationCompatibleWithMachine(operation, machine)) {
                throw new common_1.BadRequestException(`Операция ${operation.operationType} несовместима со станком ${machine.type}`);
            }
            await this.performAssignment(machine, operation);
            const updatedMachine = await this.machineRepository.findOne({ where: { id: machine.id } });
            const updatedOperation = await this.operationRepository.findOne({
                where: { id: operation.id },
                relations: ['order']
            });
            const result = {
                success: true,
                message: `Операция ${operation.operationNumber} успешно назначена на станок ${machine.code}`,
                machine: {
                    id: updatedMachine.id,
                    code: updatedMachine.code,
                    type: updatedMachine.type,
                    isOccupied: updatedMachine.isOccupied,
                    currentOperation: updatedMachine.currentOperation,
                },
                operation: {
                    id: updatedOperation.id,
                    operationNumber: updatedOperation.operationNumber,
                    operationType: updatedOperation.operationType,
                    orderDrawingNumber: updatedOperation.order?.drawingNumber || 'Неизвестно',
                    status: updatedOperation.status,
                    assignedMachine: updatedOperation.assignedMachine,
                }
            };
            this.logger.log(`✅ Операция назначена: ${machine.code} -> Операция ${operation.operationNumber}`);
            return result;
        }
        catch (error) {
            this.logger.error(`Ошибка при назначении операции: ${error.message}`);
            throw error;
        }
    }
    async unassignOperation(machineIdentifier) {
        try {
            this.logger.log(`Отмена назначения операции на станок ${machineIdentifier}`);
            const machine = await this.findMachine(machineIdentifier);
            if (!machine) {
                throw new common_1.BadRequestException(`Станок не найден: ${machineIdentifier}`);
            }
            if (!machine.currentOperation) {
                throw new common_1.BadRequestException(`На станке ${machine.code} нет назначенной операции`);
            }
            const operation = await this.operationRepository.findOne({
                where: { id: machine.currentOperation }
            });
            if (!operation) {
                this.logger.warn(`Операция ${machine.currentOperation} не найдена, очищаем станок`);
            }
            await this.machineRepository.update(machine.id, {
                isOccupied: false,
                currentOperation: null,
                assignedAt: null,
                updatedAt: new Date()
            });
            if (operation) {
                await this.operationRepository.update(operation.id, {
                    assignedMachine: null,
                    assignedAt: null,
                    status: 'PENDING',
                    updatedAt: new Date()
                });
            }
            this.logger.log(`✅ Назначение отменено: станок ${machine.code} освобожден`);
            return {
                success: true,
                message: `Назначение операции отменено, станок ${machine.code} освобожден`,
                machine: {
                    id: machine.id,
                    code: machine.code,
                    isOccupied: false,
                    currentOperation: null,
                }
            };
        }
        catch (error) {
            this.logger.error(`Ошибка при отмене назначения: ${error.message}`);
            throw error;
        }
    }
    async updateAvailability(machineIdentifier, body) {
        try {
            this.logger.log(`Изменение доступности станка ${machineIdentifier} на ${body.isAvailable}`);
            const machine = await this.findMachine(machineIdentifier);
            if (!machine) {
                throw new common_1.BadRequestException(`Станок не найден: ${machineIdentifier}`);
            }
            if (!body.isAvailable) {
                await this.machineRepository.update(machine.id, {
                    isOccupied: true,
                    updatedAt: new Date()
                });
            }
            else {
                if (machine.currentOperation) {
                    const operation = await this.operationRepository.findOne({
                        where: { id: machine.currentOperation }
                    });
                    if (operation) {
                        await this.operationRepository.update(operation.id, {
                            assignedMachine: null,
                            assignedAt: null,
                            status: 'PENDING',
                            updatedAt: new Date()
                        });
                    }
                }
                await this.machineRepository.update(machine.id, {
                    isOccupied: false,
                    currentOperation: null,
                    assignedAt: null,
                    updatedAt: new Date()
                });
            }
            const updatedMachine = await this.machineRepository.findOne({ where: { id: machine.id } });
            this.logger.log(`✅ Доступность станка ${machine.code} изменена на ${body.isAvailable ? 'доступен' : 'занят'}`);
            return {
                success: true,
                id: updatedMachine.id.toString(),
                machineName: updatedMachine.code,
                machineType: updatedMachine.type,
                isAvailable: !updatedMachine.isOccupied,
                isOccupied: updatedMachine.isOccupied,
                currentOperationId: updatedMachine.currentOperation?.toString(),
                lastFreedAt: updatedMachine.assignedAt,
                createdAt: updatedMachine.createdAt.toISOString(),
                updatedAt: updatedMachine.updatedAt.toISOString(),
            };
        }
        catch (error) {
            this.logger.error(`Ошибка при изменении доступности: ${error.message}`);
            throw error;
        }
    }
    async findMachine(identifier) {
        if (/^\d+$/.test(identifier)) {
            const machine = await this.machineRepository.findOne({
                where: { id: parseInt(identifier) }
            });
            if (machine)
                return machine;
        }
        return await this.machineRepository.findOne({
            where: { code: identifier }
        });
    }
    async performAssignment(machine, operation) {
        const now = new Date();
        await this.machineRepository.update(machine.id, {
            isOccupied: true,
            currentOperation: operation.id,
            assignedAt: now,
            updatedAt: now
        });
        await this.operationRepository.update(operation.id, {
            assignedMachine: machine.id,
            assignedAt: now,
            status: 'ASSIGNED',
            updatedAt: now
        });
    }
    isOperationCompatibleWithMachine(operation, machine) {
        const operationType = operation.operationType?.toUpperCase();
        const machineType = machine.type?.toUpperCase();
        switch (operationType) {
            case 'TURNING':
                return machineType === 'TURNING';
            case 'MILLING':
                if (operation.machineAxes === 4) {
                    return machineType === 'MILLING' && machine.axes >= 4;
                }
                else {
                    return machineType === 'MILLING';
                }
            default:
                return false;
        }
    }
};
exports.MachineAssignmentController = MachineAssignmentController;
__decorate([
    (0, common_1.Post)(':machineIdentifier/assign-operation'),
    (0, swagger_1.ApiOperation)({ summary: 'Назначить операцию на станок' }),
    __param(0, (0, common_1.Param)('machineIdentifier')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], MachineAssignmentController.prototype, "assignOperation", null);
__decorate([
    (0, common_1.Delete)(':machineIdentifier/assign-operation'),
    (0, swagger_1.ApiOperation)({ summary: 'Отменить назначение операции на станок' }),
    __param(0, (0, common_1.Param)('machineIdentifier')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], MachineAssignmentController.prototype, "unassignOperation", null);
__decorate([
    (0, common_1.Put)(':machineIdentifier/availability'),
    (0, swagger_1.ApiOperation)({ summary: 'Изменить доступность станка' }),
    __param(0, (0, common_1.Param)('machineIdentifier')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], MachineAssignmentController.prototype, "updateAvailability", null);
exports.MachineAssignmentController = MachineAssignmentController = MachineAssignmentController_1 = __decorate([
    (0, swagger_1.ApiTags)('machine-assignment'),
    (0, common_1.Controller)('machines'),
    __param(0, (0, typeorm_1.InjectRepository)(machine_entity_1.Machine)),
    __param(1, (0, typeorm_1.InjectRepository)(operation_entity_1.Operation)),
    __param(2, (0, typeorm_1.InjectRepository)(order_entity_1.Order)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], MachineAssignmentController);
//# sourceMappingURL=machine-assignment.controller.js.map