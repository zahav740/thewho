import { DataSource } from 'typeorm';
export interface MachineAvailabilityDto {
    id: string;
    machineName: string;
    machineType: string;
    isAvailable: boolean;
    currentOperationId?: string;
    currentOperationDetails?: {
        id: string;
        operationNumber: number;
        operationType: string;
        estimatedTime: number;
        status: string;
        orderDrawingNumber?: string;
        orderId?: string;
    };
    lastFreedAt?: Date;
    createdAt: Date;
    updatedAt: Date;
}
export declare class MachineAvailabilitySimpleService {
    private readonly dataSource;
    constructor(dataSource: DataSource);
    findAll(): Promise<MachineAvailabilityDto[]>;
    findByName(machineName: string): Promise<MachineAvailabilityDto>;
    updateAvailability(machineName: string, isAvailable: boolean): Promise<MachineAvailabilityDto>;
    getAvailableMachines(): Promise<MachineAvailabilityDto[]>;
    getActiveOperations(): Promise<any[]>;
    assignOperation(machineName: string, operationId: string): Promise<MachineAvailabilityDto>;
    unassignOperation(machineName: string): Promise<MachineAvailabilityDto>;
}
