"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MachineAvailabilitySimpleService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
let MachineAvailabilitySimpleService = class MachineAvailabilitySimpleService {
    constructor(dataSource) {
        this.dataSource = dataSource;
    }
    async findAll() {
        try {
            console.log('SimpleMachineService: Получение всех станков с информацией об операциях');
            const machines = await this.dataSource.query(`
        SELECT 
          m.id::text,
          m.code as "machineName",
          m.type as "machineType", 
          (NOT m."isOccupied") as "isAvailable",
          op.id::text as "currentOperationId",
          op."operationNumber",
          op.operationtype as "operationType",
          op."estimatedTime",
          op.status,
          ord.drawing_number as "orderDrawingNumber",
          ord.id::text as "orderId",
          COALESCE(op."assignedAt", m."updatedAt") as "lastFreedAt",
          m."createdAt" as "createdAt",
          m."updatedAt" as "updatedAt"
        FROM machines m
        LEFT JOIN operations op ON (
          op."assignedMachine" = m.id 
          AND op.status IN ('IN_PROGRESS', 'ASSIGNED')
        )
        LEFT JOIN orders ord ON op."orderId" = ord.id
        WHERE m."isActive" = true
        ORDER BY m.code ASC
      `);
            const result = machines.map(machine => ({
                id: machine.id,
                machineName: machine.machineName,
                machineType: machine.machineType,
                isAvailable: machine.isAvailable,
                currentOperationId: machine.currentOperationId,
                currentOperationDetails: machine.currentOperationId ? {
                    id: machine.currentOperationId,
                    operationNumber: machine.operationNumber,
                    operationType: machine.operationType,
                    estimatedTime: machine.estimatedTime,
                    status: machine.status,
                    orderDrawingNumber: machine.orderDrawingNumber,
                    orderId: machine.orderId,
                } : undefined,
                lastFreedAt: machine.lastFreedAt,
                createdAt: machine.createdAt,
                updatedAt: machine.updatedAt,
            }));
            console.log(`SimpleMachineService: Найдено ${result.length} станков`);
            console.log('Станки с операциями:', result.filter(m => m.currentOperationId).length);
            return result;
        }
        catch (error) {
            console.error('SimpleMachineService.findAll Ошибка:', error);
            throw error;
        }
    }
    async findByName(machineName) {
        try {
            const machines = await this.dataSource.query(`
        SELECT 
          m.id::text,
          m.code as "machineName",
          m.type as "machineType",
          (NOT m."isOccupied") as "isAvailable", 
          op.id::text as "currentOperationId",
          op."operationNumber",
          op.operationtype as "operationType",
          op."estimatedTime",
          op.status,
          ord.drawing_number as "orderDrawingNumber",
          ord.id::text as "orderId",
          COALESCE(op."assignedAt", m."updatedAt") as "lastFreedAt",
          m."createdAt" as "createdAt",
          m."updatedAt" as "updatedAt"
        FROM machines m
        LEFT JOIN operations op ON (
          op."assignedMachine" = m.id 
          AND op.status IN ('IN_PROGRESS', 'ASSIGNED')
        )
        LEFT JOIN orders ord ON op."orderId" = ord.id
        WHERE m.code = $1 AND m."isActive" = true
      `, [machineName]);
            if (machines.length === 0) {
                throw new common_1.NotFoundException(`Станок ${machineName} не найден`);
            }
            const machine = machines[0];
            return {
                id: machine.id,
                machineName: machine.machineName,
                machineType: machine.machineType,
                isAvailable: machine.isAvailable,
                currentOperationId: machine.currentOperationId,
                currentOperationDetails: machine.currentOperationId ? {
                    id: machine.currentOperationId,
                    operationNumber: machine.operationNumber,
                    operationType: machine.operationType,
                    estimatedTime: machine.estimatedTime,
                    status: machine.status,
                    orderDrawingNumber: machine.orderDrawingNumber,
                    orderId: machine.orderId,
                } : undefined,
                lastFreedAt: machine.lastFreedAt,
                createdAt: machine.createdAt,
                updatedAt: machine.updatedAt,
            };
        }
        catch (error) {
            console.error('SimpleMachineService.findByName Ошибка:', error);
            throw error;
        }
    }
    async updateAvailability(machineName, isAvailable) {
        try {
            await this.dataSource.query(`
        UPDATE machines 
        SET 
          "isOccupied" = $1,
          "updatedAt" = NOW()
        WHERE code = $2
      `, [!isAvailable, machineName]);
            return this.findByName(machineName);
        }
        catch (error) {
            console.error('SimpleMachineService.updateAvailability Ошибка:', error);
            throw error;
        }
    }
    async getAvailableMachines() {
        try {
            const machines = await this.dataSource.query(`
        SELECT 
          m.id::text,
          m.code as "machineName",
          m.type as "machineType",
          (NOT m."isOccupied") as "isAvailable",
          op.id::text as "currentOperationId",
          op."operationNumber",
          op.operationtype as "operationType",
          op."estimatedTime",
          op.status,
          ord.drawing_number as "orderDrawingNumber",
          ord.id::text as "orderId",
          COALESCE(op."assignedAt", m."updatedAt") as "lastFreedAt",
          m."createdAt" as "createdAt",
          m."updatedAt" as "updatedAt"
        FROM machines m
        LEFT JOIN operations op ON (
          op."assignedMachine" = m.id 
          AND op.status IN ('IN_PROGRESS', 'ASSIGNED')
        )
        LEFT JOIN orders ord ON op."orderId" = ord.id
        WHERE m."isActive" = true AND m."isOccupied" = false
        ORDER BY m.code ASC
      `);
            return machines.map(machine => ({
                id: machine.id,
                machineName: machine.machineName,
                machineType: machine.machineType,
                isAvailable: machine.isAvailable,
                currentOperationId: machine.currentOperationId,
                currentOperationDetails: machine.currentOperationId ? {
                    id: machine.currentOperationId,
                    operationNumber: machine.operationNumber,
                    operationType: machine.operationType,
                    estimatedTime: machine.estimatedTime,
                    status: machine.status,
                    orderDrawingNumber: machine.orderDrawingNumber,
                    orderId: machine.orderId,
                } : undefined,
                lastFreedAt: machine.lastFreedAt,
                createdAt: machine.createdAt,
                updatedAt: machine.updatedAt,
            }));
        }
        catch (error) {
            console.error('SimpleMachineService.getAvailableMachines Ошибка:', error);
            throw error;
        }
    }
    async getActiveOperations() {
        try {
            console.log('SimpleMachineService: Получение активных операций');
            const operations = await this.dataSource.query(`
        SELECT 
          op.id::text,
          op."operationNumber",
          op.operationtype as "operationType",
          op."estimatedTime",
          op.status,
          op."assignedMachine"::text as "machineId",
          m.code as "machineName",
          ord.drawing_number as "orderDrawingNumber",
          ord.id::text as "orderId",
          op."assignedAt",
          op."createdAt",
          op."updatedAt"
        FROM operations op
        INNER JOIN machines m ON op."assignedMachine" = m.id
        LEFT JOIN orders ord ON op."orderId" = ord.id
        WHERE op.status IN ('IN_PROGRESS', 'ASSIGNED')
        ORDER BY op."assignedAt" DESC
      `);
            console.log(`SimpleMachineService: Найдено ${operations.length} активных операций`);
            return operations;
        }
        catch (error) {
            console.error('SimpleMachineService.getActiveOperations Ошибка:', error);
            throw error;
        }
    }
    async assignOperation(machineName, operationId) {
        try {
            console.log('SimpleMachineService: Назначение операции:', operationId, 'для станка:', machineName);
            const machines = await this.dataSource.query(`
        SELECT id FROM machines WHERE code = $1 AND "isActive" = true
      `, [machineName]);
            if (machines.length === 0) {
                throw new common_1.NotFoundException(`Станок ${machineName} не найден`);
            }
            const machineId = machines[0].id;
            const operationIdInt = parseInt(operationId);
            const operations = await this.dataSource.query(`
        SELECT id FROM operations WHERE id = $1 AND status = 'PENDING'
      `, [operationIdInt]);
            if (operations.length === 0) {
                throw new common_1.NotFoundException(`Операция ${operationId} не найдена или не в статусе PENDING`);
            }
            await this.dataSource.query(`
        UPDATE operations 
        SET 
          "assignedMachine" = $1,
          "assignedAt" = NOW(),
          status = 'ASSIGNED',
          "updatedAt" = NOW()
        WHERE id = $2
      `, [machineId, operationIdInt]);
            await this.dataSource.query(`
        UPDATE machines 
        SET 
          "isOccupied" = true,
          "updatedAt" = NOW()
        WHERE id = $1
      `, [machineId]);
            console.log(`SimpleMachineService: Операция ${operationId} назначена на станок ${machineName}`);
            return this.findByName(machineName);
        }
        catch (error) {
            console.error('SimpleMachineService.assignOperation Ошибка:', error);
            throw error;
        }
    }
    async unassignOperation(machineName) {
        try {
            console.log('SimpleMachineService: Отмена операции для станка:', machineName);
            const machines = await this.dataSource.query(`
        SELECT id FROM machines WHERE code = $1 AND "isActive" = true
      `, [machineName]);
            if (machines.length === 0) {
                throw new common_1.NotFoundException(`Станок ${machineName} не найден`);
            }
            const machineId = machines[0].id;
            await this.dataSource.query(`
        UPDATE operations 
        SET 
          "assignedMachine" = NULL,
          "assignedAt" = NULL,
          status = 'PENDING',
          "updatedAt" = NOW()
        WHERE "assignedMachine" = $1
      `, [machineId]);
            await this.dataSource.query(`
        UPDATE machines 
        SET 
          "isOccupied" = false,
          "updatedAt" = NOW()
        WHERE id = $1
      `, [machineId]);
            console.log(`SimpleMachineService: Операция отменена для станка ${machineName}`);
            return this.findByName(machineName);
        }
        catch (error) {
            console.error('SimpleMachineService.unassignOperation Ошибка:', error);
            throw error;
        }
    }
};
exports.MachineAvailabilitySimpleService = MachineAvailabilitySimpleService;
exports.MachineAvailabilitySimpleService = MachineAvailabilitySimpleService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectDataSource)()),
    __metadata("design:paramtypes", [typeorm_2.DataSource])
], MachineAvailabilitySimpleService);
//# sourceMappingURL=machine-availability-simple.service.js.map