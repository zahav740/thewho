import { Repository } from 'typeorm';
import { MachineAvailability } from '../../database/entities/machine-availability.entity';
export declare class MachineAvailabilityService {
    private readonly machineAvailabilityRepository;
    constructor(machineAvailabilityRepository: Repository<MachineAvailability>);
    findAll(): Promise<MachineAvailability[]>;
    findOne(id: string): Promise<MachineAvailability>;
    findByName(machineName: string): Promise<MachineAvailability>;
    updateAvailability(machineName: string, isAvailable: boolean): Promise<MachineAvailability>;
    assignOperation(machineName: string, operationId: string): Promise<MachineAvailability>;
    getAvailableMachines(): Promise<MachineAvailability[]>;
    getCompatibleMachines(operationType: string): Promise<MachineAvailability[]>;
}
