"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MachineAvailabilityService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const machine_availability_entity_1 = require("../../database/entities/machine-availability.entity");
let MachineAvailabilityService = class MachineAvailabilityService {
    constructor(machineAvailabilityRepository) {
        this.machineAvailabilityRepository = machineAvailabilityRepository;
    }
    async findAll() {
        try {
            console.log('MachineAvailabilityService.findAll: Получение всех станков');
            const machines = await this.machineAvailabilityRepository.find({
                order: {
                    machineName: 'ASC',
                },
            });
            console.log(`MachineAvailabilityService.findAll: Найдено ${machines.length} станков`);
            return machines;
        }
        catch (error) {
            console.error('MachineAvailabilityService.findAll Ошибка:', error);
            throw error;
        }
    }
    async findOne(id) {
        const machine = await this.machineAvailabilityRepository.findOne({
            where: { id },
            relations: ['currentOperation'],
        });
        if (!machine) {
            throw new common_1.NotFoundException(`Станок с ID ${id} не найден`);
        }
        return machine;
    }
    async findByName(machineName) {
        const machine = await this.machineAvailabilityRepository.findOne({
            where: { machineName },
            relations: ['currentOperation'],
        });
        if (!machine) {
            throw new common_1.NotFoundException(`Станок ${machineName} не найден`);
        }
        return machine;
    }
    async updateAvailability(machineName, isAvailable) {
        const machine = await this.findByName(machineName);
        machine.isAvailable = isAvailable;
        if (isAvailable) {
            machine.lastFreedAt = new Date();
            machine.currentOperationId = null;
        }
        return this.machineAvailabilityRepository.save(machine);
    }
    async assignOperation(machineName, operationId) {
        const machine = await this.findByName(machineName);
        machine.isAvailable = false;
        machine.currentOperationId = operationId;
        return this.machineAvailabilityRepository.save(machine);
    }
    async getAvailableMachines() {
        return this.machineAvailabilityRepository.find({
            where: { isAvailable: true },
            order: { machineName: 'ASC' },
        });
    }
    async getCompatibleMachines(operationType) {
        const allMachines = await this.findAll();
        return allMachines.filter(machine => machine.isAvailable && machine.canPerformOperation(operationType));
    }
};
exports.MachineAvailabilityService = MachineAvailabilityService;
exports.MachineAvailabilityService = MachineAvailabilityService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(machine_availability_entity_1.MachineAvailability)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], MachineAvailabilityService);
//# sourceMappingURL=machine-availability.service.js.map