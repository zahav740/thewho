import { MachineAvailabilitySimpleService, MachineAvailabilityDto } from './machine-availability-simple.service';
export declare class MachinesSimpleController {
    private readonly machineAvailabilityService;
    constructor(machineAvailabilityService: MachineAvailabilitySimpleService);
    findAll(): Promise<MachineAvailabilityDto[]>;
    findAvailable(): Promise<MachineAvailabilityDto[]>;
    findByName(machineName: string): Promise<MachineAvailabilityDto>;
    updateAvailability(machineName: string, body: {
        isAvailable: boolean;
    }): Promise<MachineAvailabilityDto>;
    getSuggestedOperations(machineName: string): Promise<any[]>;
    assignOperation(machineName: string, body: {
        operationId: string;
    }): Promise<MachineAvailabilityDto>;
    unassignOperation(machineName: string): Promise<MachineAvailabilityDto>;
}
