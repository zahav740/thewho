"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MachinesSimpleController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const machine_availability_simple_service_1 = require("./machine-availability-simple.service");
let MachinesSimpleController = class MachinesSimpleController {
    constructor(machineAvailabilityService) {
        this.machineAvailabilityService = machineAvailabilityService;
    }
    async findAll() {
        try {
            console.log('MachinesSimpleController.findAll: Запрос всех станков');
            const result = await this.machineAvailabilityService.findAll();
            console.log('MachinesSimpleController.findAll: Успешно получено станков:', result.length);
            return result;
        }
        catch (error) {
            console.error('MachinesSimpleController.findAll: Ошибка:', error);
            throw error;
        }
    }
    async findAvailable() {
        try {
            return await this.machineAvailabilityService.getAvailableMachines();
        }
        catch (error) {
            console.error('MachinesSimpleController.findAvailable: Ошибка:', error);
            throw error;
        }
    }
    async findByName(machineName) {
        try {
            return await this.machineAvailabilityService.findByName(machineName);
        }
        catch (error) {
            console.error('MachinesSimpleController.findByName: Ошибка:', error);
            throw error;
        }
    }
    async updateAvailability(machineName, body) {
        try {
            return await this.machineAvailabilityService.updateAvailability(machineName, body.isAvailable);
        }
        catch (error) {
            console.error('MachinesSimpleController.updateAvailability: Ошибка:', error);
            throw error;
        }
    }
    async getSuggestedOperations(machineName) {
        try {
            return [];
        }
        catch (error) {
            console.error('MachinesSimpleController.getSuggestedOperations: Ошибка:', error);
            throw error;
        }
    }
    async assignOperation(machineName, body) {
        try {
            console.log('MachinesSimpleController.assignOperation: Назначение операции для станка:', machineName, 'операция:', body.operationId);
            return await this.machineAvailabilityService.assignOperation(machineName, body.operationId);
        }
        catch (error) {
            console.error('MachinesSimpleController.assignOperation: Ошибка:', error);
            throw error;
        }
    }
    async unassignOperation(machineName) {
        try {
            console.log('MachinesSimpleController.unassignOperation: Отмена операции для станка:', machineName);
            return await this.machineAvailabilityService.unassignOperation(machineName);
        }
        catch (error) {
            console.error('MachinesSimpleController.unassignOperation: Ошибка:', error);
            throw error;
        }
    }
};
exports.MachinesSimpleController = MachinesSimpleController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Получить все станки с доступностью' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], MachinesSimpleController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('available'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить только доступные станки' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], MachinesSimpleController.prototype, "findAvailable", null);
__decorate([
    (0, common_1.Get)(':machineName'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить станок по имени' }),
    __param(0, (0, common_1.Param)('machineName')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], MachinesSimpleController.prototype, "findByName", null);
__decorate([
    (0, common_1.Put)(':machineName/availability'),
    (0, swagger_1.ApiOperation)({ summary: 'Обновить доступность станка' }),
    __param(0, (0, common_1.Param)('machineName')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], MachinesSimpleController.prototype, "updateAvailability", null);
__decorate([
    (0, common_1.Get)(':machineName/suggested-operations'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить рекомендуемые операции для станка' }),
    __param(0, (0, common_1.Param)('machineName')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], MachinesSimpleController.prototype, "getSuggestedOperations", null);
__decorate([
    (0, common_1.Post)(':machineName/assign-operation'),
    (0, swagger_1.ApiOperation)({ summary: 'Назначить операцию на станок' }),
    __param(0, (0, common_1.Param)('machineName')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], MachinesSimpleController.prototype, "assignOperation", null);
__decorate([
    (0, common_1.Delete)(':machineName/assign-operation'),
    (0, swagger_1.ApiOperation)({ summary: 'Отменить назначение операции на станок' }),
    __param(0, (0, common_1.Param)('machineName')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], MachinesSimpleController.prototype, "unassignOperation", null);
exports.MachinesSimpleController = MachinesSimpleController = __decorate([
    (0, swagger_1.ApiTags)('machines-simple'),
    (0, common_1.Controller)('machines'),
    __metadata("design:paramtypes", [machine_availability_simple_service_1.MachineAvailabilitySimpleService])
], MachinesSimpleController);
//# sourceMappingURL=machines-simple.controller.js.map