import { Repository } from 'typeorm';
import { Machine } from '../../database/entities/machine.entity';
import { Operation } from '../../database/entities/operation.entity';
interface MachineWithStatus {
    id: string;
    machineName: string;
    machineType: string;
    isAvailable: boolean;
    isOccupied: boolean;
    currentOperation?: any;
    currentOperationDetails?: any;
    lastFreedAt?: Date;
    status: 'working' | 'setup' | 'idle' | 'maintenance';
    createdAt: string;
    updatedAt: string;
}
export declare class MachinesStatusController {
    private readonly machineRepository;
    private readonly operationRepository;
    private readonly logger;
    constructor(machineRepository: Repository<Machine>, operationRepository: Repository<Operation>);
    getAllMachinesWithStatus(includeInactive?: boolean): Promise<MachineWithStatus[]>;
    getFreeMachines(): Promise<MachineWithStatus[]>;
    getBusyMachines(): Promise<MachineWithStatus[]>;
}
export {};
