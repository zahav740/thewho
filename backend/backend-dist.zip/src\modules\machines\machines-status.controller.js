"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var MachinesStatusController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MachinesStatusController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const machine_entity_1 = require("../../database/entities/machine.entity");
const operation_entity_1 = require("../../database/entities/operation.entity");
let MachinesStatusController = MachinesStatusController_1 = class MachinesStatusController {
    constructor(machineRepository, operationRepository) {
        this.machineRepository = machineRepository;
        this.operationRepository = operationRepository;
        this.logger = new common_1.Logger(MachinesStatusController_1.name);
    }
    async getAllMachinesWithStatus(includeInactive = false) {
        try {
            this.logger.log('Получение актуального статуса всех станков');
            const machines = await this.machineRepository.find({
                where: includeInactive ? {} : { isActive: true }
            });
            const activeOperations = await this.operationRepository.find({
                where: [
                    { status: 'IN_PROGRESS' },
                    { status: 'ASSIGNED' }
                ],
                relations: ['order']
            });
            const operationsByMachine = new Map();
            activeOperations.forEach(operation => {
                if (operation.assignedMachine) {
                    operationsByMachine.set(operation.assignedMachine, operation);
                }
            });
            const result = machines.map(machine => {
                const assignedOperation = operationsByMachine.get(machine.id);
                let status = 'idle';
                let isAvailable = true;
                if (assignedOperation) {
                    isAvailable = false;
                    status = assignedOperation.status === 'IN_PROGRESS' ? 'working' : 'setup';
                }
                else {
                    isAvailable = true;
                    status = 'idle';
                }
                if (machine.isOccupied !== !isAvailable) {
                    this.machineRepository.update(machine.id, {
                        isOccupied: !isAvailable,
                        currentOperation: assignedOperation?.id || null,
                        updatedAt: new Date()
                    });
                }
                const machineWithStatus = {
                    id: machine.id.toString(),
                    machineName: machine.code,
                    machineType: machine.type,
                    isAvailable,
                    isOccupied: !isAvailable,
                    currentOperation: assignedOperation?.id?.toString(),
                    currentOperationDetails: assignedOperation ? {
                        id: assignedOperation.id,
                        operationNumber: assignedOperation.operationNumber,
                        operationType: assignedOperation.operationType,
                        estimatedTime: assignedOperation.estimatedTime,
                        orderId: assignedOperation.orderId,
                        orderDrawingNumber: assignedOperation.order?.drawingNumber || 'Неизвестно',
                        status: assignedOperation.status
                    } : null,
                    lastFreedAt: machine.assignedAt ? new Date(machine.assignedAt) : undefined,
                    status,
                    createdAt: machine.createdAt.toISOString(),
                    updatedAt: machine.updatedAt.toISOString(),
                };
                return machineWithStatus;
            });
            this.logger.log(`Получено ${result.length} станков, ${result.filter(m => !m.isAvailable).length} заняты`);
            return result;
        }
        catch (error) {
            this.logger.error('Ошибка при получении статуса станков:', error);
            throw error;
        }
    }
    async getFreeMachines() {
        const allMachines = await this.getAllMachinesWithStatus();
        return allMachines.filter(machine => machine.isAvailable);
    }
    async getBusyMachines() {
        const allMachines = await this.getAllMachinesWithStatus();
        return allMachines.filter(machine => !machine.isAvailable);
    }
};
exports.MachinesStatusController = MachinesStatusController;
__decorate([
    (0, common_1.Get)('all'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить актуальный статус всех станков с операциями' }),
    __param(0, (0, common_1.Query)('includeInactive')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Boolean]),
    __metadata("design:returntype", Promise)
], MachinesStatusController.prototype, "getAllMachinesWithStatus", null);
__decorate([
    (0, common_1.Get)('free'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить только свободные станки' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], MachinesStatusController.prototype, "getFreeMachines", null);
__decorate([
    (0, common_1.Get)('busy'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить только занятые станки' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], MachinesStatusController.prototype, "getBusyMachines", null);
exports.MachinesStatusController = MachinesStatusController = MachinesStatusController_1 = __decorate([
    (0, swagger_1.ApiTags)('machines-status'),
    (0, common_1.Controller)('machines/status'),
    __param(0, (0, typeorm_1.InjectRepository)(machine_entity_1.Machine)),
    __param(1, (0, typeorm_1.InjectRepository)(operation_entity_1.Operation)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository])
], MachinesStatusController);
//# sourceMappingURL=machines-status.controller.js.map