import { DataSource } from 'typeorm';
import { MachinesService } from './machines.service';
import { CreateMachineDto } from './dto/create-machine.dto';
import { UpdateMachineDto } from './dto/update-machine.dto';
import { Machine } from '../../database/entities/machine.entity';
interface MachineAvailability {
    id: string;
    machineName: string;
    machineType: string;
    isAvailable: boolean;
    currentOperationId?: string;
    lastFreedAt?: Date;
    currentOperationDetails?: {
        id: number;
        operationNumber: number;
        operationType: string;
        estimatedTime: number;
        orderId: number;
        orderDrawingNumber: string;
        orderQuantity: number;
        producedQuantity: number;
        isCompleted?: boolean;
    };
    shiftProgress?: {
        totalProduced: number;
        remainingQuantity: number;
        completionPercentage: number;
        lastUpdateDate: Date;
    };
    createdAt: string;
    updatedAt: string;
}
export declare class MachinesController {
    private readonly machinesService;
    private readonly dataSource;
    private readonly logger;
    constructor(machinesService: MachinesService, dataSource: DataSource);
    private getOperationDetails;
    private getShiftProgress;
    findAll(): Promise<MachineAvailability[]>;
    findAvailable(): Promise<MachineAvailability[]>;
    findByName(machineName: string): Promise<MachineAvailability>;
    updateAvailability(machineName: string, body: {
        isAvailable: boolean;
    }): Promise<MachineAvailability>;
    unassignOperation(machineName: string): Promise<MachineAvailability>;
    assignOperation(machineName: string, body: {
        operationId: string;
    }): Promise<MachineAvailability>;
    findAllLegacy(): Promise<Machine[]>;
    findOne(id: string): Promise<Machine>;
    create(createMachineDto: CreateMachineDto): Promise<Machine>;
    update(id: string, updateMachineDto: UpdateMachineDto): Promise<Machine>;
    toggleOccupancy(id: string): Promise<Machine>;
    remove(id: string): Promise<void>;
}
export {};
