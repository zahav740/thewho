"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var MachinesController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MachinesController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const machines_service_1 = require("./machines.service");
const create_machine_dto_1 = require("./dto/create-machine.dto");
const update_machine_dto_1 = require("./dto/update-machine.dto");
let MachinesController = MachinesController_1 = class MachinesController {
    constructor(machinesService, dataSource) {
        this.machinesService = machinesService;
        this.dataSource = dataSource;
        this.logger = new common_1.Logger(MachinesController_1.name);
    }
    async getOperationDetails(operationId) {
        try {
            const result = await this.dataSource.query(`
        SELECT 
          op.id,
          op."operationNumber",
          op.operationtype as "operationType",
          op."estimatedTime",
          op."orderId",
          op."actualQuantity",
          ord.drawing_number as "orderDrawingNumber",
          ord.quantity as "orderQuantity"
        FROM operations op
        LEFT JOIN orders ord ON op."orderId" = ord.id
        WHERE op.id = $1
      `, [operationId]);
            return result[0] || null;
        }
        catch (error) {
            this.logger.error(`Ошибка при получении данных операции ${operationId}:`, error);
            return null;
        }
    }
    async getShiftProgress(operationId, machineId) {
        try {
            const result = await this.dataSource.query(`
        SELECT 
          COALESCE(SUM(COALESCE("dayShiftQuantity", 0) + COALESCE("nightShiftQuantity", 0)), 0) as "totalProduced",
          MAX(date) as "lastUpdateDate",
          COUNT(*) as "shiftRecordsCount"
        FROM shift_records 
        WHERE "operationId" = $1 AND "machineId" = $2 AND archived = false
      `, [operationId, machineId]);
            return result[0] || { totalProduced: 0, lastUpdateDate: null, shiftRecordsCount: 0 };
        }
        catch (error) {
            this.logger.error(`Ошибка при получении прогресса смен для операции ${operationId}:`, error);
            return { totalProduced: 0, lastUpdateDate: null, shiftRecordsCount: 0 };
        }
    }
    async checkOperationCompletion(machineName) {
        try {
            this.logger.log(`🔍 Проверка завершения операции на станке: ${machineName}`);
            const machines = await this.machinesService.findAll();
            const machine = machines.find(m => m.code === machineName);
            if (!machine || !machine.currentOperation) {
                return {
                    isCompleted: false,
                    totalProduced: 0,
                    targetQuantity: 0,
                    remainingQuantity: 0,
                    completionPercentage: 0,
                    canComplete: false
                };
            }
            const operationDetails = await this.getOperationDetails(machine.currentOperation);
            if (!operationDetails) {
                throw new common_1.BadRequestException('Операция не найдена');
            }
            const shiftProgress = await this.getShiftProgress(machine.currentOperation, machine.id);
            const totalProduced = shiftProgress.totalProduced || operationDetails.actualQuantity || 0;
            const targetQuantity = operationDetails.orderQuantity || 0;
            const remainingQuantity = Math.max(0, targetQuantity - totalProduced);
            const completionPercentage = targetQuantity > 0 ? Math.round((totalProduced / targetQuantity) * 100) : 0;
            const isCompleted = totalProduced >= targetQuantity && targetQuantity > 0;
            const canComplete = totalProduced > 0;
            this.logger.log(`📊 Прогресс операции ${machine.currentOperation}: ${totalProduced}/${targetQuantity} (${completionPercentage}%)`);
            return {
                isCompleted,
                totalProduced,
                targetQuantity,
                remainingQuantity,
                completionPercentage,
                canComplete
            };
        }
        catch (error) {
            this.logger.error(`Ошибка при проверке завершения операции на станке ${machineName}:`, error);
            throw error;
        }
    }
    async completeOperation(machineName, body) {
        try {
            this.logger.log(`🏁 Завершение операции на станке ${machineName}, действие: ${body.action}`);
            const machines = await this.machinesService.findAll();
            const machine = machines.find(m => m.code === machineName);
            if (!machine || !machine.currentOperation) {
                throw new common_1.BadRequestException('У станка нет активной операции');
            }
            const operationId = machine.currentOperation;
            const operationDetails = await this.getOperationDetails(operationId);
            const shiftProgress = await this.getShiftProgress(operationId, machine.id);
            if (!operationDetails) {
                throw new common_1.BadRequestException('Операция не найдена');
            }
            const totalProduced = shiftProgress.totalProduced || operationDetails.actualQuantity || 0;
            if (body.action === 'complete') {
                this.logger.log(`✅ Завершаем операцию ${operationId} полностью`);
                await this.dataSource.query(`
          UPDATE operations 
          SET 
            status = 'COMPLETED',
            "completedAt" = NOW(),
            "actualQuantity" = $1,
            "assignedMachine" = NULL,
            "assignedAt" = NULL
          WHERE id = $2
        `, [totalProduced, operationId]);
                await this.dataSource.query(`
          UPDATE shift_records 
          SET 
            archived = true,
            "archivedAt" = NOW()
          WHERE "operationId" = $1 AND "machineId" = $2 AND archived = false
        `, [operationId, machine.id]);
                try {
                    await this.dataSource.query(`
            INSERT INTO operation_history 
            (operation_id, machine_id, drawing_number, quantity_completed, completed_at, operation_type, estimated_time, actual_time)
            VALUES ($1, $2, $3, $4, NOW(), $5, $6, 
              EXTRACT(EPOCH FROM (NOW() - $7)) / 60
            )
          `, [
                        operationId,
                        machine.id,
                        operationDetails.orderDrawingNumber,
                        totalProduced,
                        operationDetails.operationType,
                        operationDetails.estimatedTime,
                        machine.assignedAt
                    ]);
                    this.logger.log(`📚 Операция сохранена в историю`);
                }
                catch (historyError) {
                    this.logger.warn('Не удалось сохранить в историю операций:', historyError);
                }
                const updatedMachine = await this.machinesService.update(machine.id, {
                    isOccupied: false,
                    currentOperation: null,
                    assignedAt: new Date(),
                });
                this.logger.log(`🎉 Операция ${operationId} завершена, станок ${machineName} освобожден`);
                return {
                    id: updatedMachine.id.toString(),
                    machineName: updatedMachine.code,
                    machineType: updatedMachine.type,
                    isAvailable: true,
                    currentOperationId: undefined,
                    lastFreedAt: updatedMachine.assignedAt,
                    currentOperationDetails: null,
                    createdAt: updatedMachine.createdAt.toISOString(),
                    updatedAt: updatedMachine.updatedAt.toISOString(),
                };
            }
            else if (body.action === 'continue') {
                this.logger.log(`🔄 Продолжаем работу над операцией ${operationId}`);
            }
            else if (body.action === 'plan_new') {
                this.logger.log(`📋 Планируем новую операцию, сбрасываем текущий прогресс`);
                await this.dataSource.query(`
          UPDATE shift_records 
          SET 
            "resetAt" = NOW(),
            archived = true,
            "archivedAt" = NOW()
          WHERE "operationId" = $1 AND "machineId" = $2 AND archived = false
        `, [operationId, machine.id]);
                await this.dataSource.query(`
          UPDATE operations 
          SET 
            status = 'PENDING',
            "assignedMachine" = NULL,
            "assignedAt" = NULL
          WHERE id = $1
        `, [operationId]);
                const updatedMachine = await this.machinesService.update(machine.id, {
                    isOccupied: false,
                    currentOperation: null,
                    assignedAt: new Date(),
                });
                return {
                    id: updatedMachine.id.toString(),
                    machineName: updatedMachine.code,
                    machineType: updatedMachine.type,
                    isAvailable: true,
                    currentOperationId: undefined,
                    lastFreedAt: updatedMachine.assignedAt,
                    currentOperationDetails: null,
                    createdAt: updatedMachine.createdAt.toISOString(),
                    updatedAt: updatedMachine.updatedAt.toISOString(),
                };
            }
            const currentOperationDetails = await this.getOperationDetails(operationId);
            const currentShiftProgress = await this.getShiftProgress(operationId, machine.id);
            return {
                id: machine.id.toString(),
                machineName: machine.code,
                machineType: machine.type,
                isAvailable: false,
                currentOperationId: operationId.toString(),
                lastFreedAt: machine.assignedAt,
                currentOperationDetails: currentOperationDetails ? {
                    ...currentOperationDetails,
                    producedQuantity: currentShiftProgress.totalProduced || 0
                } : null,
                shiftProgress: {
                    totalProduced: currentShiftProgress.totalProduced || 0,
                    remainingQuantity: Math.max(0, (currentOperationDetails?.orderQuantity || 0) - (currentShiftProgress.totalProduced || 0)),
                    completionPercentage: Math.round(((currentShiftProgress.totalProduced || 0) / (currentOperationDetails?.orderQuantity || 1)) * 100),
                    lastUpdateDate: currentShiftProgress.lastUpdateDate
                },
                createdAt: machine.createdAt.toISOString(),
                updatedAt: machine.updatedAt.toISOString(),
            };
        }
        catch (error) {
            this.logger.error(`🚫 Ошибка при завершении операции на станке ${machineName}:`, error);
            throw error;
        }
    }
    async findAll() {
        try {
            this.logger.log('Получение всех станков с реальными данными операций и прогрессом');
            const machines = await this.machinesService.findAll();
            const result = await Promise.all(machines.map(async (machine) => {
                let currentOperationDetails = null;
                let shiftProgress = null;
                if (machine.currentOperation) {
                    this.logger.log(`Получение деталей операции ${machine.currentOperation} для станка ${machine.code}`);
                    currentOperationDetails = await this.getOperationDetails(machine.currentOperation);
                    const shiftData = await this.getShiftProgress(machine.currentOperation, machine.id);
                    if (currentOperationDetails) {
                        const totalProduced = shiftData.totalProduced || currentOperationDetails.actualQuantity || 0;
                        const targetQuantity = currentOperationDetails.orderQuantity || 0;
                        currentOperationDetails.producedQuantity = totalProduced;
                        currentOperationDetails.isCompleted = totalProduced >= targetQuantity && targetQuantity > 0;
                        shiftProgress = {
                            totalProduced,
                            remainingQuantity: Math.max(0, targetQuantity - totalProduced),
                            completionPercentage: targetQuantity > 0 ? Math.round((totalProduced / targetQuantity) * 100) : 0,
                            lastUpdateDate: shiftData.lastUpdateDate
                        };
                        this.logger.log(`✅ Операция ${currentOperationDetails.operationNumber}: ${totalProduced}/${targetQuantity} (${shiftProgress.completionPercentage}%)`);
                    }
                    else {
                        this.logger.warn(`❌ Операция ${machine.currentOperation} не найдена в БД`);
                    }
                }
                return {
                    id: machine.id.toString(),
                    machineName: machine.code,
                    machineType: machine.type,
                    isAvailable: !machine.isOccupied,
                    currentOperationId: machine.currentOperation?.toString(),
                    lastFreedAt: machine.assignedAt,
                    currentOperationDetails,
                    shiftProgress,
                    createdAt: machine.createdAt.toISOString(),
                    updatedAt: machine.updatedAt.toISOString(),
                };
            }));
            this.logger.log(`Возвращено ${result.length} станков с реальными данными операций и прогрессом`);
            return result;
        }
        catch (error) {
            this.logger.error('Ошибка при получении станков:', error);
            throw error;
        }
    }
    async findAvailable() {
        try {
            this.logger.log('Получение доступных станков');
            const machines = await this.machinesService.findAll();
            const availableMachines = machines.filter(machine => machine.isActive && !machine.isOccupied);
            const result = availableMachines.map(machine => ({
                id: machine.id.toString(),
                machineName: machine.code,
                machineType: machine.type,
                isAvailable: true,
                currentOperationId: machine.currentOperation?.toString(),
                lastFreedAt: machine.assignedAt,
                currentOperationDetails: null,
                createdAt: machine.createdAt.toISOString(),
                updatedAt: machine.updatedAt.toISOString(),
            }));
            this.logger.log(`Возвращено ${result.length} доступных станков`);
            return result;
        }
        catch (error) {
            this.logger.error('Ошибка при получении доступных станков:', error);
            throw error;
        }
    }
    async findByName(machineName) {
        try {
            this.logger.log(`Поиск станка по имени: ${machineName}`);
            const machines = await this.machinesService.findAll();
            const machine = machines.find(m => m.code === machineName);
            if (!machine) {
                throw new common_1.BadRequestException(`Станок с именем ${machineName} не найден`);
            }
            let currentOperationDetails = null;
            let shiftProgress = null;
            if (machine.currentOperation) {
                currentOperationDetails = await this.getOperationDetails(machine.currentOperation);
                const shiftData = await this.getShiftProgress(machine.currentOperation, machine.id);
                if (currentOperationDetails) {
                    const totalProduced = shiftData.totalProduced || currentOperationDetails.actualQuantity || 0;
                    const targetQuantity = currentOperationDetails.orderQuantity || 0;
                    currentOperationDetails.producedQuantity = totalProduced;
                    currentOperationDetails.isCompleted = totalProduced >= targetQuantity && targetQuantity > 0;
                    shiftProgress = {
                        totalProduced,
                        remainingQuantity: Math.max(0, targetQuantity - totalProduced),
                        completionPercentage: targetQuantity > 0 ? Math.round((totalProduced / targetQuantity) * 100) : 0,
                        lastUpdateDate: shiftData.lastUpdateDate
                    };
                }
            }
            return {
                id: machine.id.toString(),
                machineName: machine.code,
                machineType: machine.type,
                isAvailable: !machine.isOccupied,
                currentOperationId: machine.currentOperation?.toString(),
                lastFreedAt: machine.assignedAt,
                currentOperationDetails,
                shiftProgress,
                createdAt: machine.createdAt.toISOString(),
                updatedAt: machine.updatedAt.toISOString(),
            };
        }
        catch (error) {
            this.logger.error(`Ошибка при поиске станка ${machineName}:`, error);
            throw error;
        }
    }
    async updateAvailability(machineName, body) {
        try {
            this.logger.log(`Начало обновления доступности станка:`);
            this.logger.log(`  - machineName: ${machineName}`);
            this.logger.log(`  - isAvailable: ${body.isAvailable}`);
            const machines = await this.machinesService.findAll();
            this.logger.log(`Получено ${machines.length} станков из БД`);
            const machine = machines.find(m => m.code === machineName);
            if (!machine) {
                this.logger.error(`Станок с именем "${machineName}" не найден`);
                this.logger.log('Доступные станки:', machines.map(m => m.code));
                throw new common_1.BadRequestException(`Станок с именем ${machineName} не найден`);
            }
            this.logger.log(`Найден станок: ${machine.code} (ID: ${machine.id})`);
            const updateData = {
                isOccupied: !body.isAvailable
            };
            if (body.isAvailable) {
                if (machine.currentOperation) {
                    const completionCheck = await this.checkOperationCompletion(machineName);
                    if (completionCheck.isCompleted) {
                        this.logger.log('🎯 Операция завершена, автоматически сохраняем в историю');
                        return await this.completeOperation(machineName, { action: 'complete' });
                    }
                }
                updateData.currentOperation = null;
                updateData.assignedAt = null;
                this.logger.log('Очищаем текущую операцию (станок освобождается)');
            }
            else {
                updateData.assignedAt = new Date();
                this.logger.log('Отмечаем станок как занятый');
            }
            this.logger.log('Данные для обновления:', updateData);
            const updatedMachine = await this.machinesService.update(machine.id, updateData);
            this.logger.log('Станок успешно обновлён');
            let currentOperationDetails = null;
            if (updatedMachine.currentOperation) {
                currentOperationDetails = await this.getOperationDetails(updatedMachine.currentOperation);
            }
            const result = {
                id: updatedMachine.id.toString(),
                machineName: updatedMachine.code,
                machineType: updatedMachine.type,
                isAvailable: !updatedMachine.isOccupied,
                currentOperationId: updatedMachine.currentOperation?.toString(),
                lastFreedAt: updatedMachine.assignedAt,
                currentOperationDetails,
                createdAt: updatedMachine.createdAt.toISOString(),
                updatedAt: updatedMachine.updatedAt.toISOString(),
            };
            this.logger.log(`Успешно обновлена доступность станка ${machineName}`);
            return result;
        }
        catch (error) {
            this.logger.error(`Ошибка при обновлении доступности станка ${machineName}:`, error);
            throw error;
        }
    }
    async unassignOperation(machineName) {
        try {
            this.logger.log(`🗑️ Начало корректной отмены операции со станка: ${machineName}`);
            const machines = await this.machinesService.findAll();
            const machine = machines.find(m => m.code === machineName);
            if (!machine) {
                this.logger.error(`❌ Станок с именем "${machineName}" не найден`);
                throw new common_1.BadRequestException(`Станок с именем ${machineName} не найден`);
            }
            const currentOperationId = machine.currentOperation;
            this.logger.log(`🔧 Текущая операция: ${currentOperationId || 'нет'}`);
            const updateData = {
                isOccupied: false,
                currentOperation: null,
                assignedAt: new Date(),
            };
            const updatedMachine = await this.machinesService.update(machine.id, updateData);
            this.logger.log('✅ Станок успешно освобожден');
            if (currentOperationId) {
                try {
                    await this.dataSource.query(`
            UPDATE operations 
            SET status = 'PENDING', "assignedMachine" = NULL, "assignedAt" = NULL
            WHERE id = $1
          `, [currentOperationId]);
                    this.logger.log(`✅ Операция ${currentOperationId} возвращена в статус PENDING`);
                }
                catch (dbError) {
                    this.logger.error(`❌ Ошибка при обновлении статуса операции:`, dbError);
                }
            }
            const result = {
                id: updatedMachine.id.toString(),
                machineName: updatedMachine.code,
                machineType: updatedMachine.type,
                isAvailable: true,
                currentOperationId: undefined,
                lastFreedAt: updatedMachine.assignedAt,
                currentOperationDetails: null,
                createdAt: updatedMachine.createdAt.toISOString(),
                updatedAt: updatedMachine.updatedAt.toISOString(),
            };
            this.logger.log(`🎉 Отмена операции со станка ${machineName} завершена успешно`);
            return result;
        }
        catch (error) {
            this.logger.error(`🚫 Ошибка при отмене операции со станка ${machineName}:`, error);
            throw error;
        }
    }
    async assignOperation(machineName, body) {
        try {
            this.logger.log(`Назначение операции ${body.operationId} на станок ${machineName}`);
            const machines = await this.machinesService.findAll();
            const machine = machines.find(m => m.code === machineName);
            if (!machine) {
                throw new common_1.BadRequestException(`Станок с именем ${machineName} не найден`);
            }
            const operationId = parseInt(body.operationId);
            const operationDetails = await this.getOperationDetails(operationId);
            if (!operationDetails) {
                throw new common_1.BadRequestException(`Операция с ID ${operationId} не найдена`);
            }
            const updatedMachine = await this.machinesService.update(machine.id, {
                isOccupied: true,
                currentOperation: operationId,
                assignedAt: new Date(),
            });
            try {
                await this.dataSource.query(`
          UPDATE operations 
          SET status = 'IN_PROGRESS', "assignedMachine" = $1, "assignedAt" = NOW()
          WHERE id = $2
        `, [machine.id, operationId]);
                this.logger.log(`✅ Операция ${operationId} назначена на станок ${machineName}`);
            }
            catch (dbError) {
                this.logger.error('Ошибка при обновлении статуса операции:', dbError);
            }
            return {
                id: updatedMachine.id.toString(),
                machineName: updatedMachine.code,
                machineType: updatedMachine.type,
                isAvailable: false,
                currentOperationId: updatedMachine.currentOperation?.toString(),
                lastFreedAt: updatedMachine.assignedAt,
                currentOperationDetails: {
                    ...operationDetails,
                    producedQuantity: 0
                },
                createdAt: updatedMachine.createdAt.toISOString(),
                updatedAt: updatedMachine.updatedAt.toISOString(),
            };
        }
        catch (error) {
            this.logger.error(`Ошибка при назначении операции на станок ${machineName}:`, error);
            throw error;
        }
    }
    async findAllLegacy() {
        try {
            return await this.machinesService.findAll();
        }
        catch (error) {
            this.logger.error('Ошибка в findAllLegacy:', error);
            throw error;
        }
    }
    async findOne(id) {
        return this.machinesService.findOne(+id);
    }
    async create(createMachineDto) {
        return this.machinesService.create(createMachineDto);
    }
    async update(id, updateMachineDto) {
        return this.machinesService.update(+id, updateMachineDto);
    }
    async toggleOccupancy(id) {
        return this.machinesService.toggleOccupancy(+id);
    }
    async remove(id) {
        return this.machinesService.remove(+id);
    }
};
exports.MachinesController = MachinesController;
__decorate([
    (0, common_1.Get)(':machineName/operation-completion'),
    (0, swagger_1.ApiOperation)({ summary: 'Проверить завершение операции на станке' }),
    __param(0, (0, common_1.Param)('machineName')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], MachinesController.prototype, "checkOperationCompletion", null);
__decorate([
    (0, common_1.Post)(':machineName/complete-operation'),
    (0, swagger_1.ApiOperation)({ summary: 'Завершить операцию на станке полностью' }),
    __param(0, (0, common_1.Param)('machineName')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], MachinesController.prototype, "completeOperation", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Получить все станки с доступностью и прогрессом' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], MachinesController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('available'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить только доступные станки' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], MachinesController.prototype, "findAvailable", null);
__decorate([
    (0, common_1.Get)(':machineName'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить станок по имени с прогрессом' }),
    __param(0, (0, common_1.Param)('machineName')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], MachinesController.prototype, "findByName", null);
__decorate([
    (0, common_1.Put)(':machineName/availability'),
    (0, swagger_1.ApiOperation)({ summary: 'Обновить доступность станка' }),
    __param(0, (0, common_1.Param)('machineName')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], MachinesController.prototype, "updateAvailability", null);
__decorate([
    (0, common_1.Delete)(':machineName/assign-operation'),
    (0, swagger_1.ApiOperation)({ summary: 'Отменить операцию со станка (с корректной очисткой)' }),
    __param(0, (0, common_1.Param)('machineName')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], MachinesController.prototype, "unassignOperation", null);
__decorate([
    (0, common_1.Post)(':machineName/assign-operation'),
    (0, swagger_1.ApiOperation)({ summary: 'Назначить операцию на станок' }),
    __param(0, (0, common_1.Param)('machineName')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], MachinesController.prototype, "assignOperation", null);
__decorate([
    (0, common_1.Get)('legacy'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить все станки (legacy)' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], MachinesController.prototype, "findAllLegacy", null);
__decorate([
    (0, common_1.Get)('legacy/:id'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить станок по ID (legacy)' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], MachinesController.prototype, "findOne", null);
__decorate([
    (0, common_1.Post)('legacy'),
    (0, swagger_1.ApiOperation)({ summary: 'Создать новый станок (legacy)' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_machine_dto_1.CreateMachineDto]),
    __metadata("design:returntype", Promise)
], MachinesController.prototype, "create", null);
__decorate([
    (0, common_1.Put)('legacy/:id'),
    (0, swagger_1.ApiOperation)({ summary: 'Обновить станок (legacy)' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_machine_dto_1.UpdateMachineDto]),
    __metadata("design:returntype", Promise)
], MachinesController.prototype, "update", null);
__decorate([
    (0, common_1.Put)('legacy/:id/toggle'),
    (0, swagger_1.ApiOperation)({ summary: 'Переключить статус занятости станка (legacy)' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], MachinesController.prototype, "toggleOccupancy", null);
__decorate([
    (0, common_1.Delete)('legacy/:id'),
    (0, swagger_1.ApiOperation)({ summary: 'Удалить станок (legacy)' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], MachinesController.prototype, "remove", null);
exports.MachinesController = MachinesController = MachinesController_1 = __decorate([
    (0, swagger_1.ApiTags)('machines'),
    (0, common_1.Controller)('machines'),
    __param(1, (0, typeorm_1.InjectDataSource)()),
    __metadata("design:paramtypes", [machines_service_1.MachinesService,
        typeorm_2.DataSource])
], MachinesController);
//# sourceMappingURL=machines.controller.enhanced.js.map