export declare class MachinesModule {
}
