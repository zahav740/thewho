import { Repository } from 'typeorm';
import { Machine, MachineType } from '../../database/entities/machine.entity';
import { CreateMachineDto } from './dto/create-machine.dto';
import { UpdateMachineDto } from './dto/update-machine.dto';
export declare class MachinesService {
    private readonly machineRepository;
    constructor(machineRepository: Repository<Machine>);
    findAll(): Promise<Machine[]>;
    findOne(id: number): Promise<Machine>;
    create(createMachineDto: CreateMachineDto): Promise<Machine>;
    update(id: number, updateMachineDto: UpdateMachineDto): Promise<Machine>;
    toggleOccupancy(id: number): Promise<Machine>;
    remove(id: number): Promise<void>;
    findByTypeAndAxes(type: MachineType, minAxes: number): Promise<Machine[]>;
}
