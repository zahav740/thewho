"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MachinesService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const machine_entity_1 = require("../../database/entities/machine.entity");
let MachinesService = class MachinesService {
    constructor(machineRepository) {
        this.machineRepository = machineRepository;
    }
    async findAll() {
        try {
            console.log('MachinesService.findAll: Попытка получить все станки');
            const machines = await this.machineRepository.find({
                order: {
                    code: 'ASC',
                },
            });
            console.log(`MachinesService.findAll: Найдено ${machines.length} станков`);
            return machines;
        }
        catch (error) {
            console.error('MachinesService.findAll Ошибка:', error);
            throw error;
        }
    }
    async findOne(id) {
        const machine = await this.machineRepository.findOne({
            where: { id },
        });
        if (!machine) {
            throw new common_1.NotFoundException(`Станок с ID ${id} не найден`);
        }
        return machine;
    }
    async create(createMachineDto) {
        const machine = this.machineRepository.create(createMachineDto);
        return this.machineRepository.save(machine);
    }
    async update(id, updateMachineDto) {
        try {
            console.log(`MachinesService.update: Обновление станка ID ${id}`);
            console.log('updateMachineDto:', updateMachineDto);
            const machine = await this.findOne(id);
            console.log(`Найден станок: ${machine.code}`);
            if (updateMachineDto.hasOwnProperty('isOccupied')) {
                machine.isOccupied = updateMachineDto.isOccupied;
                console.log(`Обновляем isOccupied: ${updateMachineDto.isOccupied}`);
            }
            if (updateMachineDto.hasOwnProperty('currentOperation')) {
                machine.currentOperation = updateMachineDto.currentOperation;
                console.log(`Обновляем currentOperation: ${updateMachineDto.currentOperation}`);
            }
            if (updateMachineDto.hasOwnProperty('assignedAt')) {
                machine.assignedAt = updateMachineDto.assignedAt;
                console.log(`Обновляем assignedAt: ${updateMachineDto.assignedAt}`);
            }
            Object.assign(machine, updateMachineDto);
            console.log('Сохраняем станок в БД...');
            const result = await this.machineRepository.save(machine);
            console.log('Станок успешно сохранён');
            return result;
        }
        catch (error) {
            console.error(`MachinesService.update Ошибка при обновлении станка ${id}:`, error);
            throw error;
        }
    }
    async toggleOccupancy(id) {
        const machine = await this.findOne(id);
        machine.isOccupied = !machine.isOccupied;
        return this.machineRepository.save(machine);
    }
    async remove(id) {
        const machine = await this.findOne(id);
        await this.machineRepository.remove(machine);
    }
    async findByTypeAndAxes(type, minAxes) {
        return this.machineRepository.find({
            where: {
                type,
                axes: minAxes,
                isActive: true,
            },
        });
    }
};
exports.MachinesService = MachinesService;
exports.MachinesService = MachinesService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(machine_entity_1.Machine)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], MachinesService);
//# sourceMappingURL=machines.service.js.map