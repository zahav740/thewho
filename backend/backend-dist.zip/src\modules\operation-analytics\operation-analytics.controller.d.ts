import { Repository } from 'typeorm';
import { Machine } from '../../database/entities/machine.entity';
import { Operation } from '../../database/entities/operation.entity';
import { Order } from '../../database/entities/order.entity';
import { ShiftRecord } from '../../database/entities/shift-record.entity';
export declare class OperationAnalyticsController {
    private readonly machineRepository;
    private readonly operationRepository;
    private readonly orderRepository;
    private readonly shiftRecordRepository;
    constructor(machineRepository: Repository<Machine>, operationRepository: Repository<Operation>, orderRepository: Repository<Order>, shiftRecordRepository: Repository<ShiftRecord>);
    getMachineOperationAnalytics(machineId: number, startDate?: string, endDate?: string): Promise<{
        status: string;
        message: string;
        machine?: undefined;
        operation?: undefined;
        order?: undefined;
        analytics?: undefined;
        error?: undefined;
    } | {
        status: string;
        machine: {
            id: number;
            code: string;
            type: string;
        };
        operation: {
            id: number;
            operationNumber: number;
            estimatedTime: number;
            status: string;
            createdAt: Date;
        };
        order: {
            id: number;
            drawingNumber: string;
            quantity: number;
            priority: number;
            deadline: Date;
        };
        analytics: {
            progress: {
                totalProduced: number;
                remaining: number;
                progressPercent: number;
                onSchedule: boolean;
                daysOverdue: number;
            };
            timeAnalytics: {
                totalWorkingTime: number;
                totalSetupTime: number;
                averageTimePerUnit: number;
                estimatedCompletion: any;
                workingDaysLeft: number;
                totalDaysWorked: number;
            };
            shiftsData: {
                totalShifts: number;
                setupCount: number;
                averageSetupTime: number;
            };
            operatorAnalytics: any[];
        };
        message?: undefined;
        error?: undefined;
    } | {
        status: string;
        error: any;
        message?: undefined;
        machine?: undefined;
        operation?: undefined;
        order?: undefined;
        analytics?: undefined;
    }>;
    getMachineShifts(machineId: number, startDate?: string, endDate?: string): Promise<{
        status: string;
        shifts: {
            id: number;
            date: string;
            dayShiftQuantity: number;
            nightShiftQuantity: number;
            dayShiftTimePerUnit: string;
            nightShiftTimePerUnit: string;
            dayShiftOperator: string;
            nightShiftOperator: string;
            setupTime: number;
            setupOperator: string;
            operationId: number;
            drawingNumber: string;
        }[];
        error?: undefined;
    } | {
        status: string;
        error: any;
        shifts?: undefined;
    }>;
    private calculateOperationAnalytics;
    private updateOperatorStats;
    private addWorkingDays;
    private calculateWorkingDays;
}
