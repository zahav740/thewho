"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationAnalyticsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const machine_entity_1 = require("../../database/entities/machine.entity");
const operation_entity_1 = require("../../database/entities/operation.entity");
const order_entity_1 = require("../../database/entities/order.entity");
const shift_record_entity_1 = require("../../database/entities/shift-record.entity");
let OperationAnalyticsController = class OperationAnalyticsController {
    constructor(machineRepository, operationRepository, orderRepository, shiftRecordRepository) {
        this.machineRepository = machineRepository;
        this.operationRepository = operationRepository;
        this.orderRepository = orderRepository;
        this.shiftRecordRepository = shiftRecordRepository;
    }
    async getMachineOperationAnalytics(machineId, startDate, endDate) {
        try {
            console.log(`Получение аналитики для станка ${machineId}`);
            const machine = await this.machineRepository.findOne({
                where: { id: machineId }
            });
            if (!machine) {
                return {
                    status: 'error',
                    message: 'Станок не найден'
                };
            }
            const currentOperation = await this.operationRepository.findOne({
                where: {
                    assignedMachine: machineId,
                    status: 'IN_PROGRESS'
                },
                relations: ['order'],
                order: { createdAt: 'DESC' }
            });
            if (!currentOperation || !currentOperation.order) {
                return {
                    status: 'no_operation',
                    message: 'Нет текущей операции на станке'
                };
            }
            const dateFilter = startDate && endDate ? {
                date: (0, typeorm_2.Between)(new Date(startDate), new Date(endDate))
            } : {};
            const shiftRecords = await this.shiftRecordRepository.find({
                where: {
                    machineId: machineId,
                    operationId: currentOperation.id,
                    ...dateFilter
                },
                order: { date: 'ASC' }
            });
            console.log(`Найдено ${shiftRecords.length} записей смен`);
            const analytics = this.calculateOperationAnalytics(currentOperation, currentOperation.order, shiftRecords);
            return {
                status: 'success',
                machine: {
                    id: machine.id,
                    code: machine.code,
                    type: machine.type
                },
                operation: {
                    id: currentOperation.id,
                    operationNumber: currentOperation.operationNumber,
                    estimatedTime: currentOperation.estimatedTime,
                    status: currentOperation.status,
                    createdAt: currentOperation.createdAt
                },
                order: {
                    id: currentOperation.order.id,
                    drawingNumber: currentOperation.order.drawingNumber,
                    quantity: currentOperation.order.quantity,
                    priority: currentOperation.order.priority,
                    deadline: currentOperation.order.deadline
                },
                analytics
            };
        }
        catch (error) {
            console.error('Ошибка получения аналитики операции:', error);
            return {
                status: 'error',
                error: error.message
            };
        }
    }
    async getMachineShifts(machineId, startDate, endDate) {
        try {
            const dateFilter = startDate && endDate ? {
                date: (0, typeorm_2.Between)(new Date(startDate), new Date(endDate))
            } : {};
            const shifts = await this.shiftRecordRepository.find({
                where: {
                    machineId: machineId,
                    ...dateFilter
                },
                relations: ['operation', 'operation.order'],
                order: { date: 'DESC' }
            });
            const formattedShifts = shifts.map(shift => ({
                id: shift.id,
                date: shift.date.toISOString().split('T')[0],
                dayShiftQuantity: shift.dayShiftQuantity || 0,
                nightShiftQuantity: shift.nightShiftQuantity || 0,
                dayShiftTimePerUnit: shift.dayShiftTimePerUnit?.toString() || '0',
                nightShiftTimePerUnit: shift.nightShiftTimePerUnit?.toString() || '0',
                dayShiftOperator: shift.dayShiftOperator || 'Не указан',
                nightShiftOperator: shift.nightShiftOperator || 'Не указан',
                setupTime: shift.setupTime || 0,
                setupOperator: shift.dayShiftOperator || 'Не указан',
                operationId: shift.operationId,
                drawingNumber: shift.operation?.order?.drawingNumber || 'N/A'
            }));
            return {
                status: 'success',
                shifts: formattedShifts
            };
        }
        catch (error) {
            console.error('Ошибка получения смен:', error);
            return {
                status: 'error',
                error: error.message
            };
        }
    }
    calculateOperationAnalytics(operation, order, shifts) {
        let totalProduced = 0;
        let totalWorkingTime = 0;
        let totalSetupTime = 0;
        let totalShifts = 0;
        const operatorStats = new Map();
        shifts.forEach(shift => {
            const dayQuantity = shift.dayShiftQuantity || 0;
            const nightQuantity = shift.nightShiftQuantity || 0;
            const dayTime = shift.dayShiftTimePerUnit || 0;
            const nightTime = shift.nightShiftTimePerUnit || 0;
            totalProduced += dayQuantity + nightQuantity;
            totalWorkingTime += (dayQuantity * dayTime) + (nightQuantity * nightTime);
            totalSetupTime += shift.setupTime || 0;
            if (dayQuantity > 0) {
                totalShifts++;
                this.updateOperatorStats(operatorStats, shift.dayShiftOperator, dayQuantity, dayTime);
            }
            if (nightQuantity > 0) {
                totalShifts++;
                this.updateOperatorStats(operatorStats, shift.nightShiftOperator, nightQuantity, nightTime);
            }
        });
        const progressPercent = order.quantity > 0 ? (totalProduced / order.quantity) * 100 : 0;
        const remaining = Math.max(0, order.quantity - totalProduced);
        const averageTimePerUnit = totalProduced > 0 ? totalWorkingTime / totalProduced : 0;
        let estimatedCompletion = null;
        let workingDaysLeft = 0;
        if (remaining > 0 && averageTimePerUnit > 0) {
            const remainingTimeMinutes = remaining * averageTimePerUnit;
            const workingMinutesPerDay = 16 * 60;
            workingDaysLeft = Math.ceil(remainingTimeMinutes / workingMinutesPerDay);
            estimatedCompletion = this.addWorkingDays(new Date(), workingDaysLeft);
        }
        const now = new Date();
        const deadline = new Date(order.deadline);
        const onSchedule = estimatedCompletion ? estimatedCompletion <= deadline : now <= deadline;
        const operatorAnalytics = Array.from(operatorStats.values());
        return {
            progress: {
                totalProduced,
                remaining,
                progressPercent: Math.round(progressPercent * 10) / 10,
                onSchedule,
                daysOverdue: !onSchedule && estimatedCompletion ?
                    Math.ceil((estimatedCompletion.getTime() - deadline.getTime()) / (1000 * 60 * 60 * 24)) : 0
            },
            timeAnalytics: {
                totalWorkingTime: Math.round(totalWorkingTime),
                totalSetupTime: Math.round(totalSetupTime),
                averageTimePerUnit: Math.round(averageTimePerUnit * 10) / 10,
                estimatedCompletion: estimatedCompletion?.toISOString(),
                workingDaysLeft,
                totalDaysWorked: this.calculateWorkingDays(new Date(operation.createdAt), new Date())
            },
            shiftsData: {
                totalShifts,
                setupCount: shifts.filter(s => s.setupTime && s.setupTime > 0).length,
                averageSetupTime: totalSetupTime > 0 ?
                    Math.round(totalSetupTime / shifts.filter(s => s.setupTime && s.setupTime > 0).length) : 0
            },
            operatorAnalytics
        };
    }
    updateOperatorStats(operatorMap, operatorName, quantity, timePerUnit) {
        if (!operatorName || operatorName === 'Не указан')
            return;
        if (!operatorMap.has(operatorName)) {
            operatorMap.set(operatorName, {
                operatorName,
                totalShifts: 0,
                totalQuantity: 0,
                totalTime: 0,
                averageTimePerUnit: 0,
                efficiency: 0
            });
        }
        const operator = operatorMap.get(operatorName);
        operator.totalShifts++;
        operator.totalQuantity += quantity;
        operator.totalTime += quantity * timePerUnit;
        operator.averageTimePerUnit = operator.totalTime / operator.totalQuantity;
        const standardTime = 20;
        operator.efficiency = Math.round((standardTime / operator.averageTimePerUnit) * 100);
    }
    addWorkingDays(startDate, daysToAdd) {
        const result = new Date(startDate);
        let addedDays = 0;
        while (addedDays < daysToAdd) {
            result.setDate(result.getDate() + 1);
            const dayOfWeek = result.getDay();
            if (dayOfWeek !== 5 && dayOfWeek !== 6) {
                addedDays++;
            }
        }
        return result;
    }
    calculateWorkingDays(startDate, endDate) {
        let count = 0;
        const current = new Date(startDate);
        while (current <= endDate) {
            const dayOfWeek = current.getDay();
            if (dayOfWeek !== 5 && dayOfWeek !== 6) {
                count++;
            }
            current.setDate(current.getDate() + 1);
        }
        return count;
    }
};
exports.OperationAnalyticsController = OperationAnalyticsController;
__decorate([
    (0, common_1.Get)('machine/:machineId'),
    (0, swagger_1.ApiOperation)({ summary: 'Аналитика текущей операции станка' }),
    __param(0, (0, common_1.Param)('machineId')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, String, String]),
    __metadata("design:returntype", Promise)
], OperationAnalyticsController.prototype, "getMachineOperationAnalytics", null);
__decorate([
    (0, common_1.Get)('shifts/:machineId'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить записи смен для станка' }),
    __param(0, (0, common_1.Param)('machineId')),
    __param(1, (0, common_1.Query)('startDate')),
    __param(2, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, String, String]),
    __metadata("design:returntype", Promise)
], OperationAnalyticsController.prototype, "getMachineShifts", null);
exports.OperationAnalyticsController = OperationAnalyticsController = __decorate([
    (0, swagger_1.ApiTags)('operation-analytics'),
    (0, common_1.Controller)('operation-analytics'),
    __param(0, (0, typeorm_1.InjectRepository)(machine_entity_1.Machine)),
    __param(1, (0, typeorm_1.InjectRepository)(operation_entity_1.Operation)),
    __param(2, (0, typeorm_1.InjectRepository)(order_entity_1.Order)),
    __param(3, (0, typeorm_1.InjectRepository)(shift_record_entity_1.ShiftRecord)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], OperationAnalyticsController);
//# sourceMappingURL=operation-analytics.controller.js.map