export declare class OperationAnalyticsModule {
}
