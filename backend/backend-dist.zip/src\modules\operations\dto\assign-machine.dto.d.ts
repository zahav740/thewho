export declare class AssignMachineDto {
    machineId: number;
}
