import { OperationType } from '../../../database/entities/operation.entity';
export declare class CreateOperationDto {
    operationNumber: number;
    operationType: OperationType;
    machineAxes: number;
    estimatedTime: number;
    orderId: number;
}
