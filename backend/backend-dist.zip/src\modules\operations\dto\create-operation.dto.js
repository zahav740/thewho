"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateOperationDto = void 0;
const class_validator_1 = require("class-validator");
const swagger_1 = require("@nestjs/swagger");
const operation_entity_1 = require("../../../database/entities/operation.entity");
class CreateOperationDto {
}
exports.CreateOperationDto = CreateOperationDto;
__decorate([
    (0, swagger_1.ApiProperty)({ example: 1, description: 'Номер операции' }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], CreateOperationDto.prototype, "operationNumber", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ enum: operation_entity_1.OperationType, description: 'Тип операции' }),
    (0, class_validator_1.IsEnum)(operation_entity_1.OperationType),
    __metadata("design:type", String)
], CreateOperationDto.prototype, "operationType", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 3, description: 'Количество осей станка' }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(3),
    __metadata("design:type", Number)
], CreateOperationDto.prototype, "machineAxes", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 120, description: 'Время выполнения в минутах' }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], CreateOperationDto.prototype, "estimatedTime", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 1, description: 'ID заказа' }),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], CreateOperationDto.prototype, "orderId", void 0);
//# sourceMappingURL=create-operation.dto.js.map