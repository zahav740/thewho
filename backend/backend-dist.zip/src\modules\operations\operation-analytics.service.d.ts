import { DataSource } from 'typeorm';
export interface OperationTimeAnalytics {
    operationType: string;
    machineType: string;
    averageTime: number;
    minTime: number;
    maxTime: number;
    completedOperations: number;
    efficiency: number;
    recommendedTime: number;
}
export interface OperationSuggestion {
    operationType: string;
    estimatedTime: number;
    confidence: number;
    basedOnOperations: number;
    basedOnOrders: number;
    lastOrderId: number;
    lastOrderDate: string;
    historicalData: {
        orderId: number;
        quantity: number;
        estimatedTime: number;
        completedAt?: string;
    }[];
}
export declare class OperationAnalyticsService {
    private readonly dataSource;
    constructor(dataSource: DataSource);
    getOperationSuggestions(orderDrawingNumber: string, orderQuantity: number, workType?: string): Promise<OperationSuggestion[]>;
    private groupOperationsByType;
    private analyzeSimilarOperations;
    private calculateWeight;
    private calculateConfidence;
    private getFallbackSuggestions;
    getDrawingHistory(drawingNumber: string): Promise<any[]>;
    getLastCompletedOrder(drawingNumber: string): Promise<any | null>;
    getDrawingStatistics(drawingNumber: string): Promise<any>;
    getOperationTimeAnalytics(operationType?: string, machineType?: string): Promise<OperationTimeAnalytics[]>;
}
