"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationAnalyticsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
let OperationAnalyticsService = class OperationAnalyticsService {
    constructor(dataSource) {
        this.dataSource = dataSource;
    }
    async getOperationSuggestions(orderDrawingNumber, orderQuantity, workType) {
        try {
            console.log(`🔍 Поиск рекомендаций для чертежа: ${orderDrawingNumber}`);
            const historicalOrders = await this.dataSource.query(`
        SELECT DISTINCT
          ord.id as order_id,
          ord.drawing_number,
          ord.quantity,
          ord.priority,
          ord.deadline,
          -- Проверяем завершенность заказа
          CASE 
            WHEN COUNT(op.id) > 0 AND COUNT(CASE WHEN op.status = 'COMPLETED' THEN 1 END) = COUNT(op.id)
            THEN true 
            ELSE false 
          END as is_completed
        FROM orders ord
        LEFT JOIN operations op ON ord.id = op."orderId"
        WHERE ord.drawing_number = $1  -- ТОЧНОЕ совпадение чертежа
        GROUP BY ord.id, ord.drawing_number, ord.quantity, ord.priority, ord.deadline
        HAVING COUNT(op.id) > 0  -- Только заказы с операциями
        ORDER BY ord.id DESC  -- Последние заказы первыми
      `, [orderDrawingNumber]);
            if (historicalOrders.length === 0) {
                console.log(`📋 Нет исторических данных для чертежа ${orderDrawingNumber}`);
                return await this.getFallbackSuggestions(workType);
            }
            console.log(`📊 Найдено ${historicalOrders.length} заказов с чертежом ${orderDrawingNumber}`);
            const historicalOperations = await this.dataSource.query(`
        SELECT 
          op.id,
          op."operationNumber",
          op.operationtype,
          op."estimatedTime",
          op.status,
          ord.id as order_id,
          ord.quantity as order_quantity,
          prog.progress_percentage,
          prog.completed_units,
          op."updatedAt" as completed_at
        FROM operations op
        INNER JOIN orders ord ON op."orderId" = ord.id
        LEFT JOIN operation_execution_progress prog ON op.id = prog.operation_id
        WHERE ord.drawing_number = $1
          AND op.status IN ('COMPLETED', 'IN_PROGRESS', 'ASSIGNED')
        ORDER BY ord.id DESC, op."operationNumber"
      `, [orderDrawingNumber]);
            const operationGroups = this.groupOperationsByType(historicalOperations);
            const suggestions = [];
            for (const [operationType, operations] of Object.entries(operationGroups)) {
                const suggestion = this.analyzeSimilarOperations(operationType, operations, orderQuantity, orderDrawingNumber);
                if (suggestion) {
                    suggestions.push(suggestion);
                }
            }
            return suggestions.sort((a, b) => b.confidence - a.confidence);
        }
        catch (error) {
            console.error('OperationAnalytics.getOperationSuggestions ошибка:', error);
            throw error;
        }
    }
    groupOperationsByType(operations) {
        const groups = {};
        operations.forEach(op => {
            if (!groups[op.operationtype]) {
                groups[op.operationtype] = [];
            }
            groups[op.operationtype].push(op);
        });
        return groups;
    }
    analyzeSimilarOperations(operationType, operations, targetQuantity, drawingNumber) {
        if (operations.length === 0)
            return null;
        const timeAnalysis = operations.map(op => {
            const timePerUnit = op.estimatedTime / (op.order_quantity || 1);
            const estimatedTimeForTarget = timePerUnit * targetQuantity;
            return {
                ...op,
                timePerUnit,
                estimatedTimeForTarget,
                weight: this.calculateWeight(op, targetQuantity)
            };
        });
        const totalWeight = timeAnalysis.reduce((sum, item) => sum + item.weight, 0);
        const weightedAverageTime = timeAnalysis.reduce((sum, item) => sum + (item.estimatedTimeForTarget * item.weight), 0) / totalWeight;
        const confidence = this.calculateConfidence(operations, drawingNumber);
        const lastOperation = operations[0];
        return {
            operationType,
            estimatedTime: Math.round(weightedAverageTime),
            confidence,
            basedOnOperations: operations.length,
            basedOnOrders: new Set(operations.map(op => op.order_id)).size,
            lastOrderId: lastOperation.order_id,
            lastOrderDate: lastOperation.completed_at || 'В процессе',
            historicalData: operations.slice(0, 5).map(op => ({
                orderId: op.order_id,
                quantity: op.order_quantity,
                estimatedTime: op.estimatedTime,
                completedAt: op.status === 'COMPLETED' ? op.completed_at : undefined
            }))
        };
    }
    calculateWeight(operation, targetQuantity) {
        let weight = 1;
        if (operation.status === 'COMPLETED') {
            weight += 0.5;
        }
        const quantityRatio = Math.min(operation.order_quantity / targetQuantity, targetQuantity / operation.order_quantity);
        weight += quantityRatio * 0.3;
        return weight;
    }
    calculateConfidence(operations, drawingNumber) {
        let confidence = 0;
        const operationCount = operations.length;
        confidence += Math.min(operationCount * 15, 60);
        confidence += 30;
        const completedOperations = operations.filter(op => op.status === 'COMPLETED').length;
        confidence += Math.min(completedOperations * 5, 15);
        const uniqueOrders = new Set(operations.map(op => op.order_id)).size;
        if (uniqueOrders > 1) {
            confidence += Math.min(uniqueOrders * 5, 20);
        }
        return Math.min(confidence, 100);
    }
    async getFallbackSuggestions(workType) {
        try {
            const fallbackQuery = workType
                ? `WHERE ord."workType" = $1`
                : '';
            const params = workType ? [workType] : [];
            const avgOperations = await this.dataSource.query(`
        SELECT 
          op.operationtype,
          ROUND(AVG(op."estimatedTime"), 0) as avg_time,
          COUNT(*) as operation_count
        FROM operations op
        INNER JOIN orders ord ON op."orderId" = ord.id
        ${fallbackQuery}
        GROUP BY op.operationtype
        HAVING COUNT(*) >= 2
        ORDER BY operation_count DESC
      `, params);
            return avgOperations.map(avg => ({
                operationType: avg.operationtype,
                estimatedTime: avg.avg_time,
                confidence: Math.min(avg.operation_count * 10, 40),
                basedOnOperations: avg.operation_count,
                basedOnOrders: 0,
                lastOrderId: 0,
                lastOrderDate: 'Общая статистика',
                historicalData: []
            }));
        }
        catch (error) {
            console.error('Ошибка в getFallbackSuggestions:', error);
            return [];
        }
    }
    async getDrawingHistory(drawingNumber) {
        try {
            return await this.dataSource.query(`
        SELECT 
          ord.id as order_id,
          ord.quantity,
          ord.priority,
          ord.deadline,
          op.id as operation_id,
          op."operationNumber",
          op.operationtype,
          op."estimatedTime",
          op.status,
          prog.progress_percentage,
          prog.completed_units,
          prog.total_units,
          CASE 
            WHEN op.status = 'COMPLETED' THEN op."updatedAt"
            ELSE NULL 
          END as completed_at
        FROM orders ord
        LEFT JOIN operations op ON ord.id = op."orderId"
        LEFT JOIN operation_execution_progress prog ON op.id = prog.operation_id
        WHERE ord.drawing_number = $1
        ORDER BY ord.id DESC, op."operationNumber"
      `, [drawingNumber]);
        }
        catch (error) {
            console.error('OperationAnalytics.getDrawingHistory ошибка:', error);
            throw error;
        }
    }
    async getLastCompletedOrder(drawingNumber) {
        try {
            const result = await this.dataSource.query(`
        SELECT 
          ord.id,
          ord.quantity,
          ord.priority,
          COUNT(op.id) as total_operations,
          COUNT(CASE WHEN op.status = 'COMPLETED' THEN 1 END) as completed_operations,
          MAX(op."updatedAt") as last_operation_date
        FROM orders ord
        INNER JOIN operations op ON ord.id = op."orderId"
        WHERE ord.drawing_number = $1
        GROUP BY ord.id, ord.quantity, ord.priority
        HAVING COUNT(op.id) = COUNT(CASE WHEN op.status = 'COMPLETED' THEN 1 END)
        ORDER BY ord.id DESC
        LIMIT 1
      `, [drawingNumber]);
            return result.length > 0 ? result[0] : null;
        }
        catch (error) {
            console.error('OperationAnalytics.getLastCompletedOrder ошибка:', error);
            return null;
        }
    }
    async getDrawingStatistics(drawingNumber) {
        try {
            const stats = await this.dataSource.query(`
        WITH order_stats AS (
          SELECT 
            COUNT(DISTINCT ord.id) as total_orders,
            MIN(ord.quantity) as min_quantity,
            MAX(ord.quantity) as max_quantity,
            ROUND(AVG(ord.quantity), 0) as avg_quantity
          FROM orders ord
          WHERE ord.drawing_number = $1
        ),
        operation_stats AS (
          SELECT 
            COUNT(*) as total_operations,
            COUNT(CASE WHEN op.status = 'COMPLETED' THEN 1 END) as completed_operations,
            ROUND(AVG(op."estimatedTime"), 0) as avg_estimated_time
          FROM operations op
          INNER JOIN orders ord ON op."orderId" = ord.id
          WHERE ord.drawing_number = $1
        )
        SELECT 
          os.*,
          ops.*
        FROM order_stats os
        CROSS JOIN operation_stats ops
      `, [drawingNumber]);
            return stats[0] || {
                total_orders: 0,
                total_operations: 0,
                completed_operations: 0,
                min_quantity: 0,
                max_quantity: 0,
                avg_quantity: 0,
                avg_estimated_time: 0
            };
        }
        catch (error) {
            console.error('OperationAnalytics.getDrawingStatistics ошибка:', error);
            throw error;
        }
    }
    async getOperationTimeAnalytics(operationType, machineType) {
        try {
            let whereClause = 'WHERE op.status = \'COMPLETED\'';
            const params = [];
            if (operationType) {
                whereClause += ' AND op.operationtype = $1';
                params.push(operationType);
            }
            if (machineType) {
                whereClause += ` AND m.type = $${params.length + 1}`;
                params.push(machineType);
            }
            const analytics = await this.dataSource.query(`
        SELECT 
          op.operationtype as "operationType",
          m.type as "machineType",
          ROUND(AVG(op."estimatedTime")::DECIMAL, 2) as "averageTime",
          MIN(op."estimatedTime") as "minTime",
          MAX(op."estimatedTime") as "maxTime",
          COUNT(*) as "completedOperations",
          ROUND(
            (COUNT(CASE WHEN prog.progress_percentage = 100 THEN 1 END)::DECIMAL / COUNT(*)) * 100, 
            2
          ) as "efficiency",
          ROUND(
            AVG(op."estimatedTime") * 
            (COUNT(CASE WHEN prog.progress_percentage = 100 THEN 1 END)::DECIMAL / COUNT(*)), 
            2
          ) as "recommendedTime"
        FROM operations op
        LEFT JOIN machines m ON op."assignedMachine" = m.id
        LEFT JOIN operation_execution_progress prog ON op.id = prog.operation_id
        ${whereClause}
        GROUP BY op.operationtype, m.type
        ORDER BY "completedOperations" DESC
      `, params);
            return analytics;
        }
        catch (error) {
            console.error('OperationAnalytics.getOperationTimeAnalytics ошибка:', error);
            throw error;
        }
    }
};
exports.OperationAnalyticsService = OperationAnalyticsService;
exports.OperationAnalyticsService = OperationAnalyticsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectDataSource)()),
    __metadata("design:paramtypes", [typeorm_2.DataSource])
], OperationAnalyticsService);
//# sourceMappingURL=operation-analytics.service.js.map