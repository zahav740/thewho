import { Repository } from 'typeorm';
import { Operation } from '../../database/entities/operation.entity';
import { ShiftRecord } from '../../database/entities/shift-record.entity';
import { Order } from '../../database/entities/order.entity';
import { Machine } from '../../database/entities/machine.entity';
interface CompletionCheckResult {
    operationId: number;
    isCompleted: boolean;
    completedQuantity: number;
    plannedQuantity: number;
    progress: number;
    orderInfo: {
        drawingNumber: string;
        quantity: number;
    };
    operationInfo: {
        operationNumber: number;
        operationType: string;
    };
}
interface HandleCompletionDto {
    operationId: number;
    action: 'close' | 'continue' | 'plan';
    completedQuantity: number;
}
export declare class OperationCompletionCheckController {
    private readonly operationRepository;
    private readonly shiftRecordRepository;
    private readonly orderRepository;
    private readonly machineRepository;
    private readonly logger;
    constructor(operationRepository: Repository<Operation>, shiftRecordRepository: Repository<ShiftRecord>, orderRepository: Repository<Order>, machineRepository: Repository<Machine>);
    checkOperationCompletion(operationId: number): Promise<CompletionCheckResult>;
    checkAllActiveOperations(): Promise<CompletionCheckResult[]>;
    handleCompletion(dto: HandleCompletionDto): Promise<{
        success: boolean;
        message: string;
        action: string;
        shouldOpenPlanning?: undefined;
        machineId?: undefined;
    } | {
        success: boolean;
        message: string;
        action: string;
        shouldOpenPlanning: boolean;
        machineId: number;
    }>;
    private closeOperation;
}
export {};
