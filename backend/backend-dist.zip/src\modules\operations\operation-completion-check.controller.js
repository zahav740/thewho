"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var OperationCompletionCheckController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationCompletionCheckController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const operation_entity_1 = require("../../database/entities/operation.entity");
const shift_record_entity_1 = require("../../database/entities/shift-record.entity");
const order_entity_1 = require("../../database/entities/order.entity");
const machine_entity_1 = require("../../database/entities/machine.entity");
let OperationCompletionCheckController = OperationCompletionCheckController_1 = class OperationCompletionCheckController {
    constructor(operationRepository, shiftRecordRepository, orderRepository, machineRepository) {
        this.operationRepository = operationRepository;
        this.shiftRecordRepository = shiftRecordRepository;
        this.orderRepository = orderRepository;
        this.machineRepository = machineRepository;
        this.logger = new common_1.Logger(OperationCompletionCheckController_1.name);
    }
    async checkOperationCompletion(operationId) {
        try {
            this.logger.log(`Проверка завершения операции ${operationId}`);
            const operation = await this.operationRepository.findOne({
                where: { id: operationId },
                relations: ['order']
            });
            if (!operation) {
                throw new common_1.BadRequestException('Операция не найдена');
            }
            const shiftRecords = await this.shiftRecordRepository.find({
                where: { operationId: operationId, archived: false }
            });
            const totalCompleted = shiftRecords.reduce((total, record) => {
                const dayShift = record.dayShiftQuantity || 0;
                const nightShift = record.nightShiftQuantity || 0;
                return total + dayShift + nightShift;
            }, 0);
            const plannedQuantity = operation.order?.quantity || 0;
            const progress = plannedQuantity > 0 ? Math.round((totalCompleted / plannedQuantity) * 100) : 0;
            const isCompleted = plannedQuantity > 0 && totalCompleted >= plannedQuantity;
            this.logger.debug(`Проверка операции ${operationId}: выполнено ${totalCompleted}, план ${plannedQuantity}, прогресс ${progress}%, завершено: ${isCompleted}`);
            const result = {
                operationId: operationId,
                isCompleted,
                completedQuantity: totalCompleted,
                plannedQuantity,
                progress,
                orderInfo: {
                    drawingNumber: operation.order?.drawingNumber || 'Неизвестно',
                    quantity: plannedQuantity
                },
                operationInfo: {
                    operationNumber: operation.operationNumber,
                    operationType: operation.operationType || 'Неизвестно'
                }
            };
            this.logger.log(`Результат проверки операции ${operationId}: выполнено ${totalCompleted}/${plannedQuantity}, прогресс ${progress}%, завершено: ${isCompleted}`);
            return result;
        }
        catch (error) {
            this.logger.error('Ошибка при проверке завершения операции:', error);
            throw new common_1.BadRequestException(`Ошибка при проверке завершения: ${error.message}`);
        }
    }
    async checkAllActiveOperations() {
        try {
            this.logger.log('Проверка всех активных операций на завершение');
            const activeOperations = await this.operationRepository.find({
                where: [
                    { status: 'IN_PROGRESS' },
                    { status: 'ASSIGNED' }
                ],
                relations: ['order']
            });
            const results = [];
            for (const operation of activeOperations) {
                try {
                    const checkResult = await this.checkOperationCompletion(operation.id);
                    const isReallyCompleted = checkResult.isCompleted &&
                        checkResult.plannedQuantity > 0 &&
                        checkResult.completedQuantity >= checkResult.plannedQuantity &&
                        checkResult.progress >= 100;
                    if (isReallyCompleted) {
                        this.logger.log(`🎯 Операция ${operation.id} действительно завершена: ${checkResult.completedQuantity}/${checkResult.plannedQuantity}`);
                        results.push(checkResult);
                    }
                    else {
                        this.logger.debug(`⏳ Операция ${operation.id} ещё не завершена: ${checkResult.completedQuantity}/${checkResult.plannedQuantity} (${checkResult.progress}%)`);
                    }
                }
                catch (error) {
                    this.logger.warn(`Ошибка при проверке операции ${operation.id}:`, error);
                }
            }
            this.logger.log(`Найдено ${results.length} ДЕЙСТВИТЕЛЬНО завершенных операций из ${activeOperations.length} активных`);
            return results;
        }
        catch (error) {
            this.logger.error('Ошибка при проверке всех операций:', error);
            throw new common_1.BadRequestException(`Ошибка при проверке операций: ${error.message}`);
        }
    }
    async handleCompletion(dto) {
        try {
            this.logger.log(`Обработка завершения операции ${dto.operationId}, действие: ${dto.action}`);
            const operation = await this.operationRepository.findOne({
                where: { id: dto.operationId },
                relations: ['order']
            });
            if (!operation) {
                throw new common_1.BadRequestException('Операция не найдена');
            }
            switch (dto.action) {
                case 'close':
                    await this.closeOperation(dto.operationId, dto.completedQuantity);
                    return {
                        success: true,
                        message: 'Операция успешно закрыта и данные архивированы',
                        action: 'closed'
                    };
                case 'continue':
                    this.logger.log(`Операция ${dto.operationId} продолжается`);
                    return {
                        success: true,
                        message: 'Операция продолжается, накопление результата не сброшено',
                        action: 'continued'
                    };
                case 'plan':
                    await this.closeOperation(dto.operationId, dto.completedQuantity);
                    return {
                        success: true,
                        message: 'Операция закрыта, готово к планированию новой операции',
                        action: 'planned',
                        shouldOpenPlanning: true,
                        machineId: operation.assignedMachine
                    };
                default:
                    throw new common_1.BadRequestException('Неизвестное действие');
            }
        }
        catch (error) {
            this.logger.error('Ошибка при обработке завершения операции:', error);
            throw new common_1.BadRequestException(`Ошибка при обработке: ${error.message}`);
        }
    }
    async closeOperation(operationId, completedQuantity) {
        const operation = await this.operationRepository.findOne({
            where: { id: operationId }
        });
        if (!operation) {
            throw new Error(`Операция ${operationId} не найдена`);
        }
        await this.operationRepository.update(operationId, {
            status: 'COMPLETED',
            completedAt: new Date(),
            actualQuantity: completedQuantity,
            assignedMachine: null
        });
        if (operation.assignedMachine) {
            await this.machineRepository.update(operation.assignedMachine, {
                isOccupied: false,
                currentOperation: null,
                assignedAt: null,
                updatedAt: new Date()
            });
            this.logger.log(`Станок ${operation.assignedMachine} освобожден`);
        }
        await this.shiftRecordRepository.update({ operationId: operationId }, {
            archived: true,
            archivedAt: new Date()
        });
        this.logger.log(`Операция ${operationId} закрыта, выполнено ${completedQuantity} деталей, станок освобожден`);
    }
};
exports.OperationCompletionCheckController = OperationCompletionCheckController;
__decorate([
    (0, common_1.Get)('check/:operationId'),
    (0, swagger_1.ApiOperation)({ summary: 'Проверить завершение операции по накопленному количеству' }),
    __param(0, (0, common_1.Param)('operationId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", Promise)
], OperationCompletionCheckController.prototype, "checkOperationCompletion", null);
__decorate([
    (0, common_1.Get)('check-all-active'),
    (0, swagger_1.ApiOperation)({ summary: 'Проверить все активные операции на завершение' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], OperationCompletionCheckController.prototype, "checkAllActiveOperations", null);
__decorate([
    (0, common_1.Post)('handle'),
    (0, swagger_1.ApiOperation)({ summary: 'Обработать завершенную операцию (закрыть/продолжить/планировать)' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], OperationCompletionCheckController.prototype, "handleCompletion", null);
exports.OperationCompletionCheckController = OperationCompletionCheckController = OperationCompletionCheckController_1 = __decorate([
    (0, swagger_1.ApiTags)('operation-completion-check'),
    (0, common_1.Controller)('operations/completion'),
    __param(0, (0, typeorm_1.InjectRepository)(operation_entity_1.Operation)),
    __param(1, (0, typeorm_1.InjectRepository)(shift_record_entity_1.ShiftRecord)),
    __param(2, (0, typeorm_1.InjectRepository)(order_entity_1.Order)),
    __param(3, (0, typeorm_1.InjectRepository)(machine_entity_1.Machine)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], OperationCompletionCheckController);
//# sourceMappingURL=operation-completion-check.controller.js.map