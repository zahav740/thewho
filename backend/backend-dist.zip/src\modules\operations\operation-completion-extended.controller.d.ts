import { Repository } from 'typeorm';
import { Operation } from '../../database/entities/operation.entity';
import { ShiftRecord } from '../../database/entities/shift-record.entity';
import { Order } from '../../database/entities/order.entity';
import { Machine } from '../../database/entities/machine.entity';
interface CompletedOperationDetails {
    id: string;
    operationNumber: number;
    operationType: string;
    orderDrawingNumber: string;
    machineName: string;
    machineType: string;
    targetQuantity: number;
    completedQuantity: number;
    progressPercentage: number;
    estimatedTime: number;
    actualTime?: number;
    dayShiftQuantity: number;
    nightShiftQuantity: number;
    dayShiftOperator?: string;
    nightShiftOperator?: string;
    startedAt: string;
    completedAt: string;
}
export declare class OperationCompletionExtendedController {
    private readonly operationRepository;
    private readonly shiftRecordRepository;
    private readonly orderRepository;
    private readonly machineRepository;
    private readonly logger;
    constructor(operationRepository: Repository<Operation>, shiftRecordRepository: Repository<ShiftRecord>, orderRepository: Repository<Order>, machineRepository: Repository<Machine>);
    checkCompletedOperations(): Promise<{
        success: boolean;
        data: CompletedOperationDetails[];
    }>;
    getCompletionDetails(operationId: string): Promise<{
        success: boolean;
        data: CompletedOperationDetails | null;
    }>;
    closeOperation(operationId: string, body: {
        saveResults: boolean;
    }): Promise<{
        success: boolean;
        message: string;
    }>;
    continueOperation(operationId: string): Promise<{
        success: boolean;
        message: string;
    }>;
    archiveAndFree(operationId: string): Promise<{
        success: boolean;
        message: string;
        machineId?: number;
    }>;
    updateProgress(operationId: string, body: {
        completedUnits: number;
        totalUnits: number;
    }): Promise<{
        success: boolean;
        message: string;
    }>;
}
export {};
