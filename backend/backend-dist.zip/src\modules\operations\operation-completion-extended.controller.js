"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var OperationCompletionExtendedController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationCompletionExtendedController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const operation_entity_1 = require("../../database/entities/operation.entity");
const shift_record_entity_1 = require("../../database/entities/shift-record.entity");
const order_entity_1 = require("../../database/entities/order.entity");
const machine_entity_1 = require("../../database/entities/machine.entity");
let OperationCompletionExtendedController = OperationCompletionExtendedController_1 = class OperationCompletionExtendedController {
    constructor(operationRepository, shiftRecordRepository, orderRepository, machineRepository) {
        this.operationRepository = operationRepository;
        this.shiftRecordRepository = shiftRecordRepository;
        this.orderRepository = orderRepository;
        this.machineRepository = machineRepository;
        this.logger = new common_1.Logger(OperationCompletionExtendedController_1.name);
    }
    async checkCompletedOperations() {
        try {
            this.logger.log('Проверка завершенных операций для модального окна');
            const activeOperations = await this.operationRepository.find({
                where: [
                    { status: 'IN_PROGRESS' },
                    { status: 'ASSIGNED' }
                ],
                relations: ['order']
            });
            const completedOperations = [];
            for (const operation of activeOperations) {
                try {
                    const shiftRecords = await this.shiftRecordRepository.find({
                        where: { operationId: operation.id, archived: false }
                    });
                    const dayShiftTotal = shiftRecords.reduce((total, record) => total + (record.dayShiftQuantity || 0), 0);
                    const nightShiftTotal = shiftRecords.reduce((total, record) => total + (record.nightShiftQuantity || 0), 0);
                    const totalCompleted = dayShiftTotal + nightShiftTotal;
                    const targetQuantity = operation.order?.quantity || 30;
                    const progressPercentage = Math.round((totalCompleted / targetQuantity) * 100);
                    if (progressPercentage >= 100) {
                        const machine = await this.machineRepository.findOne({
                            where: { id: operation.assignedMachine }
                        });
                        const dayOperators = [...new Set(shiftRecords.map(r => r.dayShiftOperator).filter(Boolean))];
                        const nightOperators = [...new Set(shiftRecords.map(r => r.nightShiftOperator).filter(Boolean))];
                        const actualTime = operation.assignedAt ?
                            Math.round((new Date().getTime() - new Date(operation.assignedAt).getTime()) / (1000 * 60)) :
                            operation.estimatedTime;
                        const completedOperation = {
                            id: operation.id.toString(),
                            operationNumber: operation.operationNumber,
                            operationType: operation.operationType || 'Не указан',
                            orderDrawingNumber: operation.order?.drawingNumber || 'Неизвестно',
                            machineName: machine?.code || 'Неизвестно',
                            machineType: machine?.type || 'Неизвестно',
                            targetQuantity,
                            completedQuantity: totalCompleted,
                            progressPercentage,
                            estimatedTime: operation.estimatedTime || 0,
                            actualTime,
                            dayShiftQuantity: dayShiftTotal,
                            nightShiftQuantity: nightShiftTotal,
                            dayShiftOperator: dayOperators.join(', ') || undefined,
                            nightShiftOperator: nightOperators.join(', ') || undefined,
                            startedAt: operation.assignedAt ? operation.assignedAt.toISOString() : new Date().toISOString(),
                            completedAt: new Date().toISOString(),
                        };
                        completedOperations.push(completedOperation);
                    }
                }
                catch (error) {
                    this.logger.warn(`Ошибка при проверке операции ${operation.id}:`, error);
                }
            }
            this.logger.log(`Найдено ${completedOperations.length} завершенных операций`);
            return {
                success: true,
                data: completedOperations
            };
        }
        catch (error) {
            this.logger.error('Ошибка при проверке завершенных операций:', error);
            return {
                success: false,
                data: []
            };
        }
    }
    async getCompletionDetails(operationId) {
        try {
            const operation = await this.operationRepository.findOne({
                where: { id: parseInt(operationId) },
                relations: ['order']
            });
            if (!operation) {
                throw new common_1.BadRequestException('Операция не найдена');
            }
            const shiftRecords = await this.shiftRecordRepository.find({
                where: { operationId: operation.id, archived: false }
            });
            const machine = await this.machineRepository.findOne({
                where: { id: operation.assignedMachine }
            });
            const dayShiftTotal = shiftRecords.reduce((total, record) => total + (record.dayShiftQuantity || 0), 0);
            const nightShiftTotal = shiftRecords.reduce((total, record) => total + (record.nightShiftQuantity || 0), 0);
            const totalCompleted = dayShiftTotal + nightShiftTotal;
            const targetQuantity = operation.order?.quantity || 30;
            const progressPercentage = Math.round((totalCompleted / targetQuantity) * 100);
            const dayOperators = [...new Set(shiftRecords.map(r => r.dayShiftOperator).filter(Boolean))];
            const nightOperators = [...new Set(shiftRecords.map(r => r.nightShiftOperator).filter(Boolean))];
            const actualTime = operation.assignedAt ?
                Math.round((new Date().getTime() - new Date(operation.assignedAt).getTime()) / (1000 * 60)) :
                operation.estimatedTime;
            const details = {
                id: operation.id.toString(),
                operationNumber: operation.operationNumber,
                operationType: operation.operationType || 'Не указан',
                orderDrawingNumber: operation.order?.drawingNumber || 'Неизвестно',
                machineName: machine?.code || 'Неизвестно',
                machineType: machine?.type || 'Неизвестно',
                targetQuantity,
                completedQuantity: totalCompleted,
                progressPercentage,
                estimatedTime: operation.estimatedTime || 0,
                actualTime,
                dayShiftQuantity: dayShiftTotal,
                nightShiftQuantity: nightShiftTotal,
                dayShiftOperator: dayOperators.join(', ') || undefined,
                nightShiftOperator: nightOperators.join(', ') || undefined,
                startedAt: operation.assignedAt ? operation.assignedAt.toISOString() : new Date().toISOString(),
                completedAt: new Date().toISOString(),
            };
            return {
                success: true,
                data: details
            };
        }
        catch (error) {
            this.logger.error(`Ошибка при получении деталей операции ${operationId}:`, error);
            return {
                success: false,
                data: null
            };
        }
    }
    async closeOperation(operationId, body) {
        try {
            const opId = parseInt(operationId);
            this.logger.log(`Закрытие операции ${opId}, сохранить результаты: ${body.saveResults}`);
            const operation = await this.operationRepository.findOne({
                where: { id: opId },
                relations: ['order']
            });
            if (!operation) {
                throw new common_1.BadRequestException('Операция не найдена');
            }
            const shiftRecords = await this.shiftRecordRepository.find({
                where: { operationId: opId, archived: false }
            });
            const totalCompleted = shiftRecords.reduce((total, record) => total + (record.dayShiftQuantity || 0) + (record.nightShiftQuantity || 0), 0);
            if (body.saveResults) {
                await this.operationRepository.update(opId, {
                    status: 'COMPLETED',
                    completedAt: new Date(),
                    actualQuantity: totalCompleted,
                    assignedMachine: null
                });
                await this.shiftRecordRepository.update({ operationId: opId }, {
                    archived: true,
                    archivedAt: new Date()
                });
                if (operation.assignedMachine) {
                    await this.machineRepository.update(operation.assignedMachine, {
                        isOccupied: false,
                        currentOperation: null,
                        assignedAt: null,
                        updatedAt: new Date()
                    });
                }
                this.logger.log(`Операция ${opId} закрыта, выполнено ${totalCompleted} деталей`);
            }
            return {
                success: true,
                message: body.saveResults ?
                    'Операция закрыта и результат сохранен в БД' :
                    'Операция закрыта без сохранения'
            };
        }
        catch (error) {
            this.logger.error(`Ошибка при закрытии операции ${operationId}:`, error);
            throw new common_1.BadRequestException(`Ошибка при закрытии операции: ${error.message}`);
        }
    }
    async continueOperation(operationId) {
        try {
            const opId = parseInt(operationId);
            this.logger.log(`Продолжение операции ${opId}`);
            const operation = await this.operationRepository.findOne({
                where: { id: opId }
            });
            if (!operation) {
                throw new common_1.BadRequestException('Операция не найдена');
            }
            if (operation.status !== 'IN_PROGRESS') {
                await this.operationRepository.update(opId, {
                    status: 'IN_PROGRESS',
                    updatedAt: new Date()
                });
            }
            this.logger.log(`Операция ${opId} продолжена, накопление результата сохранено`);
            return {
                success: true,
                message: 'Операция продолжена, результат будет накапливаться'
            };
        }
        catch (error) {
            this.logger.error(`Ошибка при продолжении операции ${operationId}:`, error);
            throw new common_1.BadRequestException(`Ошибка при продолжении операции: ${error.message}`);
        }
    }
    async archiveAndFree(operationId) {
        try {
            const opId = parseInt(operationId);
            this.logger.log(`Архивирование и освобождение станка для операции ${opId}`);
            const operation = await this.operationRepository.findOne({
                where: { id: opId }
            });
            if (!operation) {
                throw new common_1.BadRequestException('Операция не найдена');
            }
            const shiftRecords = await this.shiftRecordRepository.find({
                where: { operationId: opId, archived: false }
            });
            const totalCompleted = shiftRecords.reduce((total, record) => total + (record.dayShiftQuantity || 0) + (record.nightShiftQuantity || 0), 0);
            await this.operationRepository.update(opId, {
                status: 'COMPLETED',
                completedAt: new Date(),
                actualQuantity: totalCompleted,
                assignedMachine: null
            });
            await this.shiftRecordRepository.update({ operationId: opId }, {
                archived: true,
                archivedAt: new Date()
            });
            let machineId = null;
            if (operation.assignedMachine) {
                await this.machineRepository.update(operation.assignedMachine, {
                    isOccupied: false,
                    currentOperation: null,
                    assignedAt: null,
                    updatedAt: new Date()
                });
                machineId = operation.assignedMachine;
            }
            this.logger.log(`Операция ${opId} архивирована, станок ${machineId} освобожден для планирования`);
            return {
                success: true,
                message: 'Результат сохранен, станок освобожден для планирования',
                machineId
            };
        }
        catch (error) {
            this.logger.error(`Ошибка при архивировании операции ${operationId}:`, error);
            throw new common_1.BadRequestException(`Ошибка при архивировании: ${error.message}`);
        }
    }
    async updateProgress(operationId, body) {
        try {
            const opId = parseInt(operationId);
            this.logger.log(`Обновление прогресса операции ${opId}: ${body.completedUnits}/${body.totalUnits}`);
            return {
                success: true,
                message: 'Прогресс операции обновлен'
            };
        }
        catch (error) {
            this.logger.error(`Ошибка при обновлении прогресса операции ${operationId}:`, error);
            throw new common_1.BadRequestException(`Ошибка при обновлении прогресса: ${error.message}`);
        }
    }
};
exports.OperationCompletionExtendedController = OperationCompletionExtendedController;
__decorate([
    (0, common_1.Get)('completed-check'),
    (0, swagger_1.ApiOperation)({ summary: 'Проверить завершенные операции для показа модального окна' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], OperationCompletionExtendedController.prototype, "checkCompletedOperations", null);
__decorate([
    (0, common_1.Get)(':operationId/completion-details'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить детальную информацию о завершенной операции' }),
    __param(0, (0, common_1.Param)('operationId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OperationCompletionExtendedController.prototype, "getCompletionDetails", null);
__decorate([
    (0, common_1.Post)(':operationId/close'),
    (0, swagger_1.ApiOperation)({ summary: 'Закрыть операцию и сохранить результат' }),
    __param(0, (0, common_1.Param)('operationId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], OperationCompletionExtendedController.prototype, "closeOperation", null);
__decorate([
    (0, common_1.Post)(':operationId/continue'),
    (0, swagger_1.ApiOperation)({ summary: 'Продолжить операцию' }),
    __param(0, (0, common_1.Param)('operationId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OperationCompletionExtendedController.prototype, "continueOperation", null);
__decorate([
    (0, common_1.Post)(':operationId/archive-and-free'),
    (0, swagger_1.ApiOperation)({ summary: 'Архивировать результат и освободить станок для планирования' }),
    __param(0, (0, common_1.Param)('operationId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OperationCompletionExtendedController.prototype, "archiveAndFree", null);
__decorate([
    (0, common_1.Put)('operation/:operationId'),
    (0, swagger_1.ApiOperation)({ summary: 'Обновить прогресс операции' }),
    __param(0, (0, common_1.Param)('operationId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], OperationCompletionExtendedController.prototype, "updateProgress", null);
exports.OperationCompletionExtendedController = OperationCompletionExtendedController = OperationCompletionExtendedController_1 = __decorate([
    (0, swagger_1.ApiTags)('operation-completion-extended'),
    (0, common_1.Controller)('operations'),
    __param(0, (0, typeorm_1.InjectRepository)(operation_entity_1.Operation)),
    __param(1, (0, typeorm_1.InjectRepository)(shift_record_entity_1.ShiftRecord)),
    __param(2, (0, typeorm_1.InjectRepository)(order_entity_1.Order)),
    __param(3, (0, typeorm_1.InjectRepository)(machine_entity_1.Machine)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], OperationCompletionExtendedController);
//# sourceMappingURL=operation-completion-extended.controller.js.map