import { Repository } from 'typeorm';
import { Operation } from '../../database/entities/operation.entity';
import { ShiftRecord } from '../../database/entities/shift-record.entity';
interface CompleteOperationDto {
    operationId: number;
    completedQuantity: number;
    shiftData: any;
    completedAt: string;
}
interface ResetOperationDto {
    operationId: number;
}
export declare class OperationCompletionController {
    private readonly operationRepository;
    private readonly shiftRecordRepository;
    private readonly logger;
    constructor(operationRepository: Repository<Operation>, shiftRecordRepository: Repository<ShiftRecord>);
    completeOperation(dto: CompleteOperationDto): Promise<{
        success: boolean;
        message: string;
        operationId: number;
    }>;
    resetOperationShifts(dto: ResetOperationDto): Promise<{
        success: boolean;
        message: string;
        operationId: number;
    }>;
}
export {};
