"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var OperationCompletionController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationCompletionController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const operation_entity_1 = require("../../database/entities/operation.entity");
const shift_record_entity_1 = require("../../database/entities/shift-record.entity");
let OperationCompletionController = OperationCompletionController_1 = class OperationCompletionController {
    constructor(operationRepository, shiftRecordRepository) {
        this.operationRepository = operationRepository;
        this.shiftRecordRepository = shiftRecordRepository;
        this.logger = new common_1.Logger(OperationCompletionController_1.name);
    }
    async completeOperation(dto) {
        try {
            this.logger.log(`Завершение операции ${dto.operationId}`);
            const operation = await this.operationRepository.findOne({
                where: { id: dto.operationId },
                relations: ['order']
            });
            if (!operation) {
                throw new common_1.BadRequestException('Операция не найдена');
            }
            operation.status = 'COMPLETED';
            operation.completedAt = new Date(dto.completedAt);
            operation.actualQuantity = dto.completedQuantity;
            await this.operationRepository.save(operation);
            const archiveRecord = {
                operationId: dto.operationId,
                completedQuantity: dto.completedQuantity,
                dayShiftData: dto.shiftData.dayShift,
                nightShiftData: dto.shiftData.nightShift,
                completedAt: new Date(dto.completedAt),
                archived: true
            };
            this.logger.log('Данные операции архивированы:', archiveRecord);
            await this.shiftRecordRepository.update({ operationId: dto.operationId }, {
                dayShiftQuantity: 0,
                nightShiftQuantity: 0,
                archived: true,
                archivedAt: new Date()
            });
            return {
                success: true,
                message: 'Операция успешно завершена и данные архивированы',
                operationId: dto.operationId
            };
        }
        catch (error) {
            this.logger.error('Ошибка при завершении операции:', error);
            throw new common_1.BadRequestException(`Ошибка при завершении операции: ${error.message}`);
        }
    }
    async resetOperationShifts(dto) {
        try {
            this.logger.log(`Сброс данных смен для операции ${dto.operationId}`);
            await this.shiftRecordRepository.update({ operationId: dto.operationId }, {
                dayShiftQuantity: 0,
                nightShiftQuantity: 0,
                dayShiftTimePerUnit: 0,
                nightShiftTimePerUnit: 0,
                resetAt: new Date()
            });
            return {
                success: true,
                message: 'Данные смен успешно сброшены',
                operationId: dto.operationId
            };
        }
        catch (error) {
            this.logger.error('Ошибка при сбросе данных смен:', error);
            throw new common_1.BadRequestException(`Ошибка при сбросе данных: ${error.message}`);
        }
    }
};
exports.OperationCompletionController = OperationCompletionController;
__decorate([
    (0, common_1.Post)('complete'),
    (0, swagger_1.ApiOperation)({ summary: 'Завершить операцию и архивировать данные' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], OperationCompletionController.prototype, "completeOperation", null);
__decorate([
    (0, common_1.Post)('reset-shifts'),
    (0, swagger_1.ApiOperation)({ summary: 'Сбросить данные смен для операции' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], OperationCompletionController.prototype, "resetOperationShifts", null);
exports.OperationCompletionController = OperationCompletionController = OperationCompletionController_1 = __decorate([
    (0, swagger_1.ApiTags)('operation-completion'),
    (0, common_1.Controller)('operations'),
    __param(0, (0, typeorm_1.InjectRepository)(operation_entity_1.Operation)),
    __param(1, (0, typeorm_1.InjectRepository)(shift_record_entity_1.ShiftRecord)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository])
], OperationCompletionController);
//# sourceMappingURL=operation-completion.controller.js.map