import { Response } from 'express';
import { OperationHistoryService, ExportRequest } from './operation-history.service';
export declare class OperationHistoryController {
    private readonly operationHistoryService;
    private readonly logger;
    constructor(operationHistoryService: OperationHistoryService);
    getAvailableDrawings(): Promise<{
        success: boolean;
        count: number;
        data: {
            drawingNumber: string;
            recordCount: number;
            lastDate: Date;
        }[];
    }>;
    getOperationHistory(drawingNumber: string, dateFrom?: string, dateTo?: string): Promise<{
        success: boolean;
        drawingNumber: string;
        period: {
            from: string;
            to: string;
        };
        count: number;
        data: import("./operation-history.service").OperationHistoryRecord[];
    }>;
    exportToExcel(exportRequest: ExportRequest): Promise<{
        success: boolean;
        message: string;
        drawingNumber: string;
        period: {
            from: string;
            to: string;
        };
        downloadUrl: string;
    }>;
    downloadFile(fileName: string, res: Response): Promise<void>;
    calculateOperatorStats(request: {
        operatorName: string;
        drawingNumber: string;
        date?: string;
    }): Promise<{
        success: boolean;
        message: string;
        data: import("./operation-history.service").OperatorEfficiencyStats;
    }>;
    saveShiftToHistory(request: {
        shiftId: number;
        forceRecalculate?: boolean;
    }): Promise<{
        success: boolean;
        message: string;
        shiftId: number;
    }>;
    private getShiftData;
    private calculateEfficiencyRating;
}
