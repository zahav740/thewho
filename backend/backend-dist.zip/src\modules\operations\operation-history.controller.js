"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var OperationHistoryController_1;
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationHistoryController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const express_1 = require("express");
const operation_history_service_1 = require("./operation-history.service");
const fs_1 = require("fs");
let OperationHistoryController = OperationHistoryController_1 = class OperationHistoryController {
    constructor(operationHistoryService) {
        this.operationHistoryService = operationHistoryService;
        this.logger = new common_1.Logger(OperationHistoryController_1.name);
    }
    async getAvailableDrawings() {
        try {
            const drawings = await this.operationHistoryService.getAvailableDrawings();
            return {
                success: true,
                count: drawings.length,
                data: drawings
            };
        }
        catch (error) {
            this.logger.error('Ошибка при получении списка чертежей:', error);
            throw error;
        }
    }
    async getOperationHistory(drawingNumber, dateFrom, dateTo) {
        try {
            this.logger.log(`Запрос истории операций для чертежа: ${drawingNumber}`);
            const dateFromObj = dateFrom ? new Date(dateFrom) : undefined;
            const dateToObj = dateTo ? new Date(dateTo) : undefined;
            const history = await this.operationHistoryService.getOperationHistory(drawingNumber, dateFromObj, dateToObj);
            return {
                success: true,
                drawingNumber,
                period: {
                    from: dateFrom || 'Не ограничено',
                    to: dateTo || 'Не ограничено'
                },
                count: history.length,
                data: history
            };
        }
        catch (error) {
            this.logger.error(`Ошибка при получении истории для ${drawingNumber}:`, error);
            throw error;
        }
    }
    async exportToExcel(exportRequest) {
        try {
            this.logger.log(`Запрос экспорта в Excel для чертежа: ${exportRequest.drawingNumber}`);
            if (!exportRequest.drawingNumber) {
                throw new common_1.BadRequestException('Номер чертежа обязателен');
            }
            if (!exportRequest.dateFrom) {
                exportRequest.dateFrom = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
            }
            if (!exportRequest.dateTo) {
                exportRequest.dateTo = new Date();
            }
            exportRequest.exportType = 'excel';
            const filePath = await this.operationHistoryService.exportToExcel(exportRequest);
            return {
                success: true,
                message: 'Файл Excel успешно создан',
                drawingNumber: exportRequest.drawingNumber,
                period: {
                    from: exportRequest.dateFrom.toISOString().split('T')[0],
                    to: exportRequest.dateTo.toISOString().split('T')[0]
                },
                downloadUrl: `/operation-history/download/${encodeURIComponent(filePath.split('/').pop() || '')}`
            };
        }
        catch (error) {
            this.logger.error('Ошибка при экспорте в Excel:', error);
            throw error;
        }
    }
    async downloadFile(fileName, res) {
        try {
            this.logger.log(`Запрос скачивания файла: ${fileName}`);
            if (fileName.includes('..') || fileName.includes('/') || fileName.includes('\\')) {
                throw new common_1.BadRequestException('Недопустимое имя файла');
            }
            const filePath = `${process.cwd()}/uploads/exports/${fileName}`;
            if (!(0, fs_1.existsSync)(filePath)) {
                throw new common_1.BadRequestException('Файл не найден');
            }
            res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
            const fileStream = (0, fs_1.createReadStream)(filePath);
            fileStream.pipe(res);
            this.logger.log(`Файл ${fileName} отправлен пользователю`);
        }
        catch (error) {
            this.logger.error(`Ошибка при скачивании файла ${fileName}:`, error);
            throw error;
        }
    }
    async calculateOperatorStats(request) {
        try {
            this.logger.log(`Запрос статистики для оператора: ${request.operatorName}, чертеж: ${request.drawingNumber}`);
            if (!request.operatorName || !request.drawingNumber) {
                throw new common_1.BadRequestException('Имя оператора и номер чертежа обязательны');
            }
            const date = request.date ? new Date(request.date) : new Date();
            const stats = await this.operationHistoryService.calculateAndSaveOperatorStats(request.operatorName, request.drawingNumber, date);
            return {
                success: true,
                message: 'Статистика оператора обновлена',
                data: stats
            };
        }
        catch (error) {
            this.logger.error('Ошибка при вычислении статистики оператора:', error);
            throw error;
        }
    }
    async saveShiftToHistory(request) {
        try {
            this.logger.log(`Сохранение смены ${request.shiftId} в историю операций`);
            const shiftData = await this.getShiftData(request.shiftId);
            if (!shiftData) {
                throw new common_1.BadRequestException('Смена не найдена');
            }
            if (shiftData.dayShiftQuantity > 0) {
                await this.operationHistoryService.saveOperationToHistory({
                    drawingNumber: shiftData.drawingNumber,
                    operationId: shiftData.operationId,
                    operationNumber: shiftData.operationNumber,
                    operationType: shiftData.operationType,
                    machineId: shiftData.machineId,
                    machineName: shiftData.machineName,
                    operatorName: shiftData.dayShiftOperator,
                    shiftType: 'DAY',
                    quantityProduced: shiftData.dayShiftQuantity,
                    timePerUnit: shiftData.dayShiftTimePerUnit,
                    setupTime: shiftData.setupTime,
                    totalTime: shiftData.dayShiftQuantity * shiftData.dayShiftTimePerUnit,
                    efficiencyRating: this.calculateEfficiencyRating(shiftData, 'DAY'),
                    dateCompleted: shiftData.date
                });
            }
            if (shiftData.nightShiftQuantity > 0) {
                await this.operationHistoryService.saveOperationToHistory({
                    drawingNumber: shiftData.drawingNumber,
                    operationId: shiftData.operationId,
                    operationNumber: shiftData.operationNumber,
                    operationType: shiftData.operationType,
                    machineId: shiftData.machineId,
                    machineName: shiftData.machineName,
                    operatorName: shiftData.nightShiftOperator,
                    shiftType: 'NIGHT',
                    quantityProduced: shiftData.nightShiftQuantity,
                    timePerUnit: shiftData.nightShiftTimePerUnit,
                    setupTime: 0,
                    totalTime: shiftData.nightShiftQuantity * shiftData.nightShiftTimePerUnit,
                    efficiencyRating: this.calculateEfficiencyRating(shiftData, 'NIGHT'),
                    dateCompleted: shiftData.date
                });
            }
            if (request.forceRecalculate) {
                if (shiftData.dayShiftOperator) {
                    await this.operationHistoryService.calculateAndSaveOperatorStats(shiftData.dayShiftOperator, shiftData.drawingNumber, shiftData.date);
                }
                if (shiftData.nightShiftOperator) {
                    await this.operationHistoryService.calculateAndSaveOperatorStats(shiftData.nightShiftOperator, shiftData.drawingNumber, shiftData.date);
                }
            }
            return {
                success: true,
                message: 'Смена сохранена в историю операций',
                shiftId: request.shiftId
            };
        }
        catch (error) {
            this.logger.error('Ошибка при сохранении смены в историю:', error);
            throw error;
        }
    }
    async getShiftData(shiftId) {
        const result = await this.operationHistoryService['dataSource'].query(`
      SELECT 
        sr.*,
        o."operationNumber",
        o.operationtype as "operationType",
        ord.drawing_number as "drawingNumber",
        m.code as "machineName"
      FROM shift_records sr
      LEFT JOIN operations o ON sr."operationId" = o.id
      LEFT JOIN orders ord ON o."orderId" = ord.id
      LEFT JOIN machines m ON sr."machineId" = m.id
      WHERE sr.id = $1
    `, [shiftId]);
        return result[0] || null;
    }
    calculateEfficiencyRating(shiftData, shiftType) {
        const planTimePerPart = 15;
        const actualTimePerPart = shiftType === 'DAY'
            ? shiftData.dayShiftTimePerUnit
            : shiftData.nightShiftTimePerUnit;
        if (!actualTimePerPart || actualTimePerPart <= 0)
            return 0;
        const efficiency = (planTimePerPart / actualTimePerPart) * 100;
        return Math.min(100, Math.max(0, efficiency));
    }
};
exports.OperationHistoryController = OperationHistoryController;
__decorate([
    (0, common_1.Get)('drawings'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить список доступных чертежей для экспорта' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], OperationHistoryController.prototype, "getAvailableDrawings", null);
__decorate([
    (0, common_1.Get)(':drawingNumber'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить историю операций по номеру чертежа' }),
    (0, swagger_1.ApiQuery)({ name: 'dateFrom', required: false, description: 'Дата начала периода (YYYY-MM-DD)' }),
    (0, swagger_1.ApiQuery)({ name: 'dateTo', required: false, description: 'Дата окончания периода (YYYY-MM-DD)' }),
    __param(0, (0, common_1.Param)('drawingNumber')),
    __param(1, (0, common_1.Query)('dateFrom')),
    __param(2, (0, common_1.Query)('dateTo')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String]),
    __metadata("design:returntype", Promise)
], OperationHistoryController.prototype, "getOperationHistory", null);
__decorate([
    (0, common_1.Post)('export/excel'),
    (0, swagger_1.ApiOperation)({ summary: 'Экспорт истории операций в Excel' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], OperationHistoryController.prototype, "exportToExcel", null);
__decorate([
    (0, common_1.Get)('download/:fileName'),
    (0, swagger_1.ApiOperation)({ summary: 'Скачать экспортированный файл' }),
    __param(0, (0, common_1.Param)('fileName')),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_a = typeof express_1.Response !== "undefined" && express_1.Response) === "function" ? _a : Object]),
    __metadata("design:returntype", Promise)
], OperationHistoryController.prototype, "downloadFile", null);
__decorate([
    (0, common_1.Post)('operator-stats'),
    (0, swagger_1.ApiOperation)({ summary: 'Вычислить и сохранить статистику эффективности оператора' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], OperationHistoryController.prototype, "calculateOperatorStats", null);
__decorate([
    (0, common_1.Post)('save-shift-to-history'),
    (0, swagger_1.ApiOperation)({ summary: 'Сохранить запись смены в историю операций' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], OperationHistoryController.prototype, "saveShiftToHistory", null);
exports.OperationHistoryController = OperationHistoryController = OperationHistoryController_1 = __decorate([
    (0, swagger_1.ApiTags)('operation-history'),
    (0, common_1.Controller)('operation-history'),
    __metadata("design:paramtypes", [operation_history_service_1.OperationHistoryService])
], OperationHistoryController);
//# sourceMappingURL=operation-history.controller.js.map