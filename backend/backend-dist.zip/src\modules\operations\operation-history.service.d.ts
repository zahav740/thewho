import { DataSource } from 'typeorm';
export interface OperationHistoryRecord {
    id?: number;
    drawingNumber: string;
    operationId: number;
    operationNumber: number;
    operationType: string;
    machineId: number;
    machineName: string;
    operatorName?: string;
    shiftType: 'DAY' | 'NIGHT';
    quantityProduced: number;
    timePerUnit?: number;
    setupTime?: number;
    totalTime?: number;
    efficiencyRating?: number;
    dateCompleted: Date;
}
export interface OperatorEfficiencyStats {
    operatorName: string;
    drawingNumber: string;
    operationType: string;
    calculationDate: Date;
    partsPerHour: number;
    planVsFactPercent: number;
    averageTimePerPart: number;
    timeDeviationPercent: number;
    consistencyRating: number;
    workingTimeMinutes: number;
    idleTimeMinutes: number;
    utilizationEfficiency: number;
    overallRating: number;
}
export interface ExportRequest {
    drawingNumber: string;
    dateFrom: Date;
    dateTo: Date;
    exportType: 'excel' | 'pdf' | 'csv';
    requestedBy?: string;
}
export declare class OperationHistoryService {
    private readonly dataSource;
    private readonly logger;
    private readonly uploadsDir;
    constructor(dataSource: DataSource);
    saveOperationToHistory(record: OperationHistoryRecord): Promise<void>;
    getOperationHistory(drawingNumber: string, dateFrom?: Date, dateTo?: Date): Promise<OperationHistoryRecord[]>;
    calculateAndSaveOperatorStats(operatorName: string, drawingNumber: string, date: Date): Promise<OperatorEfficiencyStats>;
    exportToExcel(request: ExportRequest): Promise<string>;
    getAvailableDrawings(): Promise<{
        drawingNumber: string;
        recordCount: number;
        lastDate: Date;
    }[]>;
    private calculateOperatorMetrics;
    private mapDatabaseRecordToInterface;
}
