"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var OperationHistoryService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationHistoryService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const ExcelJS = require("exceljs");
const path_1 = require("path");
const fs_1 = require("fs");
let OperationHistoryService = OperationHistoryService_1 = class OperationHistoryService {
    constructor(dataSource) {
        this.dataSource = dataSource;
        this.logger = new common_1.Logger(OperationHistoryService_1.name);
        this.uploadsDir = (0, path_1.join)(process.cwd(), 'uploads', 'exports');
        if (!(0, fs_1.existsSync)(this.uploadsDir)) {
            (0, fs_1.mkdirSync)(this.uploadsDir, { recursive: true });
        }
    }
    async saveOperationToHistory(record) {
        try {
            await this.dataSource.query(`
        INSERT INTO operation_history (
          drawing_number, operation_id, operation_number, operation_type,
          machine_id, machine_name, operator_name, shift_type,
          quantity_produced, time_per_unit, setup_time, total_time,
          efficiency_rating, date_completed
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
      `, [
                record.drawingNumber,
                record.operationId,
                record.operationNumber,
                record.operationType,
                record.machineId,
                record.machineName,
                record.operatorName,
                record.shiftType,
                record.quantityProduced,
                record.timePerUnit,
                record.setupTime,
                record.totalTime,
                record.efficiencyRating,
                record.dateCompleted
            ]);
            this.logger.log(`История операции сохранена: ${record.drawingNumber} - ${record.operationNumber}`);
        }
        catch (error) {
            this.logger.error('Ошибка при сохранении истории операции:', error);
            throw error;
        }
    }
    async getOperationHistory(drawingNumber, dateFrom, dateTo) {
        try {
            let query = `
        SELECT * FROM operation_history 
        WHERE drawing_number = $1
      `;
            const params = [drawingNumber];
            if (dateFrom && dateTo) {
                query += ` AND date_completed BETWEEN $2 AND $3`;
                params.push(dateFrom.toISOString().split('T')[0], dateTo.toISOString().split('T')[0]);
            }
            query += ` ORDER BY date_completed DESC, operation_number ASC`;
            const results = await this.dataSource.query(query, params);
            this.logger.log(`Получена история операций для ${drawingNumber}: ${results.length} записей`);
            return results.map(this.mapDatabaseRecordToInterface);
        }
        catch (error) {
            this.logger.error(`Ошибка при получении истории операций для ${drawingNumber}:`, error);
            throw error;
        }
    }
    async calculateAndSaveOperatorStats(operatorName, drawingNumber, date) {
        try {
            const operatorRecords = await this.dataSource.query(`
        SELECT * FROM operation_history 
        WHERE operator_name = $1 AND drawing_number = $2 
        AND DATE(date_completed) = $3
        ORDER BY date_completed ASC
      `, [operatorName, drawingNumber, date.toISOString().split('T')[0]]);
            if (operatorRecords.length === 0) {
                throw new Error(`Нет данных для оператора ${operatorName} по чертежу ${drawingNumber}`);
            }
            const stats = this.calculateOperatorMetrics(operatorRecords);
            await this.dataSource.query(`
        INSERT INTO operator_efficiency_stats (
          operator_name, drawing_number, operation_type, calculation_date,
          parts_per_hour, plan_vs_fact_percent, average_time_per_part,
          time_deviation_percent, consistency_rating, working_time_minutes,
          idle_time_minutes, utilization_efficiency, overall_rating
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
        ON CONFLICT (operator_name, drawing_number, calculation_date)
        DO UPDATE SET
          parts_per_hour = EXCLUDED.parts_per_hour,
          plan_vs_fact_percent = EXCLUDED.plan_vs_fact_percent,
          average_time_per_part = EXCLUDED.average_time_per_part,
          time_deviation_percent = EXCLUDED.time_deviation_percent,
          consistency_rating = EXCLUDED.consistency_rating,
          working_time_minutes = EXCLUDED.working_time_minutes,
          idle_time_minutes = EXCLUDED.idle_time_minutes,
          utilization_efficiency = EXCLUDED.utilization_efficiency,
          overall_rating = EXCLUDED.overall_rating,
          updated_at = NOW()
      `, [
                operatorName,
                drawingNumber,
                operatorRecords[0].operation_type,
                date.toISOString().split('T')[0],
                stats.partsPerHour,
                stats.planVsFactPercent,
                stats.averageTimePerPart,
                stats.timeDeviationPercent,
                stats.consistencyRating,
                stats.workingTimeMinutes,
                stats.idleTimeMinutes,
                stats.utilizationEfficiency,
                stats.overallRating
            ]);
            this.logger.log(`Статистика оператора ${operatorName} обновлена`);
            return stats;
        }
        catch (error) {
            this.logger.error('Ошибка при вычислении статистики оператора:', error);
            throw error;
        }
    }
    async exportToExcel(request) {
        try {
            const history = await this.getOperationHistory(request.drawingNumber, request.dateFrom, request.dateTo);
            if (history.length === 0) {
                throw new Error('Нет данных для экспорта');
            }
            const exportData = history.map(record => ({
                'Дата': record.dateCompleted.toLocaleDateString('ru-RU'),
                'Номер чертежа': record.drawingNumber,
                'Операция №': record.operationNumber,
                'Тип операции': record.operationType,
                'Станок': record.machineName,
                'Оператор': record.operatorName || '-',
                'Смена': record.shiftType === 'DAY' ? 'Дневная' : 'Ночная',
                'Количество деталей': record.quantityProduced,
                'Время на деталь (мин)': record.timePerUnit || 0,
                'Время наладки (мин)': record.setupTime || 0,
                'Общее время (мин)': record.totalTime || 0,
                'Эффективность (%)': record.efficiencyRating || 0
            }));
            const workbook = new ExcelJS.Workbook();
            const worksheet = workbook.addWorksheet('История операций');
            worksheet.columns = [
                { header: 'Дата', key: 'date', width: 12 },
                { header: 'Номер чертежа', key: 'drawingNumber', width: 15 },
                { header: 'Операция №', key: 'operationNumber', width: 10 },
                { header: 'Тип операции', key: 'operationType', width: 12 },
                { header: 'Станок', key: 'machine', width: 12 },
                { header: 'Оператор', key: 'operator', width: 12 },
                { header: 'Смена', key: 'shift', width: 10 },
                { header: 'Количество деталей', key: 'quantity', width: 15 },
                { header: 'Время на деталь (мин)', key: 'timePerPart', width: 18 },
                { header: 'Время наладки (мин)', key: 'setupTime', width: 18 },
                { header: 'Общее время (мин)', key: 'totalTime', width: 15 },
                { header: 'Эффективность (%)', key: 'efficiency', width: 15 }
            ];
            exportData.forEach(record => {
                worksheet.addRow({
                    date: record['Дата'],
                    drawingNumber: record['Номер чертежа'],
                    operationNumber: record['Операция №'],
                    operationType: record['Тип операции'],
                    machine: record['Станок'],
                    operator: record['Оператор'],
                    shift: record['Смена'],
                    quantity: record['Количество деталей'],
                    timePerPart: record['Время на деталь (мин)'],
                    setupTime: record['Время наладки (мин)'],
                    totalTime: record['Общее время (мин)'],
                    efficiency: record['Эффективность (%)']
                });
            });
            const fileName = `operation_history_${request.drawingNumber}_${Date.now()}.xlsx`;
            const filePath = (0, path_1.join)(this.uploadsDir, fileName);
            await workbook.xlsx.writeFile(filePath);
            await this.dataSource.query(`
        INSERT INTO operation_export_requests (
          drawing_number, date_from, date_to, export_type, 
          file_path, status, requested_by
        ) VALUES ($1, $2, $3, $4, $5, $6, $7)
      `, [
                request.drawingNumber,
                request.dateFrom.toISOString().split('T')[0],
                request.dateTo.toISOString().split('T')[0],
                request.exportType,
                filePath,
                'completed',
                request.requestedBy
            ]);
            this.logger.log(`Экспорт в Excel завершен: ${fileName}`);
            return filePath;
        }
        catch (error) {
            this.logger.error('Ошибка при экспорте в Excel:', error);
            throw error;
        }
    }
    async getAvailableDrawings() {
        try {
            const results = await this.dataSource.query(`
        SELECT 
          drawing_number,
          COUNT(*) as record_count,
          MAX(date_completed) as last_date
        FROM operation_history 
        GROUP BY drawing_number
        ORDER BY last_date DESC
      `);
            return results.map(row => ({
                drawingNumber: row.drawing_number,
                recordCount: parseInt(row.record_count),
                lastDate: row.last_date
            }));
        }
        catch (error) {
            this.logger.error('Ошибка при получении списка чертежей:', error);
            throw error;
        }
    }
    calculateOperatorMetrics(records) {
        const totalParts = records.reduce((sum, r) => sum + r.quantity_produced, 0);
        const totalTime = records.reduce((sum, r) => sum + (r.total_time || 0), 0);
        const avgTimePerPart = totalParts > 0 ? totalTime / totalParts : 0;
        const planTimePerPart = 15;
        const planVsFact = planTimePerPart > 0 ? (planTimePerPart / avgTimePerPart * 100) : 0;
        const partsPerHour = totalTime > 0 ? (totalParts / (totalTime / 60)) : 0;
        const timesPerPart = records.map(r => r.time_per_unit || 0).filter(t => t > 0);
        const avgTimeFromSamples = timesPerPart.reduce((a, b) => a + b, 0) / timesPerPart.length;
        const variance = timesPerPart.reduce((acc, time) => acc + Math.pow(time - avgTimeFromSamples, 2), 0) / timesPerPart.length;
        const consistency = Math.max(0, 100 - (Math.sqrt(variance) / avgTimeFromSamples * 100));
        const efficiency = Math.min(100, Math.max(0, planVsFact));
        const rating = (Math.min(10, partsPerHour) + Math.min(10, efficiency / 10) + Math.min(10, consistency / 10)) / 3;
        return {
            operatorName: records[0].operator_name,
            drawingNumber: records[0].drawing_number,
            operationType: records[0].operation_type,
            calculationDate: new Date(),
            partsPerHour: Math.round(partsPerHour * 100) / 100,
            planVsFactPercent: Math.round(planVsFact * 10) / 10,
            averageTimePerPart: Math.round(avgTimePerPart * 10) / 10,
            timeDeviationPercent: Math.round(((avgTimePerPart - planTimePerPart) / planTimePerPart * 100) * 10) / 10,
            consistencyRating: Math.round(consistency * 10) / 10,
            workingTimeMinutes: Math.round(totalTime),
            idleTimeMinutes: 0,
            utilizationEfficiency: Math.round(efficiency * 10) / 10,
            overallRating: Math.round(rating * 10) / 10
        };
    }
    mapDatabaseRecordToInterface(dbRecord) {
        return {
            id: dbRecord.id,
            drawingNumber: dbRecord.drawing_number,
            operationId: dbRecord.operation_id,
            operationNumber: dbRecord.operation_number,
            operationType: dbRecord.operation_type,
            machineId: dbRecord.machine_id,
            machineName: dbRecord.machine_name,
            operatorName: dbRecord.operator_name,
            shiftType: dbRecord.shift_type,
            quantityProduced: dbRecord.quantity_produced,
            timePerUnit: dbRecord.time_per_unit,
            setupTime: dbRecord.setup_time,
            totalTime: dbRecord.total_time,
            efficiencyRating: dbRecord.efficiency_rating,
            dateCompleted: dbRecord.date_completed
        };
    }
};
exports.OperationHistoryService = OperationHistoryService;
exports.OperationHistoryService = OperationHistoryService = OperationHistoryService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectDataSource)()),
    __metadata("design:paramtypes", [typeorm_2.DataSource])
], OperationHistoryService);
//# sourceMappingURL=operation-history.service.js.map