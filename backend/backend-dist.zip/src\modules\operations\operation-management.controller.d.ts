import { DataSource } from 'typeorm';
import { OperationAnalyticsService } from './operation-analytics.service';
export declare class CreateOperationDto {
    orderId: number;
    operationNumber: number;
    operationType: 'MILLING' | 'TURNING';
    estimatedTime: number;
    machineAxes?: number;
    notes?: string;
}
export declare class UpdateOperationDto {
    operationType?: 'MILLING' | 'TURNING';
    estimatedTime?: number;
    machineAxes?: number;
    notes?: string;
}
export declare class OperationManagementController {
    private readonly dataSource;
    private readonly analyticsService;
    constructor(dataSource: DataSource, analyticsService: OperationAnalyticsService);
    createOperation(createOperationDto: CreateOperationDto): Promise<{
        success: boolean;
        message: string;
        operationId?: undefined;
        error?: undefined;
    } | {
        success: boolean;
        message: string;
        operationId: any;
        error?: undefined;
    } | {
        success: boolean;
        message: string;
        error: any;
        operationId?: undefined;
    }>;
    getOrderOperations(orderId: string): Promise<{
        success: boolean;
        data: any;
        message?: undefined;
        error?: undefined;
    } | {
        success: boolean;
        message: string;
        error: any;
        data?: undefined;
    }>;
    updateOperation(operationId: string, updateOperationDto: UpdateOperationDto): Promise<{
        success: boolean;
        message: string;
        error?: undefined;
    } | {
        success: boolean;
        message: string;
        error: any;
    }>;
    deleteOperation(operationId: string): Promise<{
        success: boolean;
        message: string;
        error?: undefined;
    } | {
        success: boolean;
        message: string;
        error: any;
    }>;
    getOperationSuggestions(orderDrawingNumber: string, orderQuantity: string, workType?: string): Promise<{
        success: boolean;
        data: import("./operation-analytics.service").OperationSuggestion[];
        message: string;
        error?: undefined;
    } | {
        success: boolean;
        message: string;
        error: any;
        data?: undefined;
    }>;
    getDrawingHistory(drawingNumber: string): Promise<{
        success: boolean;
        data: {
            history: any[];
            statistics: any;
            lastCompletedOrder: any;
        };
        message: string;
        error?: undefined;
    } | {
        success: boolean;
        message: string;
        error: any;
        data?: undefined;
    }>;
    getLastCompletedOrder(drawingNumber: string): Promise<{
        success: boolean;
        data: {
            order: any;
            operations: any;
        };
        message: string;
        error?: undefined;
    } | {
        success: boolean;
        message: string;
        error: any;
        data?: undefined;
    }>;
    getTimeAnalytics(operationType?: string, machineType?: string): Promise<{
        success: boolean;
        data: import("./operation-analytics.service").OperationTimeAnalytics[];
        message?: undefined;
        error?: undefined;
    } | {
        success: boolean;
        message: string;
        error: any;
        data?: undefined;
    }>;
    test(): Promise<{
        status: string;
        message: string;
        data: any;
        example: any;
        timestamp: string;
        endpoints: string[];
        error?: undefined;
    } | {
        status: string;
        error: any;
        timestamp: string;
        message?: undefined;
        data?: undefined;
        example?: undefined;
        endpoints?: undefined;
    }>;
}
