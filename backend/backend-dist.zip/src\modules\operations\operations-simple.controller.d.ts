import { DataSource } from 'typeorm';
export declare class OperationsSimpleController {
    private readonly dataSource;
    constructor(dataSource: DataSource);
    test(): Promise<{
        status: string;
        message: string;
        count: any;
        sample: any;
        timestamp: string;
        error?: undefined;
    } | {
        status: string;
        error: any;
        timestamp: string;
        message?: undefined;
        count?: undefined;
        sample?: undefined;
    }>;
    getAssignedOperationByMachine(machineId: string): Promise<{
        success: boolean;
        message: string;
        operation: any;
        error?: undefined;
    } | {
        success: boolean;
        message: string;
        operation: any;
        error: any;
    }>;
    getActiveOperations(): Promise<any>;
    getOperationDetails(operationId: string): Promise<any>;
    findAll(status?: string): Promise<any>;
}
