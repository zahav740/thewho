"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationsSimpleController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
let OperationsSimpleController = class OperationsSimpleController {
    constructor(dataSource) {
        this.dataSource = dataSource;
    }
    async test() {
        try {
            const count = await this.dataSource.query('SELECT COUNT(*) as count FROM operations');
            const sample = await this.dataSource.query('SELECT * FROM operations LIMIT 3');
            return {
                status: 'ok',
                message: 'Operations controller is working',
                count: count[0]?.count || 0,
                sample,
                timestamp: new Date().toISOString(),
            };
        }
        catch (error) {
            return {
                status: 'error',
                error: error.message,
                timestamp: new Date().toISOString(),
            };
        }
    }
    async getAssignedOperationByMachine(machineId) {
        try {
            console.log('OperationsSimpleController.getAssignedOperationByMachine: Поиск операции для станка:', machineId);
            const query = `
        SELECT 
          op.id,
          op."operationNumber",
          op."machineId",
          op.operationtype as "operationType", 
          op."estimatedTime",
          COALESCE(op.status, 'PENDING') as status,
          op."orderId",
          op.machineaxes as "machineAxes",
          op."createdAt",
          op."updatedAt",
          ord.drawing_number as "orderDrawingNumber",
          ord.quantity as "orderQuantity",
          ord.priority as "orderPriority",
          ord.deadline as "orderDeadline",
          ord."workType" as "orderWorkType"
        FROM operations op
        LEFT JOIN orders ord ON op."orderId" = ord.id
        WHERE op."assignedMachine" = $1 
           OR op."machineId" = $1
        ORDER BY op."createdAt" DESC 
        LIMIT 1
      `;
            const operations = await this.dataSource.query(query, [parseInt(machineId)]);
            if (operations.length === 0) {
                return {
                    success: false,
                    message: 'На данный станок не назначено операций',
                    operation: null
                };
            }
            console.log(`OperationsSimpleController.getAssignedOperationByMachine: Найдена операция:`, operations[0]);
            return {
                success: true,
                message: 'Операция найдена',
                operation: operations[0]
            };
        }
        catch (error) {
            console.error('OperationsSimpleController.getAssignedOperationByMachine: Ошибка:', error);
            return {
                success: false,
                message: 'Ошибка при поиске операции',
                operation: null,
                error: error.message
            };
        }
    }
    async getActiveOperations() {
        try {
            console.log('OperationsSimpleController.getActiveOperations: Получение активных операций');
            const query = `
        SELECT 
          op.id,
          op."operationNumber",
          op.operationtype as "operationType", 
          op."estimatedTime",
          op.status,
          op."assignedMachine" as "machineId",
          m.code as "machineName",
          ord.drawing_number as "orderDrawingNumber",
          ord.id as "orderId",
          op."assignedAt",
          op."createdAt",
          op."updatedAt"
        FROM operations op
        INNER JOIN machines m ON op."assignedMachine" = m.id
        LEFT JOIN orders ord ON op."orderId" = ord.id
        WHERE op.status IN ('in_progress', 'assigned')
        ORDER BY op."assignedAt" DESC
      `;
            const operations = await this.dataSource.query(query);
            console.log(`OperationsSimpleController.getActiveOperations: Найдено ${operations.length} активных операций`);
            return operations;
        }
        catch (error) {
            console.error('OperationsSimpleController.getActiveOperations: Ошибка:', error);
            throw error;
        }
    }
    async getOperationDetails(operationId) {
        try {
            console.log('OperationsSimpleController.getOperationDetails: Получение деталей операции:', operationId);
            const query = `
        SELECT 
          op.id,
          op."operationNumber",
          op."machineId",
          op.operationtype, 
          op."estimatedTime",
          op.status,
          op."orderId",
          op.machineaxes,
          op."createdAt",
          op."updatedAt",
          ord.drawing_number,
          ord.quantity,
          ord.priority,
          ord.deadline,
          ord."workType"
        FROM operations op
        LEFT JOIN orders ord ON op."orderId" = ord.id
        WHERE op.id = $1
      `;
            const operation = await this.dataSource.query(query, [parseInt(operationId)]);
            if (operation.length === 0) {
                return {
                    success: false,
                    message: 'Операция не найдена',
                    operation: null
                };
            }
            console.log(`OperationsSimpleController.getOperationDetails: Найдена операция:`, operation[0]);
            return operation[0];
        }
        catch (error) {
            console.error('OperationsSimpleController.getOperationDetails: Ошибка:', error);
            throw error;
        }
    }
    async findAll(status) {
        try {
            console.log('OperationsSimpleController.findAll: Получение операций со статусом:', status);
            let query = `
        SELECT 
          op.id,
          op."operationNumber",
          op."machineId",
          op.operationtype as "operationType", 
          op."estimatedTime",
          0 as "completedUnits",
          null as "actualTime",
          COALESCE(op.status, 'PENDING') as status,
          '[]' as operators,
          op."orderId",
          op.machineaxes as "machineAxes",
          op."createdAt",
          op."updatedAt",
          ord.drawing_number as "orderDrawingNumber"
        FROM operations op
        LEFT JOIN orders ord ON op."orderId" = ord.id
      `;
            const params = [];
            if (status) {
                query += ' WHERE UPPER(op.status) = UPPER($1)';
                params.push(status);
            }
            query += ' ORDER BY op."createdAt" DESC LIMIT 50';
            const operations = await this.dataSource.query(query, params);
            console.log(`OperationsSimpleController.findAll: Найдено ${operations.length} операций`);
            return operations;
        }
        catch (error) {
            console.error('OperationsSimpleController.findAll: Ошибка:', error);
            throw error;
        }
    }
};
exports.OperationsSimpleController = OperationsSimpleController;
__decorate([
    (0, common_1.Get)('test'),
    (0, swagger_1.ApiOperation)({ summary: 'Тестовый endpoint для операций' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], OperationsSimpleController.prototype, "test", null);
__decorate([
    (0, common_1.Get)('assigned-to-machine/:machineId'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить назначенную операцию для станка с данными заказа' }),
    __param(0, (0, common_1.Param)('machineId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OperationsSimpleController.prototype, "getAssignedOperationByMachine", null);
__decorate([
    (0, common_1.Get)('active'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить активные операции' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], OperationsSimpleController.prototype, "getActiveOperations", null);
__decorate([
    (0, common_1.Get)(':id/details'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить детальную информацию об операции' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OperationsSimpleController.prototype, "getOperationDetails", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Получить все операции' }),
    __param(0, (0, common_1.Query)('status')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OperationsSimpleController.prototype, "findAll", null);
exports.OperationsSimpleController = OperationsSimpleController = __decorate([
    (0, swagger_1.ApiTags)('operations-simple'),
    (0, common_1.Controller)('operations'),
    __param(0, (0, typeorm_1.InjectDataSource)()),
    __metadata("design:paramtypes", [typeorm_2.DataSource])
], OperationsSimpleController);
//# sourceMappingURL=operations-simple.controller.js.map