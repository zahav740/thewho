export declare class OperationsModule {
}
