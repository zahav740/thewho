"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationsModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const operation_entity_1 = require("../../database/entities/operation.entity");
const shift_record_entity_1 = require("../../database/entities/shift-record.entity");
const order_entity_1 = require("../../database/entities/order.entity");
const machine_entity_1 = require("../../database/entities/machine.entity");
const operations_simple_controller_1 = require("./operations-simple.controller");
const operation_history_service_1 = require("./operation-history.service");
const operation_history_controller_1 = require("./operation-history.controller");
const progress_tracking_service_1 = require("./progress-tracking.service");
const progress_tracking_controller_1 = require("./progress-tracking.controller");
const operation_analytics_service_1 = require("./operation-analytics.service");
const operation_management_controller_1 = require("./operation-management.controller");
const operation_completion_controller_1 = require("./operation-completion.controller");
const operation_completion_check_controller_1 = require("./operation-completion-check.controller");
const operation_completion_extended_controller_1 = require("./operation-completion-extended.controller");
let OperationsModule = class OperationsModule {
};
exports.OperationsModule = OperationsModule;
exports.OperationsModule = OperationsModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([operation_entity_1.Operation, shift_record_entity_1.ShiftRecord, order_entity_1.Order, machine_entity_1.Machine])
        ],
        controllers: [
            operations_simple_controller_1.OperationsSimpleController,
            operation_history_controller_1.OperationHistoryController,
            progress_tracking_controller_1.ProgressTrackingController,
            operation_management_controller_1.OperationManagementController,
            operation_completion_controller_1.OperationCompletionController,
            operation_completion_check_controller_1.OperationCompletionCheckController,
            operation_completion_extended_controller_1.OperationCompletionExtendedController
        ],
        providers: [
            operation_history_service_1.OperationHistoryService,
            progress_tracking_service_1.ProgressTrackingService,
            operation_analytics_service_1.OperationAnalyticsService
        ],
        exports: [
            operation_history_service_1.OperationHistoryService,
            progress_tracking_service_1.ProgressTrackingService,
            operation_analytics_service_1.OperationAnalyticsService
        ],
    })
], OperationsModule);
//# sourceMappingURL=operations.module.js.map