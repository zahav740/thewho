import { ProgressTrackingService } from './progress-tracking.service';
export declare class UpdateProgressDto {
    completedUnits: number;
    totalUnits: number;
}
export declare class ProgressTrackingController {
    private readonly progressService;
    constructor(progressService: ProgressTrackingService);
    updateProgress(operationId: string, updateProgressDto: UpdateProgressDto): Promise<{
        success: boolean;
        message: string;
        data: import("./progress-tracking.service").OperationProgress;
        error?: undefined;
    } | {
        success: boolean;
        message: string;
        error: any;
        data?: undefined;
    }>;
    getOperationProgress(operationId: string): Promise<{
        success: boolean;
        data: import("./progress-tracking.service").OperationProgress;
        message?: undefined;
        error?: undefined;
    } | {
        success: boolean;
        message: string;
        error: any;
        data?: undefined;
    }>;
    startOperation(operationId: string): Promise<{
        success: boolean;
        message: string;
        error?: undefined;
    } | {
        success: boolean;
        message: string;
        error: any;
    }>;
    completeOperation(operationId: string): Promise<{
        success: boolean;
        message: string;
        error?: undefined;
    } | {
        success: boolean;
        message: string;
        error: any;
    }>;
    getProductionMetrics(): Promise<{
        success: boolean;
        data: import("./progress-tracking.service").ProductionMetrics;
        timestamp: Date;
        message?: undefined;
        error?: undefined;
    } | {
        success: boolean;
        message: string;
        error: any;
        data?: undefined;
        timestamp?: undefined;
    }>;
    getActiveOperationsWithProgress(): Promise<{
        success: boolean;
        data: any;
        count: any;
        message?: undefined;
        error?: undefined;
    } | {
        success: boolean;
        message: string;
        error: any;
        data?: undefined;
        count?: undefined;
    }>;
    getDashboardData(): Promise<{
        success: boolean;
        data: {
            metrics: import("./progress-tracking.service").ProductionMetrics;
            activeOperations: any;
            summary: {
                totalOperations: number;
                averageProgress: number;
                machineUtilization: number;
                dailyProduction: number;
            };
        };
        timestamp: Date;
        message?: undefined;
        error?: undefined;
    } | {
        success: boolean;
        message: string;
        error: any;
        data?: undefined;
        timestamp?: undefined;
    }>;
    test(): Promise<{
        status: string;
        message: string;
        timestamp: string;
        endpoints: string[];
        error?: undefined;
    } | {
        status: string;
        error: any;
        timestamp: string;
        message?: undefined;
        endpoints?: undefined;
    }>;
}
