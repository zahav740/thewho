"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProgressTrackingController = exports.UpdateProgressDto = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const progress_tracking_service_1 = require("./progress-tracking.service");
class UpdateProgressDto {
}
exports.UpdateProgressDto = UpdateProgressDto;
let ProgressTrackingController = class ProgressTrackingController {
    constructor(progressService) {
        this.progressService = progressService;
    }
    async updateProgress(operationId, updateProgressDto) {
        try {
            console.log('ProgressController: Обновление прогресса операции:', operationId, updateProgressDto);
            const result = await this.progressService.updateProgress(parseInt(operationId), updateProgressDto.completedUnits, updateProgressDto.totalUnits);
            return {
                success: true,
                message: 'Прогресс обновлен успешно',
                data: result
            };
        }
        catch (error) {
            console.error('ProgressController.updateProgress ошибка:', error);
            return {
                success: false,
                message: 'Ошибка при обновлении прогресса',
                error: error.message
            };
        }
    }
    async getOperationProgress(operationId) {
        try {
            const result = await this.progressService.getOperationProgress(parseInt(operationId));
            return {
                success: true,
                data: result
            };
        }
        catch (error) {
            console.error('ProgressController.getOperationProgress ошибка:', error);
            return {
                success: false,
                message: 'Ошибка при получении прогресса',
                error: error.message
            };
        }
    }
    async startOperation(operationId) {
        try {
            await this.progressService.startOperation(parseInt(operationId));
            return {
                success: true,
                message: 'Операция начата успешно'
            };
        }
        catch (error) {
            console.error('ProgressController.startOperation ошибка:', error);
            return {
                success: false,
                message: 'Ошибка при запуске операции',
                error: error.message
            };
        }
    }
    async completeOperation(operationId) {
        try {
            await this.progressService.completeOperation(parseInt(operationId));
            return {
                success: true,
                message: 'Операция завершена успешно'
            };
        }
        catch (error) {
            console.error('ProgressController.completeOperation ошибка:', error);
            return {
                success: false,
                message: 'Ошибка при завершении операции',
                error: error.message
            };
        }
    }
    async getProductionMetrics() {
        try {
            const metrics = await this.progressService.getProductionMetrics();
            return {
                success: true,
                data: metrics,
                timestamp: new Date()
            };
        }
        catch (error) {
            console.error('ProgressController.getProductionMetrics ошибка:', error);
            return {
                success: false,
                message: 'Ошибка при получении метрик',
                error: error.message
            };
        }
    }
    async getActiveOperationsWithProgress() {
        try {
            const operations = await this.progressService.getActiveOperationsWithProgress();
            return {
                success: true,
                data: operations,
                count: operations.length
            };
        }
        catch (error) {
            console.error('ProgressController.getActiveOperationsWithProgress ошибка:', error);
            return {
                success: false,
                message: 'Ошибка при получении активных операций',
                error: error.message
            };
        }
    }
    async getDashboardData() {
        try {
            const [metrics, activeOperations] = await Promise.all([
                this.progressService.getProductionMetrics(),
                this.progressService.getActiveOperationsWithProgress()
            ]);
            return {
                success: true,
                data: {
                    metrics,
                    activeOperations,
                    summary: {
                        totalOperations: metrics.totalOperations,
                        averageProgress: metrics.averageProgress,
                        machineUtilization: metrics.machineUtilization,
                        dailyProduction: metrics.dailyProduction
                    }
                },
                timestamp: new Date()
            };
        }
        catch (error) {
            console.error('ProgressController.getDashboardData ошибка:', error);
            return {
                success: false,
                message: 'Ошибка при получении данных дашборда',
                error: error.message
            };
        }
    }
    async test() {
        try {
            return {
                status: 'ok',
                message: 'Progress tracking service is working',
                timestamp: new Date().toISOString(),
                endpoints: [
                    'PUT /progress/operation/:operationId - Обновить прогресс',
                    'GET /progress/operation/:operationId - Получить прогресс',
                    'POST /progress/operation/:operationId/start - Начать операцию',
                    'POST /progress/operation/:operationId/complete - Завершить операцию',
                    'GET /progress/metrics - Производственные метрики',
                    'GET /progress/active-operations - Активные операции',
                    'GET /progress/dashboard - Данные дашборда'
                ]
            };
        }
        catch (error) {
            return {
                status: 'error',
                error: error.message,
                timestamp: new Date().toISOString()
            };
        }
    }
};
exports.ProgressTrackingController = ProgressTrackingController;
__decorate([
    (0, common_1.Put)('operation/:operationId'),
    (0, swagger_1.ApiOperation)({ summary: 'Обновить прогресс операции' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Прогресс обновлен успешно' }),
    __param(0, (0, common_1.Param)('operationId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, UpdateProgressDto]),
    __metadata("design:returntype", Promise)
], ProgressTrackingController.prototype, "updateProgress", null);
__decorate([
    (0, common_1.Get)('operation/:operationId'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить прогресс операции' }),
    __param(0, (0, common_1.Param)('operationId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ProgressTrackingController.prototype, "getOperationProgress", null);
__decorate([
    (0, common_1.Post)('operation/:operationId/start'),
    (0, swagger_1.ApiOperation)({ summary: 'Начать операцию' }),
    __param(0, (0, common_1.Param)('operationId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ProgressTrackingController.prototype, "startOperation", null);
__decorate([
    (0, common_1.Post)('operation/:operationId/complete'),
    (0, swagger_1.ApiOperation)({ summary: 'Завершить операцию' }),
    __param(0, (0, common_1.Param)('operationId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ProgressTrackingController.prototype, "completeOperation", null);
__decorate([
    (0, common_1.Get)('metrics'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить производственные метрики' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ProgressTrackingController.prototype, "getProductionMetrics", null);
__decorate([
    (0, common_1.Get)('active-operations'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить активные операции с прогрессом' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ProgressTrackingController.prototype, "getActiveOperationsWithProgress", null);
__decorate([
    (0, common_1.Get)('dashboard'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить данные для дашборда мониторинга' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ProgressTrackingController.prototype, "getDashboardData", null);
__decorate([
    (0, common_1.Get)('test'),
    (0, swagger_1.ApiOperation)({ summary: 'Тестовый endpoint' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ProgressTrackingController.prototype, "test", null);
exports.ProgressTrackingController = ProgressTrackingController = __decorate([
    (0, swagger_1.ApiTags)('progress-tracking'),
    (0, common_1.Controller)('progress'),
    __metadata("design:paramtypes", [progress_tracking_service_1.ProgressTrackingService])
], ProgressTrackingController);
//# sourceMappingURL=progress-tracking.controller.js.map