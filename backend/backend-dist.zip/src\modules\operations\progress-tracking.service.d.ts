import { DataSource } from 'typeorm';
export interface OperationProgress {
    id: number;
    operationId: number;
    completedUnits: number;
    totalUnits: number;
    progressPercentage: number;
    startedAt?: Date;
    lastUpdated: Date;
}
export interface ProductionMetrics {
    totalOperations: number;
    completedOperations: number;
    inProgressOperations: number;
    pendingOperations: number;
    averageProgress: number;
    dailyProduction: number;
    machineUtilization: number;
}
export declare class ProgressTrackingService {
    private readonly dataSource;
    constructor(dataSource: DataSource);
    updateProgress(operationId: number, completedUnits: number, totalUnits: number): Promise<OperationProgress>;
    getOperationProgress(operationId: number): Promise<OperationProgress>;
    startOperation(operationId: number): Promise<void>;
    completeOperation(operationId: number): Promise<void>;
    getProductionMetrics(): Promise<ProductionMetrics>;
    private getOperationStatistics;
    private getDailyProduction;
    private getMachineUtilization;
    getActiveOperationsWithProgress(): Promise<any>;
}
