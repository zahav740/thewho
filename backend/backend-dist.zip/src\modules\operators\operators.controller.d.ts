import { DataSource } from 'typeorm';
export interface Operator {
    id: number;
    name: string;
    isActive: boolean;
    operatorType: 'SETUP' | 'PRODUCTION' | 'BOTH';
    createdAt: string;
    updatedAt: string;
}
export interface CreateOperatorDto {
    name: string;
    operatorType?: 'SETUP' | 'PRODUCTION' | 'BOTH';
}
export interface UpdateOperatorDto {
    name?: string;
    isActive?: boolean;
    operatorType?: 'SETUP' | 'PRODUCTION' | 'BOTH';
}
export declare class OperatorsController {
    private readonly dataSource;
    constructor(dataSource: DataSource);
    test(): Promise<{
        status: string;
        message: string;
        suggestion: string;
        timestamp: string;
        tableExists?: undefined;
        count?: undefined;
        sample?: undefined;
        error?: undefined;
    } | {
        status: string;
        message: string;
        tableExists: boolean;
        count: any;
        sample: any;
        timestamp: string;
        suggestion?: undefined;
        error?: undefined;
    } | {
        status: string;
        error: any;
        suggestion: string;
        timestamp: string;
        message?: undefined;
        tableExists?: undefined;
        count?: undefined;
        sample?: undefined;
    }>;
    getAllOperators(type?: string, active?: string): Promise<Operator[]>;
    getSetupOperators(): Promise<Operator[]>;
    getProductionOperators(): Promise<Operator[]>;
    getOperatorById(id: string): Promise<Operator>;
    createOperator(createOperatorDto: CreateOperatorDto): Promise<Operator>;
    updateOperator(id: string, updateOperatorDto: UpdateOperatorDto): Promise<Operator>;
    deleteOperator(id: string): Promise<{
        message: string;
    }>;
}
