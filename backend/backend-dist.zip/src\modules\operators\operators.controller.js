"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperatorsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
let OperatorsController = class OperatorsController {
    constructor(dataSource) {
        this.dataSource = dataSource;
    }
    async test() {
        try {
            console.log('OperatorsController.test: Тест API операторов');
            const tableExists = await this.dataSource.query(`
        SELECT table_name 
        FROM information_schema.tables 
        WHERE table_name = 'operators'
      `);
            if (tableExists.length === 0) {
                return {
                    status: 'error',
                    message: 'Таблица operators не существует',
                    suggestion: 'Запустите ПРИМЕНИТЬ-ТАБЛИЦУ-ОПЕРАТОРОВ.bat',
                    timestamp: new Date().toISOString(),
                };
            }
            const count = await this.dataSource.query('SELECT COUNT(*) as count FROM operators');
            const sample = await this.dataSource.query('SELECT * FROM operators LIMIT 3');
            return {
                status: 'ok',
                message: 'Operators API is working',
                tableExists: true,
                count: count[0]?.count || 0,
                sample,
                timestamp: new Date().toISOString(),
            };
        }
        catch (error) {
            console.error('OperatorsController.test: Ошибка:', error);
            return {
                status: 'error',
                error: error.message,
                suggestion: 'Проверьте подключение к PostgreSQL и создайте таблицу operators',
                timestamp: new Date().toISOString(),
            };
        }
    }
    async getAllOperators(type, active) {
        try {
            console.log('OperatorsController.getAllOperators: Получение операторов', { type, active });
            let query = `
        SELECT 
          id,
          name,
          "isActive",
          "operatorType",
          "createdAt",
          "updatedAt"
        FROM operators
        WHERE 1=1
      `;
            const params = [];
            let paramIndex = 1;
            if (active !== undefined) {
                query += ` AND "isActive" = $${paramIndex}`;
                params.push(active === 'true');
                paramIndex++;
            }
            if (type) {
                query += ` AND ("operatorType" = $${paramIndex} OR "operatorType" = 'BOTH')`;
                params.push(type.toUpperCase());
                paramIndex++;
            }
            query += ' ORDER BY name ASC';
            const operators = await this.dataSource.query(query, params);
            console.log(`OperatorsController.getAllOperators: Найдено ${operators.length} операторов`);
            return operators;
        }
        catch (error) {
            console.error('OperatorsController.getAllOperators: Ошибка:', error);
            throw error;
        }
    }
    async getSetupOperators() {
        return this.getAllOperators('SETUP', 'true');
    }
    async getProductionOperators() {
        return this.getAllOperators('PRODUCTION', 'true');
    }
    async getOperatorById(id) {
        try {
            const operators = await this.dataSource.query('SELECT * FROM operators WHERE id = $1', [parseInt(id)]);
            if (operators.length === 0) {
                throw new Error('Оператор не найден');
            }
            return operators[0];
        }
        catch (error) {
            console.error('OperatorsController.getOperatorById: Ошибка:', error);
            throw error;
        }
    }
    async createOperator(createOperatorDto) {
        try {
            console.log('OperatorsController.createOperator: Создание оператора:', createOperatorDto);
            const existing = await this.dataSource.query('SELECT id FROM operators WHERE name = $1', [createOperatorDto.name]);
            if (existing.length > 0) {
                throw new Error('Оператор с таким именем уже существует');
            }
            const result = await this.dataSource.query(`INSERT INTO operators (name, "operatorType") 
         VALUES ($1, $2) 
         RETURNING *`, [
                createOperatorDto.name,
                createOperatorDto.operatorType || 'BOTH'
            ]);
            console.log('OperatorsController.createOperator: Оператор создан:', result[0]);
            return result[0];
        }
        catch (error) {
            console.error('OperatorsController.createOperator: Ошибка:', error);
            throw error;
        }
    }
    async updateOperator(id, updateOperatorDto) {
        try {
            console.log('OperatorsController.updateOperator: Обновление оператора:', id, updateOperatorDto);
            const setClauses = [];
            const params = [];
            let paramIndex = 1;
            if (updateOperatorDto.name !== undefined) {
                setClauses.push(`name = $${paramIndex}`);
                params.push(updateOperatorDto.name);
                paramIndex++;
            }
            if (updateOperatorDto.isActive !== undefined) {
                setClauses.push(`"isActive" = $${paramIndex}`);
                params.push(updateOperatorDto.isActive);
                paramIndex++;
            }
            if (updateOperatorDto.operatorType !== undefined) {
                setClauses.push(`"operatorType" = $${paramIndex}`);
                params.push(updateOperatorDto.operatorType);
                paramIndex++;
            }
            setClauses.push(`"updatedAt" = NOW()`);
            if (setClauses.length === 1) {
                throw new Error('Нет данных для обновления');
            }
            params.push(parseInt(id));
            const query = `
        UPDATE operators 
        SET ${setClauses.join(', ')}
        WHERE id = $${paramIndex}
        RETURNING *
      `;
            const result = await this.dataSource.query(query, params);
            if (result.length === 0) {
                throw new Error('Оператор не найден');
            }
            console.log('OperatorsController.updateOperator: Оператор обновлен:', result[0]);
            return result[0];
        }
        catch (error) {
            console.error('OperatorsController.updateOperator: Ошибка:', error);
            throw error;
        }
    }
    async deleteOperator(id) {
        try {
            console.log('OperatorsController.deleteOperator: Удаление оператора:', id);
            const result = await this.dataSource.query(`UPDATE operators 
         SET "isActive" = false, "updatedAt" = NOW()
         WHERE id = $1
         RETURNING name`, [parseInt(id)]);
            if (result.length === 0) {
                throw new Error('Оператор не найден');
            }
            console.log('OperatorsController.deleteOperator: Оператор деактивирован:', result[0].name);
            return { message: `Оператор ${result[0].name} деактивирован` };
        }
        catch (error) {
            console.error('OperatorsController.deleteOperator: Ошибка:', error);
            throw error;
        }
    }
};
exports.OperatorsController = OperatorsController;
__decorate([
    (0, common_1.Get)('test'),
    (0, swagger_1.ApiOperation)({ summary: 'Тестовый endpoint для операторов' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], OperatorsController.prototype, "test", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Получить всех операторов' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Список операторов' }),
    __param(0, (0, common_1.Query)('type')),
    __param(1, (0, common_1.Query)('active')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], OperatorsController.prototype, "getAllOperators", null);
__decorate([
    (0, common_1.Get)('setup'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить операторов наладки' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], OperatorsController.prototype, "getSetupOperators", null);
__decorate([
    (0, common_1.Get)('production'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить операторов производства' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], OperatorsController.prototype, "getProductionOperators", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить оператора по ID' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OperatorsController.prototype, "getOperatorById", null);
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Создать нового оператора' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: 'Оператор создан' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], OperatorsController.prototype, "createOperator", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Обновить оператора' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], OperatorsController.prototype, "updateOperator", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Удалить оператора (мягкое удаление)' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OperatorsController.prototype, "deleteOperator", null);
exports.OperatorsController = OperatorsController = __decorate([
    (0, swagger_1.ApiTags)('operators'),
    (0, common_1.Controller)('operators'),
    __param(0, (0, typeorm_1.InjectDataSource)()),
    __metadata("design:paramtypes", [typeorm_2.DataSource])
], OperatorsController);
//# sourceMappingURL=operators.controller.js.map