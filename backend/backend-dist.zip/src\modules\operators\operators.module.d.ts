export declare class OperatorsModule {
}
