import { OperationType } from '../../../database/entities/operation.entity';
export declare class CreateOperationDto {
    operationNumber: number;
    operationType: OperationType;
    machineAxes: number;
    estimatedTime: number;
}
export declare class CreateOrderDto {
    drawingNumber: string;
    quantity: number;
    deadline: string;
    priority: number;
    workType?: string;
    operations: CreateOperationDto[];
}
