"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateOrderDto = exports.CreateOperationDto = void 0;
const class_validator_1 = require("class-validator");
const swagger_1 = require("@nestjs/swagger");
const class_transformer_1 = require("class-transformer");
const operation_entity_1 = require("../../../database/entities/operation.entity");
class CreateOperationDto {
}
exports.CreateOperationDto = CreateOperationDto;
__decorate([
    (0, swagger_1.ApiProperty)({ example: 1, description: 'Номер операции' }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], CreateOperationDto.prototype, "operationNumber", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ enum: operation_entity_1.OperationType, description: 'Тип операции' }),
    (0, class_validator_1.IsEnum)(operation_entity_1.OperationType),
    __metadata("design:type", String)
], CreateOperationDto.prototype, "operationType", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 3, description: 'Количество осей станка' }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(3),
    __metadata("design:type", Number)
], CreateOperationDto.prototype, "machineAxes", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 120, description: 'Время выполнения в минутах' }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], CreateOperationDto.prototype, "estimatedTime", void 0);
class CreateOrderDto {
}
exports.CreateOrderDto = CreateOrderDto;
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'DRW-2024-001', description: 'Номер чертежа' }),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateOrderDto.prototype, "drawingNumber", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 100, description: 'Количество деталей' }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.Min)(1),
    __metadata("design:type", Number)
], CreateOrderDto.prototype, "quantity", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: '2024-12-31', description: 'Срок выполнения' }),
    (0, class_validator_1.IsDateString)(),
    __metadata("design:type", String)
], CreateOrderDto.prototype, "deadline", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 1, description: 'Приоритет заказа (1-высокий, 2-средний, 3-низкий)' }),
    (0, class_validator_1.IsNotEmpty)(),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsIn)([1, 2, 3, 4]),
    __metadata("design:type", Number)
], CreateOrderDto.prototype, "priority", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 'Фрезерная обработка', description: 'Тип работы' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateOrderDto.prototype, "workType", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ type: [CreateOperationDto], description: 'Операции заказа' }),
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => CreateOperationDto),
    __metadata("design:type", Array)
], CreateOrderDto.prototype, "operations", void 0);
//# sourceMappingURL=create-order.dto.js.map