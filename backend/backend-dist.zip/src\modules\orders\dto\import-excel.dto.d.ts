export declare class ImportExcelDto {
    colorFilters?: string[];
}
