export declare class OrdersFilterDto {
    page?: number;
    limit?: number;
    priority?: string;
    search?: string;
    status?: string;
}
