import { OperationType } from '../../../database/entities/operation.entity';
export declare class UpdateOperationDto {
    operationNumber: number;
    operationType: OperationType;
    machineAxes: number;
    estimatedTime: number;
    id?: string;
    status?: string;
    completedUnits?: number;
}
export declare class UpdateOrderDto {
    drawingNumber?: string;
    quantity?: number;
    deadline?: string;
    priority?: number;
    workType?: string;
    operations?: UpdateOperationDto[];
}
