import { Repository } from 'typeorm';
import { Order } from '../../database/entities/order.entity';
import { Operation } from '../../database/entities/operation.entity';
import { OrdersService } from './orders.service';
import type { Express } from 'express';
export interface ColorFilter {
    color: string;
    label: string;
    description: string;
    priority: number;
    selected: boolean;
}
export interface ImportSettings {
    colorFilters: ColorFilter[];
    columnMapping: ColumnMapping[];
    importOnlySelected: boolean;
    clearExistingData?: boolean;
    skipDuplicates?: boolean;
}
export interface ColumnMapping {
    fieldName: string;
    excelColumn: string;
    description: string;
    required?: boolean;
}
export interface EnhancedImportResult {
    totalRows: number;
    processedRows: number;
    skippedRows: number;
    created: number;
    updated: number;
    duplicatesSkipped: number;
    errors: Array<{
        row: number;
        order: string;
        error: string;
        color?: string;
    }>;
    colorStatistics: Record<string, number>;
    summary: {
        greenOrders: number;
        yellowOrders: number;
        redOrders: number;
        blueOrders: number;
    };
    filters: {
        applied: ColorFilter[];
        total: number;
        selected: number;
    };
}
export declare class EnhancedExcelImportService {
    private readonly orderRepository;
    private readonly operationRepository;
    private readonly ordersService;
    constructor(orderRepository: Repository<Order>, operationRepository: Repository<Operation>, ordersService: OrdersService);
    importFullExcelWithFilters(file: Express.Multer.File, settings: ImportSettings): Promise<EnhancedImportResult>;
    private parseExcelWithColors;
    private determineRowColor;
    private getCellColor;
    private shouldProcessRowByFilters;
    private parseRowToOrder;
    private parsePriorityFromColorAndText;
    private parseDate;
    private parseOperations;
    private parseOperationType;
    private importOrdersToDatabase;
    private createNewOrder;
    private updateExistingOrder;
    private clearExistingOrders;
}
