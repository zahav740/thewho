import type { Express } from 'express';
import { OrdersService } from './orders.service';
import { EnhancedExcelImportService, EnhancedImportResult } from './enhanced-excel-import.service';
import { ExcelPreviewService, ExcelPreviewResult } from './excel-preview.service';
import { CreateOrderDto } from './dto/create-order.dto';
import { UpdateOrderDto } from './dto/update-order.dto';
import { OrdersFilterDto } from './dto/orders-filter.dto';
import { Order } from '../../database/entities/order.entity';
export declare class EnhancedOrdersController {
    private readonly ordersService;
    private readonly enhancedExcelImportService;
    private readonly excelPreviewService;
    constructor(ordersService: OrdersService, enhancedExcelImportService: EnhancedExcelImportService, excelPreviewService: ExcelPreviewService);
    findAll(filterDto: OrdersFilterDto): Promise<{
        data: {
            name: string;
            clientName: string;
            remainingQuantity: number;
            status: string;
            completionPercentage: number;
            forecastedCompletionDate: Date;
            isOnSchedule: boolean;
            lastRecalculationAt: Date;
            operations: import("../../database/entities").Operation[];
            id: number;
            drawingNumber: string;
            deadline: Date;
            quantity: number;
            priority: number;
            workType: string;
            pdfPath: string;
            pdfUrl?: string;
            createdAt: Date;
            updatedAt: Date;
        }[];
        total: number;
        page: number;
        limit: number;
        totalPages: number;
    }>;
    findOne(id: string): Promise<Order>;
    create(createOrderDto: CreateOrderDto): Promise<Order>;
    update(id: string, updateOrderDto: UpdateOrderDto): Promise<Order>;
    remove(id: string): Promise<void>;
    removeBatch(ids: string[]): Promise<{
        deleted: number;
    }>;
    removeAll(confirm: boolean): Promise<{
        deleted: number;
    }>;
    uploadExcelFull(file: Express.Multer.File, body: any): Promise<{
        success: boolean;
        message: string;
        data: EnhancedImportResult;
        file: any;
    }>;
    analyzeExcelFile(file: Express.Multer.File): Promise<{
        success: boolean;
        data: ExcelPreviewResult;
        message: string;
    }>;
    previewExcel(file: Express.Multer.File): Promise<{
        success: boolean;
        preview: any[];
        statistics: any;
        recommendedFilters: any[];
        totalRows: number;
    }>;
    private getDefaultImportSettings;
    private getColorLabel;
    private getDefaultColumnMapping;
    importSelectedOrders(file: Express.Multer.File, body: {
        selectedOrders: string;
        clearExisting: string;
        skipDuplicates: string;
        colorFilters: string;
    }): Promise<{
        success: boolean;
        message: string;
        data: EnhancedImportResult;
    }>;
}
