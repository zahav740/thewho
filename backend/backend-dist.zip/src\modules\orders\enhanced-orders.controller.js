"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnhancedOrdersController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const orders_service_1 = require("./orders.service");
const enhanced_excel_import_service_1 = require("./enhanced-excel-import.service");
const excel_preview_service_1 = require("./excel-preview.service");
const create_order_dto_1 = require("./dto/create-order.dto");
const update_order_dto_1 = require("./dto/update-order.dto");
const orders_filter_dto_1 = require("./dto/orders-filter.dto");
let EnhancedOrdersController = class EnhancedOrdersController {
    constructor(ordersService, enhancedExcelImportService, excelPreviewService) {
        this.ordersService = ordersService;
        this.enhancedExcelImportService = enhancedExcelImportService;
        this.excelPreviewService = excelPreviewService;
    }
    async findAll(filterDto) {
        return this.ordersService.findAll(filterDto);
    }
    async findOne(id) {
        return this.ordersService.findOne(id);
    }
    async create(createOrderDto) {
        return this.ordersService.create(createOrderDto);
    }
    async update(id, updateOrderDto) {
        return this.ordersService.update(id, updateOrderDto);
    }
    async remove(id) {
        return this.ordersService.remove(id);
    }
    async removeBatch(ids) {
        const deleted = await this.ordersService.removeBatch(ids);
        return { deleted };
    }
    async removeAll(confirm) {
        if (!confirm) {
            throw new Error('Подтверждение удаления обязательно');
        }
        const deleted = await this.ordersService.removeAll();
        return { deleted };
    }
    async uploadExcelFull(file, body) {
        try {
            console.log('🚀 ПОЛНЫЙ ИМПОРТ EXCEL: Получен файл:', {
                originalname: file?.originalname,
                size: file?.size,
                mimetype: file?.mimetype,
                hasBuffer: !!file?.buffer,
                bufferSize: file?.buffer?.length,
                bodyData: Object.keys(body || {})
            });
            if (!file || !file.buffer) {
                throw new Error('Файл не получен или отсутствует buffer');
            }
            let importSettings;
            try {
                importSettings = body.importSettings ? JSON.parse(body.importSettings) : this.getDefaultImportSettings();
                console.log('📋 ПОЛНЫЙ ИМПОРТ: Настройки импорта:', {
                    colorFiltersCount: importSettings.colorFilters?.length || 0,
                    selectedFiltersCount: importSettings.colorFilters?.filter(f => f.selected)?.length || 0,
                    importOnlySelected: importSettings.importOnlySelected,
                    clearExisting: importSettings.clearExistingData,
                    skipDuplicates: importSettings.skipDuplicates
                });
            }
            catch (parseError) {
                console.error('⚠️ ПОЛНЫЙ ИМПОРТ: Ошибка парсинга настроек, используем настройки по умолчанию:', parseError);
                importSettings = this.getDefaultImportSettings();
            }
            console.log('🔄 ПОЛНЫЙ ИМПОРТ: Начинаем импорт в базу данных...');
            const result = await this.enhancedExcelImportService.importFullExcelWithFilters(file, importSettings);
            console.log('✅ ПОЛНЫЙ ИМПОРТ: Импорт завершен успешно:', {
                totalRows: result.totalRows,
                processedRows: result.processedRows,
                created: result.created,
                updated: result.updated,
                errors: result.errors?.length || 0,
                summary: result.summary
            });
            return {
                success: true,
                message: `Полный импорт завершен! Обработано ${result.processedRows} из ${result.totalRows} строк. Создано: ${result.created}, Обновлено: ${result.updated}`,
                data: result,
                file: {
                    originalname: file.originalname,
                    size: file.size,
                    fullImport: true,
                    bufferProcessed: true
                }
            };
        }
        catch (error) {
            console.error('❌ ПОЛНЫЙ ИМПОРТ: Критическая ошибка:', error);
            return {
                success: false,
                message: `Ошибка полного импорта: ${error.message}`,
                data: null,
                file: {
                    originalname: file?.originalname || 'unknown',
                    size: file?.size || 0,
                    error: error.message
                }
            };
        }
    }
    async analyzeExcelFile(file) {
        try {
            console.log('🔍 АНАЛИЗ EXCEL: Получен файл для анализа:', file.originalname);
            const analysisResult = await this.excelPreviewService.analyzeExcelFile(file);
            console.log('✅ АНАЛИЗ ЗАВЕРШЕН:', {
                fileName: analysisResult.fileName,
                totalOrders: analysisResult.orders.length,
                colorsFound: Object.keys(analysisResult.colorStatistics).length
            });
            return {
                success: true,
                data: analysisResult,
                message: `Найдено ${analysisResult.orders.length} заказов в файле ${analysisResult.fileName}`
            };
        }
        catch (error) {
            console.error('❌ АНАЛИЗ EXCEL: Ошибка:', error);
            throw error;
        }
    }
    async previewExcel(file) {
        try {
            console.log('👁️ ПРЕВЬЮ EXCEL: Анализ файла:', file.originalname);
            const previewSettings = {
                ...this.getDefaultImportSettings(),
                importOnlySelected: false,
                clearExistingData: false
            };
            const result = await this.enhancedExcelImportService.importFullExcelWithFilters(file, {
                ...previewSettings,
                clearExistingData: false
            });
            const preview = result.errors.slice(0, 10).map((error, index) => ({
                row: error.row,
                order: error.order,
                color: error.color,
                preview: true
            }));
            const recommendedFilters = Object.entries(result.colorStatistics)
                .filter(([color, count]) => count > 0)
                .map(([color, count]) => ({
                color,
                count,
                label: this.getColorLabel(color),
                description: `Найдено ${count} строк`,
                recommended: true
            }));
            console.log('✅ ПРЕВЬЮ: Анализ завершен:', {
                totalRows: result.totalRows,
                colorsFound: Object.keys(result.colorStatistics).length,
                recommendedFilters: recommendedFilters.length
            });
            return {
                success: true,
                preview,
                statistics: result.colorStatistics,
                recommendedFilters,
                totalRows: result.totalRows
            };
        }
        catch (error) {
            console.error('❌ ПРЕВЬЮ: Ошибка анализа:', error);
            throw error;
        }
    }
    getDefaultImportSettings() {
        return {
            colorFilters: [
                {
                    color: 'green',
                    label: 'Зеленый (Готовые)',
                    description: 'Заказы готовые к производству',
                    priority: 1,
                    selected: true
                },
                {
                    color: 'yellow',
                    label: 'Желтый (Обычные)',
                    description: 'Стандартные заказы',
                    priority: 2,
                    selected: true
                },
                {
                    color: 'red',
                    label: 'Красный (Критичные)',
                    description: 'Срочные заказы высокого приоритета',
                    priority: 3,
                    selected: true
                },
                {
                    color: 'blue',
                    label: 'Синий (Плановые)',
                    description: 'Плановые заказы',
                    priority: 4,
                    selected: true
                },
            ],
            columnMapping: [
                { fieldName: 'Номер чертежа', excelColumn: 'C', description: 'Уникальный номер чертежа', required: true },
                { fieldName: 'Количество', excelColumn: 'E', description: 'Количество изделий', required: true },
                { fieldName: 'Срок', excelColumn: 'H', description: 'Дедлайн выполнения заказа' },
                { fieldName: 'Приоритет', excelColumn: 'K', description: 'Приоритет выполнения заказа' },
                { fieldName: 'Тип работы', excelColumn: 'F', description: 'Описание типа работ' },
            ],
            importOnlySelected: false,
            clearExistingData: false,
            skipDuplicates: true
        };
    }
    getColorLabel(color) {
        const labels = {
            green: 'Зеленый (Готовые)',
            yellow: 'Желтый (Обычные)',
            red: 'Красный (Критичные)',
            blue: 'Синий (Плановые)',
            other: 'Другие цвета'
        };
        return labels[color] || `Цвет: ${color}`;
    }
    getDefaultColumnMapping() {
        return [
            { fieldName: 'Номер чертежа', excelColumn: 'C', description: 'Уникальный номер чертежа', required: true },
            { fieldName: 'Количество', excelColumn: 'E', description: 'Количество изделий', required: true },
            { fieldName: 'Срок', excelColumn: 'H', description: 'Дедлайн выполнения заказа' },
            { fieldName: 'Приоритет', excelColumn: 'K', description: 'Приоритет выполнения заказа' },
            { fieldName: 'Тип работы', excelColumn: 'F', description: 'Описание типа работ' },
        ];
    }
    async importSelectedOrders(file, body) {
        try {
            console.log('🎯 ВЫБОРОЧНЫЙ ИМПОРТ: Начало импорта выбранных заказов:', {
                fileName: file.originalname,
                bodyKeys: Object.keys(body)
            });
            const selectedOrders = JSON.parse(body.selectedOrders || '[]');
            const clearExisting = body.clearExisting === 'true';
            const skipDuplicates = body.skipDuplicates !== 'false';
            const colorFilters = JSON.parse(body.colorFilters || '[]');
            console.log('📋 НАСТРОЙКИ ИМПОРТА:', {
                selectedOrdersCount: selectedOrders.length,
                clearExisting,
                skipDuplicates,
                colorFiltersCount: colorFilters.length
            });
            const importSettings = {
                colorFilters: colorFilters.map(color => ({
                    color,
                    label: this.getColorLabel(color),
                    description: `Заказы цвета ${color}`,
                    priority: 1,
                    selected: true
                })),
                columnMapping: this.getDefaultColumnMapping(),
                importOnlySelected: colorFilters.length > 0,
                clearExistingData: clearExisting,
                skipDuplicates: skipDuplicates
            };
            const result = await this.enhancedExcelImportService.importFullExcelWithFilters(file, importSettings);
            if (selectedOrders.length > 0) {
                console.log(`🔍 Дополнительная фильтрация по ${selectedOrders.length} выбранным заказам`);
            }
            console.log('✅ ВЫБОРОЧНЫЙ ИМПОРТ ЗАВЕРШЕН:', {
                totalRows: result.totalRows,
                created: result.created,
                updated: result.updated,
                errors: result.errors.length
            });
            return {
                success: true,
                message: `Импорт завершен! Создано: ${result.created}, Обновлено: ${result.updated}, Ошибок: ${result.errors.length}`,
                data: result
            };
        }
        catch (error) {
            console.error('❌ ВЫБОРОЧНЫЙ ИМПОРТ: Ошибка:', error);
            return {
                success: false,
                message: `Ошибка выборочного импорта: ${error.message}`,
                data: null
            };
        }
    }
};
exports.EnhancedOrdersController = EnhancedOrdersController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Получить все заказы с фильтрацией и пагинацией' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [orders_filter_dto_1.OrdersFilterDto]),
    __metadata("design:returntype", Promise)
], EnhancedOrdersController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить заказ по ID' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], EnhancedOrdersController.prototype, "findOne", null);
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Создать новый заказ' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_order_dto_1.CreateOrderDto]),
    __metadata("design:returntype", Promise)
], EnhancedOrdersController.prototype, "create", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Обновить заказ' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_order_dto_1.UpdateOrderDto]),
    __metadata("design:returntype", Promise)
], EnhancedOrdersController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Удалить заказ' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], EnhancedOrdersController.prototype, "remove", null);
__decorate([
    (0, common_1.Delete)('batch/selected'),
    (0, swagger_1.ApiOperation)({ summary: 'Удалить выбранные заказы' }),
    __param(0, (0, common_1.Body)('ids')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Array]),
    __metadata("design:returntype", Promise)
], EnhancedOrdersController.prototype, "removeBatch", null);
__decorate([
    (0, common_1.Delete)('all/confirm'),
    (0, swagger_1.ApiOperation)({ summary: 'Удалить все заказы' }),
    __param(0, (0, common_1.Body)('confirm')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Boolean]),
    __metadata("design:returntype", Promise)
], EnhancedOrdersController.prototype, "removeAll", null);
__decorate([
    (0, common_1.Post)('upload-excel-full'),
    (0, swagger_1.ApiOperation)({
        summary: '🚀 ПОЛНЫЙ ИМПОРТ EXCEL С ФИЛЬТРАМИ В БД',
        description: 'Загружает весь Excel файл в базу данных с применением цветовых фильтров и настроек импорта'
    }),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('excel', {
        fileFilter: (req, file, cb) => {
            console.log('🔍 ПОЛНЫЙ ИМПОРТ: Проверка файла:', {
                originalname: file.originalname,
                mimetype: file.mimetype,
                size: file.size
            });
            const allowedTypes = [
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'application/vnd.ms-excel',
                'application/octet-stream'
            ];
            const isValidType = allowedTypes.includes(file.mimetype) || !!file.originalname.match(/\.(xlsx?|csv)$/);
            if (isValidType) {
                console.log('✅ ПОЛНЫЙ ИМПОРТ: Файл прошел проверку');
                cb(null, true);
            }
            else {
                console.error('❌ ПОЛНЫЙ ИМПОРТ: Недопустимый тип файла:', file.mimetype);
                cb(new Error('Только Excel файлы (.xlsx, .xls) разрешены для полного импорта'), false);
            }
        },
        limits: {
            fileSize: 100 * 1024 * 1024,
            fieldSize: 100 * 1024 * 1024,
        },
    })),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], EnhancedOrdersController.prototype, "uploadExcelFull", null);
__decorate([
    (0, common_1.Post)('analyze-excel'),
    (0, swagger_1.ApiOperation)({
        summary: '🔍 ДЕТАЛЬНЫЙ АНАЛИЗ EXCEL ФАЙЛА',
        description: 'Анализирует Excel файл и показывает все найденные заказы с возможностью выбора для импорта'
    }),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('excel', {
        fileFilter: (req, file, cb) => {
            const allowedTypes = [
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'application/vnd.ms-excel',
                'application/octet-stream'
            ];
            const isValidType = allowedTypes.includes(file.mimetype) || !!file.originalname.match(/\.(xlsx?|csv)$/);
            cb(null, isValidType);
        },
        limits: {
            fileSize: 50 * 1024 * 1024,
        },
    })),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], EnhancedOrdersController.prototype, "analyzeExcelFile", null);
__decorate([
    (0, swagger_1.ApiOperation)({
        summary: '👁️ ПРЕВЬЮ EXCEL С АНАЛИЗОМ ФИЛЬТРОВ',
        description: 'Показывает превью Excel файла с анализом цветов и возможными фильтрами'
    }),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('excel', {
        fileFilter: (req, file, cb) => {
            const allowedTypes = [
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'application/vnd.ms-excel',
                'application/octet-stream'
            ];
            const isValidType = allowedTypes.includes(file.mimetype) || !!file.originalname.match(/\.(xlsx?|csv)$/);
            cb(null, isValidType);
        },
        limits: {
            fileSize: 50 * 1024 * 1024,
        },
    })),
    __param(0, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], EnhancedOrdersController.prototype, "previewExcel", null);
__decorate([
    (0, common_1.Post)('import-selected-orders'),
    (0, swagger_1.ApiOperation)({
        summary: '🎯 ИМПОРТ ВЫБРАННЫХ ЗАКАЗОВ',
        description: 'Импортирует только выбранные заказы из ранее проанализированного Excel файла'
    }),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('excel', {
        fileFilter: (req, file, cb) => {
            const allowedTypes = [
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'application/vnd.ms-excel',
                'application/octet-stream'
            ];
            const isValidType = allowedTypes.includes(file.mimetype) || !!file.originalname.match(/\.(xlsx?|csv)$/);
            cb(null, isValidType);
        },
        limits: {
            fileSize: 100 * 1024 * 1024,
        },
    })),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], EnhancedOrdersController.prototype, "importSelectedOrders", null);
exports.EnhancedOrdersController = EnhancedOrdersController = __decorate([
    (0, swagger_1.ApiTags)('enhanced-orders'),
    (0, common_1.Controller)('enhanced-orders'),
    __metadata("design:paramtypes", [orders_service_1.OrdersService,
        enhanced_excel_import_service_1.EnhancedExcelImportService,
        excel_preview_service_1.ExcelPreviewService])
], EnhancedOrdersController);
//# sourceMappingURL=enhanced-orders.controller.js.map