import { Repository } from 'typeorm';
import { Order } from '../../database/entities/order.entity';
import { Operation } from '../../database/entities/operation.entity';
import { OrdersService } from './orders.service';
import type { Express } from 'express';
export interface ImportResult {
    created: number;
    updated: number;
    errors: Array<{
        order: string;
        error: string;
    }>;
}
export declare class ExcelImportService {
    private readonly orderRepository;
    private readonly operationRepository;
    private readonly ordersService;
    constructor(orderRepository: Repository<Order>, operationRepository: Repository<Operation>, ordersService: OrdersService);
    importOrders(file: Express.Multer.File, colorFilters?: string[]): Promise<ImportResult>;
    private shouldProcessRow;
    private parseRowToOrder;
    private parseDate;
    private parsePriority;
    private parseOperations;
    private parseOperationType;
    private processImportedOrders;
    private createNewOrder;
    private updateExistingOrder;
}
