"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExcelImportService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const ExcelJS = require("exceljs");
const order_entity_1 = require("../../database/entities/order.entity");
const operation_entity_1 = require("../../database/entities/operation.entity");
const orders_service_1 = require("./orders.service");
let ExcelImportService = class ExcelImportService {
    constructor(orderRepository, operationRepository, ordersService) {
        this.orderRepository = orderRepository;
        this.operationRepository = operationRepository;
        this.ordersService = ordersService;
    }
    async importOrders(file, colorFilters = []) {
        console.log('🔍 EXCEL IMPORT SERVICE: Начало импорта реального файла:', {
            originalname: file.originalname,
            size: file.size,
            mimetype: file.mimetype,
            hasBuffer: !!file.buffer,
            bufferSize: file.buffer?.length,
            colorFiltersCount: colorFilters.length
        });
        if (!file) {
            throw new common_1.BadRequestException('Файл не предоставлен');
        }
        if (!file.buffer) {
            console.error('❌ EXCEL IMPORT SERVICE: Отсутствует file.buffer!');
            throw new common_1.BadRequestException('Ошибка чтения файла: отсутствует buffer');
        }
        console.log('✅ Файл прошел проверку, начинаем парсинг...');
        const workbook = new ExcelJS.Workbook();
        try {
            console.log('📂 Загружаем Excel из buffer...');
            await workbook.xlsx.load(file.buffer);
            console.log('✅ Excel успешно загружен!');
        }
        catch (error) {
            console.error('❌ Ошибка загрузки Excel:', error);
            throw new common_1.BadRequestException(`Ошибка чтения Excel файла: ${error.message}`);
        }
        const worksheet = workbook.getWorksheet(1);
        if (!worksheet) {
            throw new common_1.BadRequestException('Рабочий лист не найден');
        }
        console.log('📄 Найден рабочий лист:', {
            name: worksheet.name,
            rowCount: worksheet.rowCount,
            columnCount: worksheet.columnCount
        });
        console.log('🔍 Превью структуры данных:');
        for (let rowNum = 1; rowNum <= Math.min(3, worksheet.rowCount); rowNum++) {
            const row = worksheet.getRow(rowNum);
            const rowData = {};
            for (let colNum = 1; colNum <= Math.min(10, worksheet.columnCount); colNum++) {
                const cell = row.getCell(colNum);
                const columnLetter = String.fromCharCode(64 + colNum);
                rowData[columnLetter] = cell.value || 'пусто';
            }
            console.log(`  Строка ${rowNum}:`, rowData);
        }
        const orders = [];
        const errors = [];
        let processedRows = 0;
        worksheet.eachRow((row, rowNumber) => {
            if (rowNumber === 1) {
                console.log('🗺 Пропускаем заголовок в строке', rowNumber);
                return;
            }
            try {
                if (this.shouldProcessRow(row, colorFilters)) {
                    const order = this.parseRowToOrder(row);
                    if (order) {
                        orders.push(order);
                        console.log(`✅ Обработана строка ${rowNumber}: ${order.drawingNumber}`);
                    }
                    else {
                        console.log(`⚠️ Пустая строка ${rowNumber}`);
                    }
                }
                else {
                    console.log(`🎨 Пропускаем строку ${rowNumber} (не проходит цветовой фильтр)`);
                }
                processedRows++;
            }
            catch (error) {
                console.error(`❌ Ошибка в строке ${rowNumber}:`, error.message);
                errors.push({
                    order: `Строка ${rowNumber}`,
                    error: error.message,
                });
            }
        });
        console.log('📊 Обработка завершена:', {
            totalRows: processedRows,
            parsedOrders: orders.length,
            errors: errors.length
        });
        return this.processImportedOrders(orders, errors);
    }
    shouldProcessRow(row, colorFilters) {
        if (colorFilters.length === 0)
            return true;
        const cell = row.getCell(1);
        const fill = cell.style?.fill;
        if (!fill || fill.type !== 'pattern')
            return false;
        const cellColor = fill.fgColor?.argb;
        return cellColor ? colorFilters.includes(cellColor) : false;
    }
    parseRowToOrder(row) {
        const drawingNumber = row.getCell(1).value?.toString();
        if (!drawingNumber)
            return null;
        const quantity = parseInt(row.getCell(2).value?.toString() || '0', 10);
        const deadlineValue = row.getCell(3).value;
        const deadline = this.parseDate(deadlineValue);
        const priority = this.parsePriority(row.getCell(4).value?.toString());
        const workType = row.getCell(5).value?.toString();
        const operations = this.parseOperations(row);
        return {
            drawingNumber,
            quantity,
            deadline,
            priority,
            workType,
            operations,
        };
    }
    parseDate(value) {
        if (value instanceof Date) {
            return value;
        }
        if (typeof value === 'number') {
            return new Date((value - 25569) * 86400 * 1000);
        }
        if (typeof value === 'string') {
            const date = new Date(value);
            if (isNaN(date.getTime())) {
                throw new Error('Неверный формат даты');
            }
            return date;
        }
        throw new Error('Дата не указана');
    }
    parsePriority(value) {
        const priorityMap = {
            '1': order_entity_1.Priority.CRITICAL,
            'критический': order_entity_1.Priority.CRITICAL,
            '2': order_entity_1.Priority.HIGH,
            'высокий': order_entity_1.Priority.HIGH,
            '3': order_entity_1.Priority.MEDIUM,
            'средний': order_entity_1.Priority.MEDIUM,
            '4': order_entity_1.Priority.LOW,
            'низкий': order_entity_1.Priority.LOW,
        };
        const priority = priorityMap[value?.toLowerCase() || ''];
        return priority || order_entity_1.Priority.MEDIUM;
    }
    parseOperations(row) {
        const operations = [];
        for (let i = 6; i <= 30; i += 4) {
            const operationNumber = parseInt(row.getCell(i).value?.toString() || '0', 10);
            if (!operationNumber)
                break;
            const operationType = this.parseOperationType(row.getCell(i + 1).value?.toString());
            const machineAxes = parseInt(row.getCell(i + 2).value?.toString() || '3', 10);
            const estimatedTime = parseInt(row.getCell(i + 3).value?.toString() || '0', 10);
            operations.push({
                operationNumber,
                operationType,
                machineAxes,
                estimatedTime,
            });
        }
        return operations;
    }
    parseOperationType(value) {
        const typeMap = {
            'фрезерная': operation_entity_1.OperationType.MILLING,
            'milling': operation_entity_1.OperationType.MILLING,
            'ф': operation_entity_1.OperationType.MILLING,
            'токарная': operation_entity_1.OperationType.TURNING,
            'turning': operation_entity_1.OperationType.TURNING,
            'т': operation_entity_1.OperationType.TURNING,
        };
        const type = typeMap[value?.toLowerCase() || ''];
        return type || operation_entity_1.OperationType.MILLING;
    }
    async processImportedOrders(orders, existingErrors) {
        const result = {
            created: 0,
            updated: 0,
            errors: existingErrors,
        };
        for (const orderData of orders) {
            try {
                const existingOrder = await this.ordersService.findByDrawingNumber(orderData.drawingNumber);
                if (existingOrder) {
                    await this.updateExistingOrder(existingOrder, orderData);
                    result.updated++;
                }
                else {
                    await this.createNewOrder(orderData);
                    result.created++;
                }
            }
            catch (error) {
                result.errors.push({
                    order: orderData.drawingNumber,
                    error: error.message,
                });
            }
        }
        return result;
    }
    async createNewOrder(orderData) {
        const order = this.orderRepository.create({
            drawingNumber: orderData.drawingNumber,
            quantity: orderData.quantity,
            remainingQuantity: orderData.quantity,
            deadline: orderData.deadline,
            priority: orderData.priority,
            status: 'planned',
        });
        const savedOrder = await this.orderRepository.save(order);
        for (const opData of orderData.operations) {
            const operation = this.operationRepository.create({
                operationNumber: opData.operationNumber,
                operationType: opData.operationType,
                estimatedTime: opData.estimatedTime,
                order: savedOrder,
            });
            await this.operationRepository.save(operation);
        }
    }
    async updateExistingOrder(existingOrder, orderData) {
        existingOrder.quantity = orderData.quantity;
        existingOrder.remainingQuantity = orderData.quantity;
        existingOrder.deadline = orderData.deadline;
        existingOrder.priority = orderData.priority;
        await this.orderRepository.save(existingOrder);
        await this.operationRepository.delete({ order: { id: existingOrder.id } });
        for (const opData of orderData.operations) {
            const operation = this.operationRepository.create({
                operationNumber: opData.operationNumber,
                operationType: opData.operationType,
                estimatedTime: opData.estimatedTime,
                order: existingOrder,
            });
            await this.operationRepository.save(operation);
        }
    }
};
exports.ExcelImportService = ExcelImportService;
exports.ExcelImportService = ExcelImportService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(order_entity_1.Order)),
    __param(1, (0, typeorm_1.InjectRepository)(operation_entity_1.Operation)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        orders_service_1.OrdersService])
], ExcelImportService);
//# sourceMappingURL=excel-import.service.js.map