import type { Express } from 'express';
export interface ExcelOrderPreview {
    rowNumber: number;
    drawingNumber: string;
    quantity: number;
    deadline: string;
    priority: string;
    workType: string;
    color: string;
    colorLabel: string;
    operations: Array<{
        number: number;
        type: string;
        time: number;
        axes: number;
    }>;
    selected: boolean;
    exists: boolean;
}
export interface ExcelPreviewResult {
    fileName: string;
    totalRows: number;
    orders: ExcelOrderPreview[];
    colorStatistics: {
        green: {
            count: number;
            label: string;
            description: string;
        };
        yellow: {
            count: number;
            label: string;
            description: string;
        };
        red: {
            count: number;
            label: string;
            description: string;
        };
        blue: {
            count: number;
            label: string;
            description: string;
        };
        other: {
            count: number;
            label: string;
            description: string;
        };
    };
    recommendedFilters: Array<{
        color: string;
        label: string;
        count: number;
        description: string;
        priority: number;
        recommended: boolean;
    }>;
    columnMapping: Array<{
        column: string;
        field: string;
        sample: string;
        detected: boolean;
    }>;
}
export interface ImportSelection {
    selectedOrders: string[];
    clearExisting: boolean;
    skipDuplicates: boolean;
    colorFilters: string[];
}
export declare class ExcelPreviewService {
    analyzeExcelFile(file: Express.Multer.File): Promise<ExcelPreviewResult>;
    private analyzeColumnStructure;
    private parseAllOrders;
    private parseRowToPreview;
    private determineRowColor;
    private getCellColor;
    private getColorLabel;
    private formatDeadline;
    private parseOperationsForPreview;
    private calculateColorStatistics;
    private generateRecommendedFilters;
    private getColorPriority;
    private isDrawingNumberField;
    private isQuantityField;
    private isDateField;
    private isPriorityField;
    private isWorkTypeField;
    private isOperationField;
}
