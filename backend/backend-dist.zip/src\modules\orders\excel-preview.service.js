"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExcelPreviewService = void 0;
const common_1 = require("@nestjs/common");
const ExcelJS = require("exceljs");
let ExcelPreviewService = class ExcelPreviewService {
    async analyzeExcelFile(file) {
        console.log('🔍 АНАЛИЗ EXCEL: Начало детального анализа файла:', {
            originalname: file.originalname,
            size: file.size,
            hasBuffer: !!file.buffer
        });
        if (!file || !file.buffer) {
            throw new common_1.BadRequestException('Файл не предоставлен или поврежден');
        }
        const workbook = new ExcelJS.Workbook();
        await workbook.xlsx.load(file.buffer);
        const worksheet = workbook.getWorksheet(1);
        if (!worksheet) {
            throw new common_1.BadRequestException('Рабочий лист не найден в Excel файле');
        }
        console.log('📊 Структура Excel файла:', {
            worksheetName: worksheet.name,
            totalRows: worksheet.rowCount,
            totalColumns: worksheet.columnCount
        });
        const columnMapping = this.analyzeColumnStructure(worksheet);
        const orders = await this.parseAllOrders(worksheet);
        const colorStatistics = this.calculateColorStatistics(orders);
        const recommendedFilters = this.generateRecommendedFilters(colorStatistics);
        const result = {
            fileName: file.originalname,
            totalRows: worksheet.rowCount - 1,
            orders,
            colorStatistics,
            recommendedFilters,
            columnMapping
        };
        console.log('✅ АНАЛИЗ ЗАВЕРШЕН:', {
            ordersFound: orders.length,
            colorsDetected: Object.keys(colorStatistics).length,
            recommendedFilters: recommendedFilters.length
        });
        return result;
    }
    analyzeColumnStructure(worksheet) {
        const headerRow = worksheet.getRow(1);
        const dataRow = worksheet.getRow(2);
        const mapping = [];
        for (let col = 1; col <= Math.min(10, worksheet.columnCount); col++) {
            const headerValue = headerRow.getCell(col).value?.toString()?.trim() || '';
            const sampleValue = dataRow.getCell(col).value?.toString()?.trim() || '';
            const columnLetter = String.fromCharCode(64 + col);
            let fieldName = 'Неизвестно';
            let detected = false;
            if (col === 1 || this.isDrawingNumberField(headerValue, sampleValue)) {
                fieldName = 'Номер чертежа';
                detected = true;
            }
            else if (col === 2 || this.isQuantityField(headerValue, sampleValue)) {
                fieldName = 'Количество';
                detected = true;
            }
            else if (col === 3 || this.isDateField(headerValue, sampleValue)) {
                fieldName = 'Дедлайн';
                detected = true;
            }
            else if (col === 4 || this.isPriorityField(headerValue, sampleValue)) {
                fieldName = 'Приоритет';
                detected = true;
            }
            else if (col === 5 || this.isWorkTypeField(headerValue, sampleValue)) {
                fieldName = 'Тип работы';
                detected = true;
            }
            else if (col >= 6) {
                fieldName = 'Операции';
                detected = this.isOperationField(headerValue, sampleValue);
            }
            mapping.push({
                column: columnLetter,
                field: fieldName,
                sample: sampleValue.length > 20 ? sampleValue.substring(0, 20) + '...' : sampleValue,
                detected
            });
        }
        return mapping;
    }
    async parseAllOrders(worksheet) {
        const orders = [];
        for (let rowNumber = 2; rowNumber <= worksheet.rowCount; rowNumber++) {
            try {
                const row = worksheet.getRow(rowNumber);
                const order = this.parseRowToPreview(row, rowNumber);
                if (order) {
                    orders.push(order);
                    console.log(`📝 Строка ${rowNumber}: ${order.drawingNumber} (${order.color})`);
                }
            }
            catch (error) {
                console.warn(`⚠️ Ошибка в строке ${rowNumber}:`, error.message);
            }
        }
        console.log(`📋 Обработано ${orders.length} заказов`);
        return orders;
    }
    parseRowToPreview(row, rowNumber) {
        const drawingNumber = row.getCell('C').value?.toString()?.trim();
        if (!drawingNumber)
            return null;
        const quantity = parseInt(row.getCell('E').value?.toString() || '1', 10);
        const deadline = this.formatDeadline(row.getCell('H').value);
        const priority = row.getCell('K').value?.toString()?.trim() || 'Средний';
        const workType = row.getCell('F').value?.toString()?.trim() || 'Не указан';
        const color = this.determineRowColor(row);
        const colorLabel = this.getColorLabel(color);
        const operations = this.parseOperationsForPreview(row);
        console.log(`📋 Превью строки ${rowNumber}: Чертеж=${drawingNumber}, Кол-во=${quantity}, Срок=${deadline}, Приоритет=${priority}`);
        return {
            rowNumber,
            drawingNumber,
            quantity,
            deadline,
            priority,
            workType,
            color,
            colorLabel,
            operations,
            selected: true,
            exists: false
        };
    }
    determineRowColor(row) {
        const firstCell = row.getCell(1);
        const cellColor = this.getCellColor(firstCell);
        if (cellColor)
            return cellColor;
        const values = [];
        for (let i = 1; i <= Math.min(10, row.cellCount); i++) {
            const cellValue = row.getCell(i).value;
            if (cellValue) {
                values.push(String(cellValue).toLowerCase());
            }
        }
        const allText = values.join(' ');
        if (allText.includes('готов') || allText.includes('готово') || allText.includes('завершен')) {
            return 'green';
        }
        else if (allText.includes('критич') || allText.includes('срочн') || allText.includes('важн')) {
            return 'red';
        }
        else if (allText.includes('план') || allText.includes('будущ') || allText.includes('отложен')) {
            return 'blue';
        }
        else {
            return 'yellow';
        }
    }
    getCellColor(cell) {
        try {
            const fill = cell.style?.fill;
            if (fill && fill.type === 'pattern') {
                const patternFill = fill;
                const argb = patternFill.fgColor?.argb;
                if (argb) {
                    const colorMap = {
                        'FF00FF00': 'green', 'FF92D050': 'green', 'FF00B050': 'green',
                        'FFFFFF00': 'yellow', 'FFFFCC00': 'yellow', 'FFFFC000': 'yellow',
                        'FFFF0000': 'red', 'FFFF6666': 'red', 'FFFF9999': 'red',
                        'FF0000FF': 'blue', 'FF6699CC': 'blue', 'FF9BC2E6': 'blue',
                    };
                    return colorMap[argb] || null;
                }
            }
        }
        catch (error) {
        }
        return null;
    }
    getColorLabel(color) {
        const labels = {
            green: '🟢 Готовые заказы',
            yellow: '🟡 Обычные заказы',
            red: '🔴 Критичные заказы',
            blue: '🔵 Плановые заказы',
            other: '⚪ Другие'
        };
        return labels[color] || labels.other;
    }
    formatDeadline(value) {
        if (value instanceof Date) {
            return value.toLocaleDateString('ru-RU');
        }
        if (typeof value === 'number') {
            const date = new Date((value - 25569) * 86400 * 1000);
            return date.toLocaleDateString('ru-RU');
        }
        if (typeof value === 'string') {
            const date = new Date(value);
            if (!isNaN(date.getTime())) {
                return date.toLocaleDateString('ru-RU');
            }
        }
        return 'Не указан';
    }
    parseOperationsForPreview(row) {
        const operations = [];
        for (let i = 12; i <= Math.min(30, row.cellCount); i += 4) {
            const opNumber = parseInt(row.getCell(i).value?.toString() || '0', 10);
            if (!opNumber)
                break;
            const opType = row.getCell(i + 1).value?.toString()?.trim() || 'Фрезерная';
            const opAxes = parseInt(row.getCell(i + 2).value?.toString() || '3', 10);
            const opTime = parseInt(row.getCell(i + 3).value?.toString() || '60', 10);
            operations.push({
                number: opNumber,
                type: opType,
                time: opTime,
                axes: opAxes
            });
        }
        if (operations.length === 0) {
            operations.push({
                number: 1,
                type: 'Фрезерная',
                time: 60,
                axes: 3
            });
        }
        return operations;
    }
    calculateColorStatistics(orders) {
        const stats = {
            green: { count: 0, label: '🟢 Готовые заказы', description: 'Заказы готовые к производству' },
            yellow: { count: 0, label: '🟡 Обычные заказы', description: 'Стандартные заказы' },
            red: { count: 0, label: '🔴 Критичные заказы', description: 'Срочные заказы высокого приоритета' },
            blue: { count: 0, label: '🔵 Плановые заказы', description: 'Плановые заказы на будущее' },
            other: { count: 0, label: '⚪ Другие', description: 'Заказы неопределенного типа' }
        };
        orders.forEach(order => {
            if (stats[order.color]) {
                stats[order.color].count++;
            }
            else {
                stats.other.count++;
            }
        });
        return stats;
    }
    generateRecommendedFilters(statistics) {
        const filters = [];
        Object.entries(statistics).forEach(([color, data]) => {
            if (data.count > 0) {
                filters.push({
                    color,
                    label: data.label,
                    count: data.count,
                    description: `${data.description} (${data.count} шт.)`,
                    priority: this.getColorPriority(color),
                    recommended: data.count > 0
                });
            }
        });
        return filters.sort((a, b) => a.priority - b.priority);
    }
    getColorPriority(color) {
        const priorities = {
            red: 1,
            yellow: 2,
            green: 3,
            blue: 4,
            other: 5
        };
        return priorities[color] || 5;
    }
    isDrawingNumberField(header, sample) {
        const headerLower = header.toLowerCase();
        return headerLower.includes('номер') || headerLower.includes('чертеж') || headerLower.includes('number') ||
            headerLower.includes('drawing') || !!sample.match(/^[A-Z0-9\-_]+$/);
    }
    isQuantityField(header, sample) {
        const headerLower = header.toLowerCase();
        return headerLower.includes('количество') || headerLower.includes('qty') || headerLower.includes('quantity') ||
            (!isNaN(parseInt(sample)) && parseInt(sample) > 0 && parseInt(sample) < 10000);
    }
    isDateField(header, sample) {
        const headerLower = header.toLowerCase();
        return headerLower.includes('дата') || headerLower.includes('срок') || headerLower.includes('date') ||
            headerLower.includes('deadline') || !isNaN(Date.parse(sample));
    }
    isPriorityField(header, sample) {
        const headerLower = header.toLowerCase();
        const sampleLower = sample.toLowerCase();
        return headerLower.includes('приоритет') || headerLower.includes('priority') ||
            sampleLower.includes('высок') || sampleLower.includes('критич') || sampleLower.includes('низк');
    }
    isWorkTypeField(header, sample) {
        const headerLower = header.toLowerCase();
        return headerLower.includes('тип') || headerLower.includes('работа') || headerLower.includes('type') ||
            headerLower.includes('work') || headerLower.includes('описание');
    }
    isOperationField(header, sample) {
        const headerLower = header.toLowerCase();
        const sampleLower = sample.toLowerCase();
        return headerLower.includes('операция') || headerLower.includes('operation') ||
            sampleLower.includes('фрез') || sampleLower.includes('ток') || sampleLower.includes('сверл');
    }
};
exports.ExcelPreviewService = ExcelPreviewService;
exports.ExcelPreviewService = ExcelPreviewService = __decorate([
    (0, common_1.Injectable)()
], ExcelPreviewService);
//# sourceMappingURL=excel-preview.service.js.map