export interface OrderFileSystemData {
    order: any;
    operations: any[];
    shifts?: any[];
    planning?: any;
    history?: any[];
    metadata: any;
}
export declare class OrderFileSystemService {
    private readonly logger;
    private readonly ordersPath;
    constructor();
    private ensureOrdersDirectory;
    createOrderVersion(drawingNumber: string, orderData: OrderFileSystemData): Promise<string>;
    updateOrderVersion(drawingNumber: string, orderData: OrderFileSystemData): Promise<string>;
    getLatestOrderVersion(drawingNumber: string): Promise<OrderFileSystemData | null>;
    getOrderVersion(drawingNumber: string, version: string): Promise<OrderFileSystemData | null>;
    getOrderVersions(drawingNumber: string): Promise<string[]>;
    saveShiftData(drawingNumber: string, version: string, shiftsData: any[]): Promise<void>;
    savePlanningData(drawingNumber: string, version: string, planningData: any): Promise<void>;
    private createOrderDirectoryStructure;
    private saveOrderFiles;
    private loadOrderFiles;
    private loadJsonFile;
    private updateLatestVersionPointer;
    private isValidVersionName;
    private ensureDirectoryExists;
    getAllOrders(): Promise<string[]>;
    exportOrderFromDatabase(orderData: any, operationsData: any[]): Promise<string>;
}
