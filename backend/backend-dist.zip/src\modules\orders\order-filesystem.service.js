"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var OrderFileSystemService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderFileSystemService = void 0;
const common_1 = require("@nestjs/common");
const fs_1 = require("fs");
const path_1 = require("path");
let OrderFileSystemService = OrderFileSystemService_1 = class OrderFileSystemService {
    constructor() {
        this.logger = new common_1.Logger(OrderFileSystemService_1.name);
        const possiblePaths = [
            (0, path_1.join)(process.cwd(), 'uploads', 'orders'),
            (0, path_1.join)(__dirname, '..', '..', '..', '..', 'uploads', 'orders'),
            (0, path_1.resolve)('uploads', 'orders'),
            'C:\\Users\\kasuf\\Downloads\\TheWho\\production-crm\\uploads\\orders'
        ];
        this.ordersPath = possiblePaths[0];
        this.logger.log(`OrderFileSystemService initialized with path: ${this.ordersPath}`);
        this.logger.log(`Current working directory: ${process.cwd()}`);
        this.logger.log(`__dirname: ${__dirname}`);
        this.ensureOrdersDirectory();
    }
    async ensureOrdersDirectory() {
        try {
            await fs_1.promises.access(this.ordersPath);
            this.logger.log(`SUCCESS: Orders directory exists at: ${this.ordersPath}`);
            const items = await fs_1.promises.readdir(this.ordersPath);
            this.logger.log(`Found ${items.length} items in directory: ${items.join(', ')}`);
        }
        catch (error) {
            this.logger.error(`ERROR: Cannot access orders directory at: ${this.ordersPath}`);
            this.logger.error('Error details:', error.message);
            const possiblePaths = [
                (0, path_1.join)(process.cwd(), 'uploads', 'orders'),
                (0, path_1.join)(__dirname, '..', '..', '..', '..', 'uploads', 'orders'),
                (0, path_1.resolve)('uploads', 'orders'),
                'C:\\Users\\kasuf\\Downloads\\TheWho\\production-crm\\uploads\\orders'
            ];
            for (const testPath of possiblePaths) {
                try {
                    await fs_1.promises.access(testPath);
                    this.logger.log(`FOUND alternative path: ${testPath}`);
                    this.ordersPath = testPath;
                    return;
                }
                catch {
                    this.logger.log(`Path not found: ${testPath}`);
                }
            }
            await fs_1.promises.mkdir(this.ordersPath, { recursive: true });
            this.logger.log(`Created orders directory: ${this.ordersPath}`);
        }
    }
    async createOrderVersion(drawingNumber, orderData) {
        const timestamp = new Date().toISOString().split('T')[0];
        const versionPath = (0, path_1.join)(this.ordersPath, drawingNumber, timestamp);
        await this.createOrderDirectoryStructure(versionPath);
        await this.saveOrderFiles(versionPath, orderData);
        this.logger.log(`Создана версия заказа ${drawingNumber} в ${versionPath}`);
        return timestamp;
    }
    async updateOrderVersion(drawingNumber, orderData) {
        const now = new Date();
        const timestamp = `${now.toISOString().split('T')[0]}_${now.getHours().toString().padStart(2, '0')}-${now.getMinutes().toString().padStart(2, '0')}`;
        const versionPath = (0, path_1.join)(this.ordersPath, drawingNumber, timestamp);
        await this.createOrderDirectoryStructure(versionPath);
        await this.saveOrderFiles(versionPath, orderData);
        await this.updateLatestVersionPointer(drawingNumber, timestamp);
        this.logger.log(`Обновлена версия заказа ${drawingNumber} в ${versionPath}`);
        return timestamp;
    }
    async getLatestOrderVersion(drawingNumber) {
        try {
            const orderPath = (0, path_1.join)(this.ordersPath, drawingNumber);
            const versions = await this.getOrderVersions(drawingNumber);
            if (versions.length === 0) {
                return null;
            }
            const latestVersion = versions[versions.length - 1];
            const versionPath = (0, path_1.join)(orderPath, latestVersion);
            return await this.loadOrderFiles(versionPath);
        }
        catch (error) {
            this.logger.error(`Ошибка получения заказа ${drawingNumber}:`, error);
            return null;
        }
    }
    async getOrderVersion(drawingNumber, version) {
        try {
            const versionPath = (0, path_1.join)(this.ordersPath, drawingNumber, version);
            return await this.loadOrderFiles(versionPath);
        }
        catch (error) {
            this.logger.error(`Ошибка получения версии ${version} заказа ${drawingNumber}:`, error);
            return null;
        }
    }
    async getOrderVersions(drawingNumber) {
        try {
            const orderPath = (0, path_1.join)(this.ordersPath, drawingNumber);
            const items = await fs_1.promises.readdir(orderPath);
            const versions = [];
            for (const item of items) {
                const itemPath = (0, path_1.join)(orderPath, item);
                const stats = await fs_1.promises.stat(itemPath);
                if (stats.isDirectory() && this.isValidVersionName(item)) {
                    versions.push(item);
                }
            }
            return versions.sort();
        }
        catch (error) {
            this.logger.error(`Ошибка получения версий заказа ${drawingNumber}:`, error);
            return [];
        }
    }
    async saveShiftData(drawingNumber, version, shiftsData) {
        const shiftsPath = (0, path_1.join)(this.ordersPath, drawingNumber, version, 'shifts', 'shifts_records.json');
        await this.ensureDirectoryExists((0, path_1.join)(this.ordersPath, drawingNumber, version, 'shifts'));
        await fs_1.promises.writeFile(shiftsPath, JSON.stringify(shiftsData, null, 2));
        this.logger.log(`Сохранены данные смен для ${drawingNumber} v${version}`);
    }
    async savePlanningData(drawingNumber, version, planningData) {
        const planningPath = (0, path_1.join)(this.ordersPath, drawingNumber, version, 'planning', 'planning_results.json');
        await this.ensureDirectoryExists((0, path_1.join)(this.ordersPath, drawingNumber, version, 'planning'));
        await fs_1.promises.writeFile(planningPath, JSON.stringify(planningData, null, 2));
        this.logger.log(`Сохранены данные планирования для ${drawingNumber} v${version}`);
    }
    async createOrderDirectoryStructure(versionPath) {
        const subFolders = [
            'operations',
            'shifts',
            'planning',
            'documents',
            'history',
            'exports',
            'analysis'
        ];
        await fs_1.promises.mkdir(versionPath, { recursive: true });
        for (const folder of subFolders) {
            await fs_1.promises.mkdir((0, path_1.join)(versionPath, folder), { recursive: true });
        }
    }
    async saveOrderFiles(versionPath, data) {
        await fs_1.promises.writeFile((0, path_1.join)(versionPath, 'order.json'), JSON.stringify(data.order, null, 2));
        await fs_1.promises.writeFile((0, path_1.join)(versionPath, 'operations', 'operations.json'), JSON.stringify(data.operations, null, 2));
        await fs_1.promises.writeFile((0, path_1.join)(versionPath, 'metadata.json'), JSON.stringify(data.metadata, null, 2));
        if (data.shifts) {
            await fs_1.promises.writeFile((0, path_1.join)(versionPath, 'shifts', 'shifts_records.json'), JSON.stringify(data.shifts, null, 2));
        }
        if (data.planning) {
            await fs_1.promises.writeFile((0, path_1.join)(versionPath, 'planning', 'planning_results.json'), JSON.stringify(data.planning, null, 2));
        }
        if (data.history) {
            await fs_1.promises.writeFile((0, path_1.join)(versionPath, 'history', 'order_history.json'), JSON.stringify(data.history, null, 2));
        }
    }
    async loadOrderFiles(versionPath) {
        const order = await this.loadJsonFile((0, path_1.join)(versionPath, 'order.json'));
        const operations = await this.loadJsonFile((0, path_1.join)(versionPath, 'operations', 'operations.json'));
        const metadata = await this.loadJsonFile((0, path_1.join)(versionPath, 'metadata.json'));
        const shifts = await this.loadJsonFile((0, path_1.join)(versionPath, 'shifts', 'shifts_records.json'), true);
        const planning = await this.loadJsonFile((0, path_1.join)(versionPath, 'planning', 'planning_results.json'), true);
        const history = await this.loadJsonFile((0, path_1.join)(versionPath, 'history', 'order_history.json'), true);
        return {
            order,
            operations,
            metadata,
            shifts,
            planning,
            history
        };
    }
    async loadJsonFile(filePath, optional = false) {
        try {
            const content = await fs_1.promises.readFile(filePath, 'utf-8');
            return JSON.parse(content);
        }
        catch (error) {
            if (optional) {
                return null;
            }
            throw error;
        }
    }
    async updateLatestVersionPointer(drawingNumber, version) {
        const pointerPath = (0, path_1.join)(this.ordersPath, drawingNumber, 'latest_version.json');
        const pointerData = {
            latest_version: version,
            updated_at: new Date().toISOString()
        };
        await fs_1.promises.writeFile(pointerPath, JSON.stringify(pointerData, null, 2));
    }
    isValidVersionName(name) {
        const datePattern = /^\d{4}-\d{2}-\d{2}(_\d{2}-\d{2})?$/;
        return datePattern.test(name);
    }
    async ensureDirectoryExists(dirPath) {
        try {
            await fs_1.promises.access(dirPath);
        }
        catch {
            await fs_1.promises.mkdir(dirPath, { recursive: true });
        }
    }
    async getAllOrders() {
        try {
            this.logger.log(`Getting all orders from: ${this.ordersPath}`);
            const items = await fs_1.promises.readdir(this.ordersPath);
            this.logger.log(`Found ${items.length} items in orders directory: ${items.join(', ')}`);
            const orders = [];
            for (const item of items) {
                const itemPath = (0, path_1.join)(this.ordersPath, item);
                const stats = await fs_1.promises.stat(itemPath);
                this.logger.log(`Item ${item}: isDirectory=${stats.isDirectory()}`);
                if (stats.isDirectory()) {
                    orders.push(item);
                }
            }
            this.logger.log(`Found ${orders.length} order directories: ${orders.join(', ')}`);
            return orders;
        }
        catch (error) {
            this.logger.error('Ошибка получения списка заказов:', error);
            return [];
        }
    }
    async exportOrderFromDatabase(orderData, operationsData) {
        this.logger.log(`Exporting order ${orderData.drawing_number || orderData.drawingNumber} to filesystem`);
        const fileSystemData = {
            order: orderData,
            operations: operationsData,
            metadata: {
                version: '1.0',
                created_at: orderData.createdAt,
                updated_at: orderData.updatedAt,
                changes_summary: 'Экспорт из базы данных',
                data_source: 'database_export',
                export_date: new Date().toISOString()
            }
        };
        const drawingNumber = orderData.drawing_number || orderData.drawingNumber;
        this.logger.log(`Creating version for order: ${drawingNumber}`);
        return await this.createOrderVersion(drawingNumber, fileSystemData);
    }
};
exports.OrderFileSystemService = OrderFileSystemService;
exports.OrderFileSystemService = OrderFileSystemService = OrderFileSystemService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [])
], OrderFileSystemService);
//# sourceMappingURL=order-filesystem.service.js.map