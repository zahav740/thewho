import { OrderFileSystemService } from './order-filesystem.service';
import { OrdersService } from './orders.service';
export declare class OrdersFilesystemController {
    private readonly orderFileSystemService;
    private readonly ordersService;
    private readonly logger;
    constructor(orderFileSystemService: OrderFileSystemService, ordersService: OrdersService);
    getAllOrders(): Promise<{
        success: boolean;
        data: {
            drawing_number: string;
            versions_count: number;
            versions: string[];
            latest_version: any;
            has_data: boolean;
        }[];
        total: number;
    }>;
    getLatestOrderVersion(drawingNumber: string): Promise<{
        success: boolean;
        data: import("./order-filesystem.service").OrderFileSystemData;
    }>;
    getOrderVersions(drawingNumber: string): Promise<{
        success: boolean;
        drawing_number: string;
        versions: {
            version: string;
            metadata: any;
            has_shifts: boolean;
            has_planning: boolean;
            has_history: boolean;
            operations_count: number;
        }[];
        total_versions: number;
    }>;
    getOrderVersion(drawingNumber: string, version: string): Promise<{
        success: boolean;
        drawing_number: string;
        version: string;
        data: import("./order-filesystem.service").OrderFileSystemData;
    }>;
    exportAllOrdersFromDatabase(): Promise<{
        success: boolean;
        message: string;
        statistics: {
            success: number;
            errors: number;
        };
    }>;
    getOrderShifts(drawingNumber: string): Promise<{
        success: boolean;
        drawing_number: string;
        shifts: any[];
        has_shifts_data: boolean;
    }>;
    getOrderPlanning(drawingNumber: string): Promise<{
        success: boolean;
        drawing_number: string;
        planning: any;
        has_planning_data: boolean;
    }>;
    getFileSystemStatistics(): Promise<{
        success: boolean;
        statistics: {
            total_orders: number;
            total_versions: number;
            average_versions_per_order: string | number;
            orders_with_shifts: number;
            orders_with_planning: number;
            orders_with_history: number;
            coverage: {
                shifts_coverage: string;
                planning_coverage: string;
                history_coverage: string;
            };
        };
    }>;
}
