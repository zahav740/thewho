"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var OrdersFilesystemController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrdersFilesystemController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const order_filesystem_service_1 = require("./order-filesystem.service");
const orders_service_1 = require("./orders.service");
let OrdersFilesystemController = OrdersFilesystemController_1 = class OrdersFilesystemController {
    constructor(orderFileSystemService, ordersService) {
        this.orderFileSystemService = orderFileSystemService;
        this.ordersService = ordersService;
        this.logger = new common_1.Logger(OrdersFilesystemController_1.name);
    }
    async getAllOrders() {
        try {
            const orders = await this.orderFileSystemService.getAllOrders();
            const ordersWithDetails = await Promise.all(orders.map(async (drawingNumber) => {
                const versions = await this.orderFileSystemService.getOrderVersions(drawingNumber);
                const latestVersion = await this.orderFileSystemService.getLatestOrderVersion(drawingNumber);
                return {
                    drawing_number: drawingNumber,
                    versions_count: versions.length,
                    versions: versions,
                    latest_version: latestVersion?.metadata || null,
                    has_data: !!latestVersion
                };
            }));
            return {
                success: true,
                data: ordersWithDetails,
                total: ordersWithDetails.length
            };
        }
        catch (error) {
            this.logger.error('Ошибка получения списка заказов:', error);
            throw new common_1.HttpException('Ошибка получения списка заказов из файловой системы', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async getLatestOrderVersion(drawingNumber) {
        try {
            const orderData = await this.orderFileSystemService.getLatestOrderVersion(drawingNumber);
            if (!orderData) {
                throw new common_1.HttpException(`Заказ ${drawingNumber} не найден в файловой системе`, common_1.HttpStatus.NOT_FOUND);
            }
            return {
                success: true,
                data: orderData
            };
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            this.logger.error(`Ошибка получения заказа ${drawingNumber}:`, error);
            throw new common_1.HttpException('Ошибка получения данных заказа', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async getOrderVersions(drawingNumber) {
        try {
            const versions = await this.orderFileSystemService.getOrderVersions(drawingNumber);
            const versionsWithMetadata = await Promise.all(versions.map(async (version) => {
                const versionData = await this.orderFileSystemService.getOrderVersion(drawingNumber, version);
                return {
                    version,
                    metadata: versionData?.metadata || null,
                    has_shifts: !!versionData?.shifts,
                    has_planning: !!versionData?.planning,
                    has_history: !!versionData?.history,
                    operations_count: versionData?.operations?.length || 0
                };
            }));
            return {
                success: true,
                drawing_number: drawingNumber,
                versions: versionsWithMetadata,
                total_versions: versionsWithMetadata.length
            };
        }
        catch (error) {
            this.logger.error(`Ошибка получения версий заказа ${drawingNumber}:`, error);
            throw new common_1.HttpException('Ошибка получения версий заказа', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async getOrderVersion(drawingNumber, version) {
        try {
            const orderData = await this.orderFileSystemService.getOrderVersion(drawingNumber, version);
            if (!orderData) {
                throw new common_1.HttpException(`Версия ${version} заказа ${drawingNumber} не найдена`, common_1.HttpStatus.NOT_FOUND);
            }
            return {
                success: true,
                drawing_number: drawingNumber,
                version,
                data: orderData
            };
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            this.logger.error(`Ошибка получения версии ${version} заказа ${drawingNumber}:`, error);
            throw new common_1.HttpException('Ошибка получения версии заказа', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async exportAllOrdersFromDatabase() {
        try {
            this.logger.log('Начинаем экспорт всех заказов из БД в файловую систему');
            const result = await this.ordersService.exportAllOrdersToFileSystem();
            this.logger.log(`Экспорт завершен. Успешно: ${result.success}, Ошибок: ${result.errors}`);
            return {
                success: true,
                message: 'Экспорт заказов завершен',
                statistics: result
            };
        }
        catch (error) {
            this.logger.error('Ошибка экспорта заказов:', error);
            throw new common_1.HttpException('Ошибка экспорта заказов в файловую систему', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async getOrderShifts(drawingNumber) {
        try {
            const orderData = await this.orderFileSystemService.getLatestOrderVersion(drawingNumber);
            if (!orderData) {
                throw new common_1.HttpException(`Заказ ${drawingNumber} не найден`, common_1.HttpStatus.NOT_FOUND);
            }
            return {
                success: true,
                drawing_number: drawingNumber,
                shifts: orderData.shifts || null,
                has_shifts_data: !!orderData.shifts
            };
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            this.logger.error(`Ошибка получения смен заказа ${drawingNumber}:`, error);
            throw new common_1.HttpException('Ошибка получения данных смен', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async getOrderPlanning(drawingNumber) {
        try {
            const orderData = await this.orderFileSystemService.getLatestOrderVersion(drawingNumber);
            if (!orderData) {
                throw new common_1.HttpException(`Заказ ${drawingNumber} не найден`, common_1.HttpStatus.NOT_FOUND);
            }
            return {
                success: true,
                drawing_number: drawingNumber,
                planning: orderData.planning || null,
                has_planning_data: !!orderData.planning
            };
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            this.logger.error(`Ошибка получения планирования заказа ${drawingNumber}:`, error);
            throw new common_1.HttpException('Ошибка получения данных планирования', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async getFileSystemStatistics() {
        try {
            const orders = await this.orderFileSystemService.getAllOrders();
            let totalVersions = 0;
            let ordersWithShifts = 0;
            let ordersWithPlanning = 0;
            let ordersWithHistory = 0;
            for (const drawingNumber of orders) {
                const versions = await this.orderFileSystemService.getOrderVersions(drawingNumber);
                totalVersions += versions.length;
                const latestVersion = await this.orderFileSystemService.getLatestOrderVersion(drawingNumber);
                if (latestVersion?.shifts)
                    ordersWithShifts++;
                if (latestVersion?.planning)
                    ordersWithPlanning++;
                if (latestVersion?.history)
                    ordersWithHistory++;
            }
            return {
                success: true,
                statistics: {
                    total_orders: orders.length,
                    total_versions: totalVersions,
                    average_versions_per_order: orders.length > 0 ? (totalVersions / orders.length).toFixed(2) : 0,
                    orders_with_shifts: ordersWithShifts,
                    orders_with_planning: ordersWithPlanning,
                    orders_with_history: ordersWithHistory,
                    coverage: {
                        shifts_coverage: orders.length > 0 ? ((ordersWithShifts / orders.length) * 100).toFixed(2) + '%' : '0%',
                        planning_coverage: orders.length > 0 ? ((ordersWithPlanning / orders.length) * 100).toFixed(2) + '%' : '0%',
                        history_coverage: orders.length > 0 ? ((ordersWithHistory / orders.length) * 100).toFixed(2) + '%' : '0%'
                    }
                }
            };
        }
        catch (error) {
            this.logger.error('Ошибка получения статистики:', error);
            throw new common_1.HttpException('Ошибка получения статистики файловой системы', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
};
exports.OrdersFilesystemController = OrdersFilesystemController;
__decorate([
    (0, common_1.Get)('orders'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить список всех заказов в файловой системе' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Список заказов получен успешно' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], OrdersFilesystemController.prototype, "getAllOrders", null);
__decorate([
    (0, common_1.Get)('orders/:drawingNumber'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить последнюю версию заказа' }),
    (0, swagger_1.ApiParam)({ name: 'drawingNumber', description: 'Номер чертежа заказа' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Данные заказа получены успешно' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Заказ не найден' }),
    __param(0, (0, common_1.Param)('drawingNumber')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrdersFilesystemController.prototype, "getLatestOrderVersion", null);
__decorate([
    (0, common_1.Get)('orders/:drawingNumber/versions'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить список версий заказа' }),
    (0, swagger_1.ApiParam)({ name: 'drawingNumber', description: 'Номер чертежа заказа' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Список версий получен успешно' }),
    __param(0, (0, common_1.Param)('drawingNumber')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrdersFilesystemController.prototype, "getOrderVersions", null);
__decorate([
    (0, common_1.Get)('orders/:drawingNumber/versions/:version'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить конкретную версию заказа' }),
    (0, swagger_1.ApiParam)({ name: 'drawingNumber', description: 'Номер чертежа заказа' }),
    (0, swagger_1.ApiParam)({ name: 'version', description: 'Версия заказа (YYYY-MM-DD или YYYY-MM-DD_HH-MM)' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Данные версии получены успешно' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Версия не найдена' }),
    __param(0, (0, common_1.Param)('drawingNumber')),
    __param(1, (0, common_1.Param)('version')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], OrdersFilesystemController.prototype, "getOrderVersion", null);
__decorate([
    (0, common_1.Post)('orders/export-all'),
    (0, swagger_1.ApiOperation)({ summary: 'Экспортировать все заказы из БД в файловую систему' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Экспорт завершен успешно' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], OrdersFilesystemController.prototype, "exportAllOrdersFromDatabase", null);
__decorate([
    (0, common_1.Get)('orders/:drawingNumber/shifts'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить данные смен для заказа' }),
    (0, swagger_1.ApiParam)({ name: 'drawingNumber', description: 'Номер чертежа заказа' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Данные смен получены успешно' }),
    __param(0, (0, common_1.Param)('drawingNumber')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrdersFilesystemController.prototype, "getOrderShifts", null);
__decorate([
    (0, common_1.Get)('orders/:drawingNumber/planning'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить данные планирования для заказа' }),
    (0, swagger_1.ApiParam)({ name: 'drawingNumber', description: 'Номер чертежа заказа' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Данные планирования получены успешно' }),
    __param(0, (0, common_1.Param)('drawingNumber')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrdersFilesystemController.prototype, "getOrderPlanning", null);
__decorate([
    (0, common_1.Get)('orders/statistics/overview'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить статистику файловой системы заказов' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Статистика получена успешно' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], OrdersFilesystemController.prototype, "getFileSystemStatistics", null);
exports.OrdersFilesystemController = OrdersFilesystemController = OrdersFilesystemController_1 = __decorate([
    (0, swagger_1.ApiTags)('Orders Filesystem API'),
    (0, common_1.Controller)('filesystem'),
    __metadata("design:paramtypes", [order_filesystem_service_1.OrderFileSystemService,
        orders_service_1.OrdersService])
], OrdersFilesystemController);
//# sourceMappingURL=orders-filesystem.controller.js.map