import { DataSource } from 'typeorm';
export declare class OrdersSimpleController {
    private readonly dataSource;
    constructor(dataSource: DataSource);
    findAll(page?: string, limit?: string): Promise<{
        data: any;
        total: number;
        page: number;
        limit: number;
        totalPages: number;
    }>;
}
