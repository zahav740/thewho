import { Response } from 'express';
import type { Express } from 'express';
import { OrdersService } from './orders.service';
import { ExcelImportService, ImportResult } from './excel-import.service';
import { CreateOrderDto } from './dto/create-order.dto';
import { UpdateOrderDto } from './dto/update-order.dto';
import { OrdersFilterDto } from './dto/orders-filter.dto';
import { ImportExcelDto } from './dto/import-excel.dto';
import { Order } from '../../database/entities/order.entity';
export declare class OrdersController {
    private readonly ordersService;
    private readonly excelImportService;
    constructor(ordersService: OrdersService, excelImportService: ExcelImportService);
    findAll(filterDto: OrdersFilterDto): Promise<{
        data: {
            name: string;
            clientName: string;
            remainingQuantity: number;
            status: string;
            completionPercentage: number;
            forecastedCompletionDate: Date;
            isOnSchedule: boolean;
            lastRecalculationAt: Date;
            operations: import("../../database/entities").Operation[];
            id: number;
            drawingNumber: string;
            deadline: Date;
            quantity: number;
            priority: number;
            workType: string;
            pdfPath: string;
            pdfUrl?: string;
            createdAt: Date;
            updatedAt: Date;
        }[];
        total: number;
        page: number;
        limit: number;
        totalPages: number;
    }>;
    findOne(id: string): Promise<Order>;
    create(createOrderDto: CreateOrderDto): Promise<Order>;
    update(id: string, updateOrderDto: UpdateOrderDto): Promise<Order>;
    remove(id: string): Promise<void>;
    removeBatch(ids: string[]): Promise<{
        deleted: number;
    }>;
    removeAll(confirm: boolean): Promise<{
        deleted: number;
    }>;
    uploadExcel(file: Express.Multer.File, body: any): Promise<{
        success: boolean;
        message: string;
        data: {
            created: number;
            updated: number;
            totalRows: number;
            importedRows: number;
            skippedRows: number;
            errors: {
                order: string;
                error: string;
            }[];
        };
        file: {
            originalname: any;
            size: any;
            realFile: boolean;
            bufferProcessed: boolean;
        };
        error?: undefined;
        details?: undefined;
    } | {
        success: boolean;
        error: string;
        message: any;
        details: {
            hasFile: boolean;
            hasBuffer: boolean;
            bufferSize: any;
        };
        data?: undefined;
        file?: undefined;
    }>;
    importExcel(file: Express.Multer.File, importDto: ImportExcelDto): Promise<ImportResult>;
    uploadPdf(id: string, file: Express.Multer.File): Promise<Order>;
    getPdf(id: string, res: Response): Promise<void>;
}
