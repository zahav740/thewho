"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var _a;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrdersController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const express_1 = require("express");
const orders_service_1 = require("./orders.service");
const excel_import_service_1 = require("./excel-import.service");
const create_order_dto_1 = require("./dto/create-order.dto");
const update_order_dto_1 = require("./dto/update-order.dto");
const orders_filter_dto_1 = require("./dto/orders-filter.dto");
const import_excel_dto_1 = require("./dto/import-excel.dto");
const multer_1 = require("multer");
const path_1 = require("path");
let OrdersController = class OrdersController {
    constructor(ordersService, excelImportService) {
        this.ordersService = ordersService;
        this.excelImportService = excelImportService;
    }
    async findAll(filterDto) {
        try {
            console.log('OrdersController.findAll: Получен запрос с фильтрами:', filterDto);
            const result = await this.ordersService.findAll(filterDto);
            console.log(`OrdersController.findAll: Возвращено ${result.data?.length || 0} заказов`);
            return result;
        }
        catch (error) {
            console.error('OrdersController.findAll error:', error);
            throw error;
        }
    }
    async findOne(id) {
        try {
            return await this.ordersService.findOne(id);
        }
        catch (error) {
            console.error(`Orders findOne error for id ${id}:`, error);
            throw error;
        }
    }
    async create(createOrderDto) {
        return this.ordersService.create(createOrderDto);
    }
    async update(id, updateOrderDto) {
        return this.ordersService.update(id, updateOrderDto);
    }
    async remove(id) {
        try {
            return await this.ordersService.remove(id);
        }
        catch (error) {
            console.error(`Orders remove error for id ${id}:`, error);
            throw error;
        }
    }
    async removeBatch(ids) {
        try {
            const deleted = await this.ordersService.removeBatch(ids);
            return { deleted };
        }
        catch (error) {
            console.error('Orders batch remove error:', error);
            throw error;
        }
    }
    async removeAll(confirm) {
        if (!confirm) {
            throw new Error('Подтверждение удаления обязательно');
        }
        try {
            const deleted = await this.ordersService.removeAll();
            return { deleted };
        }
        catch (error) {
            console.error('Orders remove all error:', error);
            throw error;
        }
    }
    async uploadExcel(file, body) {
        try {
            console.log('📁 ПРОДАКШЕН: Получен РЕАЛЬНЫЙ Excel файл (с buffer):', {
                originalname: file.originalname,
                size: file.size,
                mimetype: file.mimetype,
                hasBuffer: !!file.buffer,
                bufferSize: file.buffer?.length,
                body: body
            });
            if (!file || !file.buffer) {
                console.error('❌ Отсутствует file.buffer!');
                throw new Error('ПУСТОЙ ИЛИ НЕКОРРЕКТНЫЙ ФАЙЛ - нет buffer');
            }
            if (file.buffer.length === 0) {
                console.error('❌ Пустой buffer!');
                throw new Error('ПУСТОЙ ФАЙЛ - buffer пустой');
            }
            console.log('✅ Файл прошел проверку, buffer доступен:', file.buffer.length, 'байт');
            let colorFilters = [];
            if (body.colorFilters) {
                try {
                    colorFilters = JSON.parse(body.colorFilters);
                    console.log('🎨 Применяем цветовые фильтры:', colorFilters);
                }
                catch {
                    console.log('⚠️ Не удалось распарсить цветовые фильтры');
                }
            }
            console.log('🔄 Начинаем обработку реального Excel файла с buffer...');
            const result = await this.excelImportService.importOrders(file, colorFilters);
            console.log('✅ ПРОДАКШЕН: Импорт реальных данных завершен:', {
                created: result.created,
                updated: result.updated,
                errors: result.errors?.length || 0,
                firstErrorExample: result.errors?.[0] || 'Нет ошибок'
            });
            return {
                success: true,
                message: 'ПРОДАКШЕН: Реальный Excel файл успешно обработан',
                data: {
                    created: result.created,
                    updated: result.updated,
                    totalRows: result.created + result.updated + result.errors.length,
                    importedRows: result.created + result.updated,
                    skippedRows: result.errors.length,
                    errors: result.errors
                },
                file: {
                    originalname: file.originalname,
                    size: file.size,
                    realFile: true,
                    bufferProcessed: true
                }
            };
        }
        catch (error) {
            console.error('❌ ПРОДАКШЕН: Ошибка при импорте реального Excel:', error);
            return {
                success: false,
                error: 'ПРОДАКШЕН: Ошибка при обработке реального Excel файла',
                message: error.message,
                details: {
                    hasFile: !!file,
                    hasBuffer: !!file?.buffer,
                    bufferSize: file?.buffer?.length || 0
                }
            };
        }
    }
    async importExcel(file, importDto) {
        return this.excelImportService.importOrders(file, importDto.colorFilters);
    }
    async uploadPdf(id, file) {
        try {
            console.log(`📁 ПРОДАКШЕН: Загрузка PDF для заказа ${id}:`, {
                originalname: file.originalname,
                filename: file.filename,
                size: file.size,
                path: file.path
            });
            if (!file || !file.filename) {
                throw new Error('Ошибка сохранения PDF файла');
            }
            const result = await this.ordersService.uploadPdf(id, file.filename);
            console.log(`✅ PDF успешно загружен для заказа ${id}`);
            return result;
        }
        catch (error) {
            console.error(`❌ Ошибка загрузки PDF для заказа ${id}:`, error);
            throw error;
        }
    }
    async getPdf(id, res) {
        const order = await this.ordersService.findOne(id);
        if (!order.pdfUrl) {
            res.status(404).send('PDF файл не найден');
            return;
        }
        res.sendFile(order.pdfUrl, { root: './uploads/pdf' });
    }
};
exports.OrdersController = OrdersController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Получить все заказы с фильтрацией и пагинацией' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [orders_filter_dto_1.OrdersFilterDto]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить заказ по ID' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "findOne", null);
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Создать новый заказ' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_order_dto_1.CreateOrderDto]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "create", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Обновить заказ' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_order_dto_1.UpdateOrderDto]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Удалить заказ' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "remove", null);
__decorate([
    (0, common_1.Delete)('batch/selected'),
    (0, swagger_1.ApiOperation)({ summary: 'Удалить выбранные заказы' }),
    __param(0, (0, common_1.Body)('ids')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Array]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "removeBatch", null);
__decorate([
    (0, common_1.Delete)('all/confirm'),
    (0, swagger_1.ApiOperation)({ summary: 'Удалить все заказы (с подтверждением)' }),
    __param(0, (0, common_1.Body)('confirm')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Boolean]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "removeAll", null);
__decorate([
    (0, common_1.Post)('upload-excel'),
    (0, swagger_1.ApiOperation)({ summary: 'ПРОДАКШЕН: Загрузить и обработать РЕАЛЬНЫЙ Excel файл (с buffer)' }),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('excel', {
        fileFilter: (req, file, cb) => {
            console.log('🔍 Проверка реального файла:', {
                originalname: file.originalname,
                mimetype: file.mimetype,
                size: file.size
            });
            const allowedTypes = [
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'application/vnd.ms-excel',
                'application/octet-stream'
            ];
            const isValidType = allowedTypes.includes(file.mimetype) || file.originalname.match(/\.(xlsx?|csv)$/);
            if (isValidType) {
                console.log('✅ Файл прошел проверку');
                cb(null, true);
            }
            else {
                console.error('❌ Недопустимый тип файла:', file.mimetype);
                cb(new Error('ПРОДАКШЕН: Только Excel файлы (.xlsx, .xls) разрешены'), false);
            }
        },
        limits: {
            fileSize: 50 * 1024 * 1024,
        },
    })),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "uploadExcel", null);
__decorate([
    (0, common_1.Post)('import-excel'),
    (0, swagger_1.ApiOperation)({ summary: 'Импортировать заказы из Excel файла (legacy)' }),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.UploadedFile)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, import_excel_dto_1.ImportExcelDto]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "importExcel", null);
__decorate([
    (0, common_1.Post)(':id/upload-pdf'),
    (0, swagger_1.ApiOperation)({ summary: 'ПРОДАКШЕН: Загрузить PDF файл для заказа' }),
    (0, swagger_1.ApiConsumes)('multipart/form-data'),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file', {
        storage: (0, multer_1.diskStorage)({
            destination: './uploads/pdf',
            filename: (req, file, cb) => {
                const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1e9);
                cb(null, `${uniqueSuffix}${(0, path_1.extname)(file.originalname)}`);
            },
        }),
        fileFilter: (req, file, cb) => {
            console.log('📄 Проверка PDF файла:', {
                originalname: file.originalname,
                mimetype: file.mimetype,
                size: file.size
            });
            if (file.mimetype === 'application/pdf') {
                console.log('✅ PDF файл прошел проверку');
                cb(null, true);
            }
            else {
                console.error('❌ Недопустимый тип файла для PDF:', file.mimetype);
                cb(new Error('ПРОДАКШЕН: Только PDF файлы разрешены'), false);
            }
        },
        limits: {
            fileSize: 100 * 1024 * 1024,
        },
    })),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "uploadPdf", null);
__decorate([
    (0, common_1.Get)(':id/pdf'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить PDF файл заказа' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, typeof (_a = typeof express_1.Response !== "undefined" && express_1.Response) === "function" ? _a : Object]),
    __metadata("design:returntype", Promise)
], OrdersController.prototype, "getPdf", null);
exports.OrdersController = OrdersController = __decorate([
    (0, swagger_1.ApiTags)('orders'),
    (0, common_1.Controller)('orders'),
    __metadata("design:paramtypes", [orders_service_1.OrdersService,
        excel_import_service_1.ExcelImportService])
], OrdersController);
//# sourceMappingURL=orders.controller.js.map