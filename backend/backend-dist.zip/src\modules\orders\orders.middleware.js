"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrdersDataMiddleware = void 0;
const common_1 = require("@nestjs/common");
let OrdersDataMiddleware = class OrdersDataMiddleware {
    constructor() {
        this.logger = new common_1.Logger('OrdersDataMiddleware');
    }
    use(req, res, next) {
        if ((req.method === 'POST' || req.method === 'PUT') &&
            (req.originalUrl.includes('/orders') && !req.originalUrl.includes('/upload'))) {
            this.logger.log(`Обработка ${req.method} запроса к ${req.originalUrl}`);
            this.logger.debug('Оригинальное тело запроса:', req.body);
            if (req.body) {
                if (req.body.priority !== undefined) {
                    const originalPriority = req.body.priority;
                    req.body.priority = typeof req.body.priority === 'string'
                        ? parseInt(req.body.priority, 10)
                        : req.body.priority;
                    this.logger.log(`Priority: ${originalPriority} -> ${req.body.priority}`);
                }
                if (req.body.operations && Array.isArray(req.body.operations)) {
                    this.logger.log(`Преобразование ${req.body.operations.length} операций`);
                    req.body.operations = req.body.operations.map((op, index) => {
                        const updatedOp = { ...op };
                        if (updatedOp.operationNumber !== undefined) {
                            const original = updatedOp.operationNumber;
                            updatedOp.operationNumber = typeof updatedOp.operationNumber === 'string'
                                ? parseInt(updatedOp.operationNumber, 10)
                                : updatedOp.operationNumber;
                            this.logger.debug(`[Op ${index}] operationNumber: ${original} -> ${updatedOp.operationNumber}`);
                        }
                        if (updatedOp.machineAxes !== undefined) {
                            const original = updatedOp.machineAxes;
                            if (typeof updatedOp.machineAxes === 'number' ||
                                (typeof updatedOp.machineAxes === 'string' && !updatedOp.machineAxes.includes('-axis'))) {
                                updatedOp.machineAxes = `${updatedOp.machineAxes}-axis`;
                            }
                            this.logger.debug(`[Op ${index}] machineAxes: ${original} -> ${updatedOp.machineAxes}`);
                        }
                        if (updatedOp.estimatedTime !== undefined) {
                            const original = updatedOp.estimatedTime;
                            updatedOp.estimatedTime = typeof updatedOp.estimatedTime === 'string'
                                ? parseInt(updatedOp.estimatedTime, 10)
                                : updatedOp.estimatedTime;
                            this.logger.debug(`[Op ${index}] estimatedTime: ${original} -> ${updatedOp.estimatedTime}`);
                        }
                        return updatedOp;
                    });
                    this.logger.debug('Преобразованные операции:', req.body.operations);
                }
            }
            this.logger.debug('Преобразованное тело запроса:', req.body);
        }
        next();
    }
};
exports.OrdersDataMiddleware = OrdersDataMiddleware;
exports.OrdersDataMiddleware = OrdersDataMiddleware = __decorate([
    (0, common_1.Injectable)()
], OrdersDataMiddleware);
//# sourceMappingURL=orders.middleware.js.map