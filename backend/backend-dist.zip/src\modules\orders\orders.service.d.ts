import { Repository } from 'typeorm';
import { Order } from '../../database/entities/order.entity';
import { Operation } from '../../database/entities/operation.entity';
import { CreateOrderDto } from './dto/create-order.dto';
import { UpdateOrderDto } from './dto/update-order.dto';
import { OrdersFilterDto } from './dto/orders-filter.dto';
import { OrderFileSystemService } from './order-filesystem.service';
export declare class OrdersService {
    private readonly orderRepository;
    private readonly operationRepository;
    private readonly orderFileSystemService;
    constructor(orderRepository: Repository<Order>, operationRepository: Repository<Operation>, orderFileSystemService: OrderFileSystemService);
    findAll(filterDto?: OrdersFilterDto): Promise<{
        data: {
            name: string;
            clientName: string;
            remainingQuantity: number;
            status: string;
            completionPercentage: number;
            forecastedCompletionDate: Date;
            isOnSchedule: boolean;
            lastRecalculationAt: Date;
            operations: Operation[];
            id: number;
            drawingNumber: string;
            deadline: Date;
            quantity: number;
            priority: number;
            workType: string;
            pdfPath: string;
            pdfUrl?: string;
            createdAt: Date;
            updatedAt: Date;
        }[];
        total: number;
        page: number;
        limit: number;
        totalPages: number;
    }>;
    findOne(id: string): Promise<Order>;
    findByDrawingNumber(drawingNumber: string): Promise<Order | null>;
    create(createOrderDto: CreateOrderDto): Promise<Order>;
    update(id: string, updateOrderDto: UpdateOrderDto): Promise<Order>;
    remove(id: string): Promise<void>;
    removeBatch(ids: string[]): Promise<number>;
    removeAll(): Promise<number>;
    uploadPdf(id: string, filename: string): Promise<Order>;
    private enrichOrder;
    private calculateOrderStatus;
    private calculateCompletionPercentage;
    private isOrderOnSchedule;
    private saveOrderToFileSystem;
    private updateOrderInFileSystem;
    exportAllOrdersToFileSystem(): Promise<{
        success: number;
        errors: number;
    }>;
}
