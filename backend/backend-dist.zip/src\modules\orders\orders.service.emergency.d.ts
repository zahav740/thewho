import { Repository } from 'typeorm';
import { Order } from '../../database/entities/order.entity';
import { Operation } from '../../database/entities/operation.entity';
import { CreateOrderDto } from './dto/create-order.dto';
import { UpdateOrderDto } from './dto/update-order.dto';
import { OrdersFilterDto } from './dto/orders-filter.dto';
export declare class OrdersService {
    private readonly orderRepository;
    private readonly operationRepository;
    constructor(orderRepository: Repository<Order>, operationRepository: Repository<Operation>);
    findAll(filterDto?: OrdersFilterDto): Promise<{
        data: {
            name: string;
            clientName: string;
            remainingQuantity: number;
            status: string;
            completionPercentage: number;
            forecastedCompletionDate: Date;
            isOnSchedule: boolean;
            lastRecalculationAt: Date;
            operations: any[];
            id: number;
            drawingNumber: string;
            deadline: Date;
            quantity: number;
            priority: number;
            workType: string;
            pdfPath: string;
            pdfUrl?: string;
            createdAt: Date;
            updatedAt: Date;
        }[];
        total: number;
        page: number;
        limit: number;
        totalPages: number;
    } | {
        data: {
            id: number;
            drawingNumber: string;
            name: string;
            clientName: string;
            quantity: number;
            remainingQuantity: number;
            deadline: Date;
            priority: number;
            status: string;
            completionPercentage: number;
            operations: any[];
        }[];
        total: number;
        page: number;
        limit: number;
        totalPages: number;
    }>;
    findOne(id: string): Promise<Order>;
    create(createOrderDto: CreateOrderDto): Promise<Order>;
    update(id: string, updateOrderDto: UpdateOrderDto): Promise<Order>;
    private enrichOrder;
}
