import { Repository } from 'typeorm';
import { Order } from '../../database/entities/order.entity';
import { CreateOrderDto } from './dto/create-order.dto';
import { UpdateOrderDto } from './dto/update-order.dto';
import { OrdersFilterDto } from './dto/orders-filter.dto';
export declare class OrdersServiceFixed {
    private readonly orderRepository;
    constructor(orderRepository: Repository<Order>);
    findAll(filterDto?: OrdersFilterDto): Promise<{
        id: number;
        drawingNumber: string;
        quantity: number;
        deadline: Date;
        priority: number;
        workType: string;
        pdfPath: string;
        pdfUrl: string;
        name: string;
        clientName: string;
        remainingQuantity: number;
        status: string;
        completionPercentage: number;
        forecastedCompletionDate: Date;
        isOnSchedule: boolean;
        lastRecalculationAt: Date;
        createdAt: Date;
        updatedAt: Date;
        operations: any[];
    }[]>;
    findOne(id: string): Promise<Order>;
    create(createOrderDto: CreateOrderDto): Promise<Order>;
    update(id: string, updateOrderDto: UpdateOrderDto): Promise<Order>;
    remove(id: string): Promise<void>;
    removeBatch(ids: string[]): Promise<number>;
    removeAll(): Promise<number>;
    uploadPdf(id: string, filename: string): Promise<Order>;
    findByDrawingNumber(drawingNumber: string): Promise<Order | null>;
}
