"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrdersServiceFixed = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const order_entity_1 = require("../../database/entities/order.entity");
let OrdersServiceFixed = class OrdersServiceFixed {
    constructor(orderRepository) {
        this.orderRepository = orderRepository;
    }
    async findAll(filterDto) {
        try {
            console.log('OrdersServiceFixed.findAll: Начало выполнения');
            const orders = await this.orderRepository
                .createQueryBuilder('order')
                .select([
                'order.id',
                'order.drawingNumber',
                'order.quantity',
                'order.deadline',
                'order.priority',
                'order.workType',
                'order.pdfPath',
                'order.createdAt',
                'order.updatedAt'
            ])
                .orderBy('order.priority', 'ASC')
                .addOrderBy('order.deadline', 'ASC')
                .getMany();
            console.log(`OrdersServiceFixed.findAll: Найдено ${orders.length} заказов`);
            const convertedOrders = orders.map(order => ({
                id: order.id,
                drawingNumber: order.drawingNumber || '',
                quantity: order.quantity || 0,
                deadline: order.deadline,
                priority: order.priority || 3,
                workType: order.workType || '',
                pdfPath: order.pdfPath || null,
                pdfUrl: order.pdfPath || null,
                name: order.drawingNumber || '',
                clientName: 'Не указан',
                remainingQuantity: order.quantity || 0,
                status: 'planned',
                completionPercentage: 0,
                forecastedCompletionDate: order.deadline,
                isOnSchedule: true,
                lastRecalculationAt: order.updatedAt || new Date(),
                createdAt: order.createdAt,
                updatedAt: order.updatedAt,
                operations: []
            }));
            console.log('OrdersServiceFixed.findAll: Успешно преобразовано');
            return convertedOrders;
        }
        catch (error) {
            console.error('OrdersServiceFixed.findAll Ошибка:', error);
            return [];
        }
    }
    async findOne(id) {
        try {
            const numericId = parseInt(id);
            if (isNaN(numericId)) {
                throw new common_1.NotFoundException(`Некорректный ID заказа: ${id}`);
            }
            const order = await this.orderRepository.findOne({
                where: { id: numericId }
            });
            if (!order) {
                throw new common_1.NotFoundException(`Заказ с ID ${id} не найден`);
            }
            return order;
        }
        catch (error) {
            console.error(`OrdersServiceFixed.findOne error for id ${id}:`, error);
            throw error;
        }
    }
    async create(createOrderDto) {
        try {
            const orderData = {
                drawingNumber: createOrderDto.drawingNumber,
                quantity: createOrderDto.quantity,
                deadline: new Date(createOrderDto.deadline),
                priority: createOrderDto.priority,
                workType: createOrderDto.workType,
            };
            const order = this.orderRepository.create(orderData);
            const savedOrder = await this.orderRepository.save(order);
            return savedOrder;
        }
        catch (error) {
            console.error('OrdersServiceFixed.create Ошибка:', error);
            throw error;
        }
    }
    async update(id, updateOrderDto) {
        const order = await this.findOne(id);
        const updateData = {};
        if (updateOrderDto.drawingNumber !== undefined) {
            updateData.drawingNumber = updateOrderDto.drawingNumber;
        }
        if (updateOrderDto.quantity !== undefined) {
            updateData.quantity = updateOrderDto.quantity;
        }
        if (updateOrderDto.workType !== undefined) {
            updateData.workType = updateOrderDto.workType;
        }
        if (updateOrderDto.priority !== undefined) {
            updateData.priority = updateOrderDto.priority;
        }
        if (updateOrderDto.deadline !== undefined) {
            updateData.deadline = new Date(updateOrderDto.deadline);
        }
        Object.assign(order, updateData);
        return this.orderRepository.save(order);
    }
    async remove(id) {
        const order = await this.findOne(id);
        await this.orderRepository.remove(order);
    }
    async removeBatch(ids) {
        try {
            const numericIds = ids.map(id => parseInt(id)).filter(id => !isNaN(id));
            const result = await this.orderRepository.delete(numericIds);
            return result.affected || 0;
        }
        catch (error) {
            console.error('OrdersServiceFixed.removeBatch Ошибка:', error);
            throw error;
        }
    }
    async removeAll() {
        try {
            const count = await this.orderRepository.count();
            await this.orderRepository.clear();
            return count;
        }
        catch (error) {
            console.error('OrdersServiceFixed.removeAll Ошибка:', error);
            throw error;
        }
    }
    async uploadPdf(id, filename) {
        const order = await this.findOne(id);
        order.pdfPath = filename;
        return this.orderRepository.save(order);
    }
    async findByDrawingNumber(drawingNumber) {
        return this.orderRepository.findOne({
            where: { drawingNumber }
        });
    }
};
exports.OrdersServiceFixed = OrdersServiceFixed;
exports.OrdersServiceFixed = OrdersServiceFixed = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(order_entity_1.Order)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], OrdersServiceFixed);
//# sourceMappingURL=orders.service.fixed.js.map