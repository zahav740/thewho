"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrdersService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const order_entity_1 = require("../../database/entities/order.entity");
const operation_entity_1 = require("../../database/entities/operation.entity");
const order_filesystem_service_1 = require("./order-filesystem.service");
let OrdersService = class OrdersService {
    constructor(orderRepository, operationRepository, orderFileSystemService) {
        this.orderRepository = orderRepository;
        this.operationRepository = operationRepository;
        this.orderFileSystemService = orderFileSystemService;
    }
    async findAll(filterDto) {
        console.log('OrdersService.findAll: Получение всех заказов');
        console.log('OrdersService.findAll: Filter:', filterDto);
        let query = this.orderRepository.createQueryBuilder('order')
            .leftJoinAndSelect('order.operations', 'operation')
            .orderBy('operation.operationNumber', 'ASC');
        if (filterDto?.search) {
            query = query.where('order.drawingNumber ILIKE :search OR order.workType ILIKE :search', { search: `%${filterDto.search}%` });
        }
        if (filterDto?.priority) {
            query = query.andWhere('order.priority = :priority', { priority: filterDto.priority });
        }
        query = query.addOrderBy('order.priority', 'ASC')
            .addOrderBy('order.deadline', 'ASC');
        let page = filterDto?.page || 1;
        let limit = filterDto?.limit || 10;
        const skip = (page - 1) * limit;
        query = query.skip(skip).take(limit);
        const [orders, total] = await query.getManyAndCount();
        console.log(`OrdersService.findAll: Найдено ${orders.length} заказов из ${total}`);
        const enrichedOrders = orders.map(order => {
            return {
                ...order,
                name: order.drawingNumber || 'Без имени',
                clientName: 'Не указан',
                remainingQuantity: order.quantity,
                status: this.calculateOrderStatus(order),
                completionPercentage: this.calculateCompletionPercentage(order),
                forecastedCompletionDate: order.deadline,
                isOnSchedule: this.isOrderOnSchedule(order),
                lastRecalculationAt: order.updatedAt || order.createdAt || new Date(),
                operations: order.operations || []
            };
        });
        return {
            data: enrichedOrders,
            total,
            page: page,
            limit: limit,
            totalPages: Math.ceil(total / limit) || 1
        };
    }
    async findOne(id) {
        console.log(`OrdersService.findOne: Поиск заказа с ID ${id}`);
        const numericId = parseInt(id, 10);
        if (isNaN(numericId)) {
            throw new common_1.NotFoundException(`Некорректный ID заказа: ${id}`);
        }
        const order = await this.orderRepository.findOne({
            where: { id: numericId },
            relations: ['operations']
        });
        if (!order) {
            throw new common_1.NotFoundException(`Заказ с ID ${id} не найден`);
        }
        console.log(`OrdersService.findOne: Найден заказ ${order.drawingNumber} с ${order.operations?.length || 0} операциями`);
        const enrichedOrder = this.enrichOrder(order);
        return enrichedOrder;
    }
    async findByDrawingNumber(drawingNumber) {
        const order = await this.orderRepository.findOne({
            where: { drawingNumber },
            relations: ['operations']
        });
        return order ? this.enrichOrder(order) : null;
    }
    async create(createOrderDto) {
        console.log('OrdersService.create: Начало создания заказа:', createOrderDto);
        const { operations: operationsDto, ...orderData } = createOrderDto;
        const orderEntityData = {
            ...orderData,
            priority: Number(orderData.priority),
            deadline: new Date(orderData.deadline)
        };
        console.log('OrdersService.create: Данные заказа для сохранения:', orderEntityData);
        const orderEntity = this.orderRepository.create(orderEntityData);
        const savedOrder = await this.orderRepository.save(orderEntity);
        console.log(`OrdersService.create: Заказ создан с ID ${savedOrder.id}`);
        if (operationsDto && operationsDto.length > 0) {
            console.log(`OrdersService.create: Создание ${operationsDto.length} операций`);
            const operationEntities = operationsDto.map(opDto => {
                return this.operationRepository.create({
                    operationNumber: Number(opDto.operationNumber),
                    operationType: opDto.operationType,
                    estimatedTime: Number(opDto.estimatedTime),
                    machineAxes: Number(opDto.machineAxes),
                    status: 'PENDING',
                    order: savedOrder,
                });
            });
            const savedOperations = await this.operationRepository.save(operationEntities);
            console.log(`OrdersService.create: Создано ${savedOperations.length} операций`);
        }
        const orderWithOperations = await this.orderRepository.findOne({
            where: { id: savedOrder.id },
            relations: ['operations']
        });
        if (!orderWithOperations) {
            throw new common_1.InternalServerErrorException('Не удалось загрузить созданный заказ');
        }
        console.log(`OrdersService.create: Заказ создан с ${orderWithOperations.operations?.length || 0} операциями`);
        await this.saveOrderToFileSystem(orderWithOperations, orderWithOperations.operations || []);
        return this.enrichOrder(orderWithOperations);
    }
    async update(id, updateOrderDto) {
        console.log(`OrdersService.update: Обновление заказа ${id}:`, updateOrderDto);
        const numericId = parseInt(id, 10);
        if (isNaN(numericId)) {
            throw new common_1.NotFoundException(`Некорректный ID заказа: ${id}`);
        }
        const order = await this.orderRepository.findOne({
            where: { id: numericId },
            relations: ['operations']
        });
        if (!order) {
            throw new common_1.NotFoundException(`Заказ с ID ${id} не найден`);
        }
        if (updateOrderDto.drawingNumber !== undefined) {
            order.drawingNumber = updateOrderDto.drawingNumber;
        }
        if (updateOrderDto.quantity !== undefined) {
            order.quantity = updateOrderDto.quantity;
        }
        if (updateOrderDto.workType !== undefined) {
            order.workType = updateOrderDto.workType;
        }
        if (updateOrderDto.priority !== undefined) {
            order.priority = Number(updateOrderDto.priority);
        }
        if (updateOrderDto.deadline !== undefined) {
            order.deadline = new Date(updateOrderDto.deadline);
        }
        const savedOrder = await this.orderRepository.save(order);
        if (updateOrderDto.operations) {
            await this.operationRepository.delete({ order: { id: numericId } });
            if (updateOrderDto.operations.length > 0) {
                const operationEntities = updateOrderDto.operations.map(opDto => {
                    return this.operationRepository.create({
                        operationNumber: Number(opDto.operationNumber),
                        operationType: opDto.operationType,
                        estimatedTime: Number(opDto.estimatedTime),
                        machineAxes: Number(opDto.machineAxes),
                        status: 'PENDING',
                        order: savedOrder,
                    });
                });
                await this.operationRepository.save(operationEntities);
            }
        }
        const updatedOrder = await this.orderRepository.findOne({
            where: { id: numericId },
            relations: ['operations']
        });
        await this.updateOrderInFileSystem(updatedOrder, updatedOrder.operations || []);
        return this.enrichOrder(updatedOrder);
    }
    async remove(id) {
        console.log(`OrdersService.remove: Удаление заказа ${id}`);
        const numericId = parseInt(id, 10);
        if (isNaN(numericId)) {
            throw new common_1.NotFoundException(`Некорректный ID заказа: ${id}`);
        }
        const result = await this.orderRepository.delete(numericId);
        if (result.affected === 0) {
            throw new common_1.NotFoundException(`Заказ с ID ${id} не найден`);
        }
        console.log(`OrdersService.remove: Заказ ${id} удален`);
    }
    async removeBatch(ids) {
        console.log(`OrdersService.removeBatch: Удаление заказов ${ids.join(', ')}`);
        const numericIds = ids.map(id => parseInt(id, 10)).filter(id => !isNaN(id));
        if (numericIds.length === 0) {
            return 0;
        }
        const result = await this.orderRepository.delete(numericIds);
        console.log(`OrdersService.removeBatch: Удалено ${result.affected} заказов`);
        return result.affected || 0;
    }
    async removeAll() {
        console.log(`OrdersService.removeAll: Удаление всех заказов`);
        const result = await this.orderRepository.delete({});
        console.log(`OrdersService.removeAll: Удалено ${result.affected} заказов`);
        return result.affected || 0;
    }
    async uploadPdf(id, filename) {
        console.log(`OrdersService.uploadPdf: Загрузка PDF для заказа ${id}`);
        const order = await this.findOne(id);
        order.pdfPath = filename;
        const numericId = parseInt(id, 10);
        await this.orderRepository.update(numericId, { pdfPath: filename });
        return order;
    }
    enrichOrder(order) {
        const enriched = { ...order };
        enriched.name = enriched.drawingNumber || 'Без имени';
        enriched.clientName = 'Не указан';
        enriched.remainingQuantity = enriched.quantity;
        enriched.status = this.calculateOrderStatus(order);
        enriched.completionPercentage = this.calculateCompletionPercentage(order);
        enriched.forecastedCompletionDate = enriched.deadline;
        enriched.isOnSchedule = this.isOrderOnSchedule(order);
        enriched.lastRecalculationAt = enriched.updatedAt || enriched.createdAt || new Date();
        enriched.operations = enriched.operations || [];
        return enriched;
    }
    calculateOrderStatus(order) {
        if (!order.operations || order.operations.length === 0) {
            return 'planned';
        }
        const completedOps = order.operations.filter(op => op.status === 'COMPLETED').length;
        const totalOps = order.operations.length;
        if (completedOps === 0)
            return 'planned';
        if (completedOps === totalOps)
            return 'completed';
        return 'in_progress';
    }
    calculateCompletionPercentage(order) {
        if (!order.operations || order.operations.length === 0) {
            return 0;
        }
        const completedOps = order.operations.filter(op => op.status === 'COMPLETED').length;
        return Math.round((completedOps / order.operations.length) * 100);
    }
    isOrderOnSchedule(order) {
        const now = new Date();
        const deadline = new Date(order.deadline);
        const daysUntilDeadline = Math.ceil((deadline.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
        return daysUntilDeadline > 3;
    }
    async saveOrderToFileSystem(order, operations) {
        try {
            const fileSystemData = {
                order: {
                    ...order,
                    operations: undefined
                },
                operations: operations.map(op => ({
                    ...op,
                    order: undefined
                })),
                metadata: {
                    version: '1.0',
                    created_at: order.createdAt?.toISOString() || new Date().toISOString(),
                    updated_at: order.updatedAt?.toISOString() || new Date().toISOString(),
                    changes_summary: 'Создание заказа',
                    data_source: 'orders_service',
                    export_date: new Date().toISOString()
                }
            };
            await this.orderFileSystemService.createOrderVersion(order.drawingNumber, fileSystemData);
            console.log(`OrdersService: Заказ ${order.drawingNumber} сохранен в файловую систему`);
        }
        catch (error) {
            console.error(`Ошибка сохранения заказа ${order.drawingNumber} в файловую систему:`, error);
        }
    }
    async updateOrderInFileSystem(order, operations) {
        try {
            const fileSystemData = {
                order: {
                    ...order,
                    operations: undefined
                },
                operations: operations.map(op => ({
                    ...op,
                    order: undefined
                })),
                metadata: {
                    version: '1.1',
                    created_at: order.createdAt?.toISOString() || new Date().toISOString(),
                    updated_at: new Date().toISOString(),
                    changes_summary: 'Обновление заказа',
                    data_source: 'orders_service',
                    export_date: new Date().toISOString()
                }
            };
            await this.orderFileSystemService.updateOrderVersion(order.drawingNumber, fileSystemData);
            console.log(`OrdersService: Создана новая версия заказа ${order.drawingNumber} в файловой системе`);
        }
        catch (error) {
            console.error(`Ошибка обновления заказа ${order.drawingNumber} в файловой системе:`, error);
        }
    }
    async exportAllOrdersToFileSystem() {
        console.log('OrdersService: Начинаем экспорт всех заказов в файловую систему');
        const orders = await this.orderRepository.find({ relations: ['operations'] });
        let success = 0;
        let errors = 0;
        for (const order of orders) {
            try {
                await this.orderFileSystemService.exportOrderFromDatabase(order, order.operations || []);
                success++;
                console.log(`Экспортирован заказ ${order.drawingNumber}`);
            }
            catch (error) {
                errors++;
                console.error(`Ошибка экспорта заказа ${order.drawingNumber}:`, error);
            }
        }
        console.log(`OrdersService: Экспорт завершен. Успешно: ${success}, Ошибок: ${errors}`);
        return { success, errors };
    }
};
exports.OrdersService = OrdersService;
exports.OrdersService = OrdersService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(order_entity_1.Order)),
    __param(1, (0, typeorm_1.InjectRepository)(operation_entity_1.Operation)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        order_filesystem_service_1.OrderFileSystemService])
], OrdersService);
//# sourceMappingURL=orders.service.js.map