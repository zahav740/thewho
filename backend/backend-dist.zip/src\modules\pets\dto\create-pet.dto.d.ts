import { PetType, AnimalSize } from '../entities/pet.entity';
export declare class CreatePetDto {
    title: string;
    description: string;
    type: PetType;
    animalType: string;
    breed?: string;
    color?: string;
    age?: number;
    size?: AnimalSize;
    lastSeenLatitude?: number;
    lastSeenLongitude?: number;
    lastSeenAddress?: string;
    contactPhone?: string;
    contactEmail?: string;
    preferredContact?: string;
    images?: string[];
    reward?: number;
    userId: string;
    userName: string;
}
