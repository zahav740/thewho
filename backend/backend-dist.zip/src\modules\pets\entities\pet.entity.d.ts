export declare enum PetType {
    LOST = "lost",
    FOUND = "found"
}
export declare enum PetStatus {
    ACTIVE = "active",
    RESOLVED = "resolved",
    CLOSED = "closed"
}
export declare enum AnimalSize {
    SMALL = "small",
    MEDIUM = "medium",
    LARGE = "large"
}
export declare class Pet {
    id: string;
    title: string;
    description: string;
    type: PetType;
    status: PetStatus;
    animalType: string;
    breed?: string;
    color?: string;
    age?: number;
    size?: AnimalSize;
    lastSeenLatitude?: number;
    lastSeenLongitude?: number;
    lastSeenAddress?: string;
    contactPhone?: string;
    contactEmail?: string;
    preferredContact: string;
    images: string[];
    reward?: number;
    userId: string;
    userName: string;
    createdAt: Date;
    updatedAt: Date;
}
