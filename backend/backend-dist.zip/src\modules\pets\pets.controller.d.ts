import { PetsService } from './pets.service';
import { CreatePetDto } from './dto/create-pet.dto';
import { Pet, PetType, PetStatus } from './entities/pet.entity';
export declare class PetsController {
    private readonly petsService;
    constructor(petsService: PetsService);
    create(createPetDto: CreatePetDto): Promise<Pet>;
    findAll(page?: string, limit?: string, type?: PetType, status?: PetStatus, animalType?: string): Promise<{
        pets: Pet[];
        total: number;
        page: number;
        limit: number;
    }>;
    getStats(): Promise<{
        total: number;
        lost: number;
        found: number;
        resolved: number;
        active: number;
    }>;
    findNearby(lat: string, lng: string, radius?: string, type?: PetType): Promise<Pet[]>;
    findOne(id: string): Promise<Pet>;
    update(id: string, updatePetDto: Partial<CreatePetDto>): Promise<Pet>;
    updateStatus(id: string, status: PetStatus): Promise<Pet>;
    remove(id: string): Promise<void>;
}
