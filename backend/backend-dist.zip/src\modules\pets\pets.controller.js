"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PetsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const pets_service_1 = require("./pets.service");
const create_pet_dto_1 = require("./dto/create-pet.dto");
const pet_entity_1 = require("./entities/pet.entity");
let PetsController = class PetsController {
    constructor(petsService) {
        this.petsService = petsService;
    }
    async create(createPetDto) {
        console.log('PetsController.create: Создание объявления о животном', createPetDto.title);
        return await this.petsService.create(createPetDto);
    }
    async findAll(page = '1', limit = '10', type, status, animalType) {
        console.log('PetsController.findAll: Запрос списка животных', { page, limit, type, status, animalType });
        const pageNum = parseInt(page, 10) || 1;
        const limitNum = parseInt(limit, 10) || 10;
        const result = await this.petsService.findAll(pageNum, limitNum, type, status, animalType);
        console.log(`PetsController.findAll: Найдено ${result.pets.length} объявлений из ${result.total}`);
        return result;
    }
    async getStats() {
        console.log('PetsController.getStats: Запрос статистики');
        return await this.petsService.getStats();
    }
    async findNearby(lat, lng, radius = '10', type) {
        console.log('PetsController.findNearby: Поиск поблизости', { lat, lng, radius, type });
        const latitude = parseFloat(lat);
        const longitude = parseFloat(lng);
        const radiusKm = parseFloat(radius) || 10;
        return await this.petsService.findNearby(latitude, longitude, radiusKm, type);
    }
    async findOne(id) {
        console.log('PetsController.findOne: Поиск объявления по ID', id);
        return await this.petsService.findOne(id);
    }
    async update(id, updatePetDto) {
        console.log('PetsController.update: Обновление объявления', id);
        return await this.petsService.update(id, updatePetDto);
    }
    async updateStatus(id, status) {
        console.log('PetsController.updateStatus: Изменение статуса', { id, status });
        return await this.petsService.updateStatus(id, status);
    }
    async remove(id) {
        console.log('PetsController.remove: Удаление объявления', id);
        await this.petsService.remove(id);
    }
};
exports.PetsController = PetsController;
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Создать объявление о животном' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: 'Объявление создано', type: pet_entity_1.Pet }),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    (0, common_1.UsePipes)(common_1.ValidationPipe),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_pet_dto_1.CreatePetDto]),
    __metadata("design:returntype", Promise)
], PetsController.prototype, "create", null);
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Получить список объявлений о животных' }),
    (0, swagger_1.ApiQuery)({ name: 'page', required: false, description: 'Номер страницы' }),
    (0, swagger_1.ApiQuery)({ name: 'limit', required: false, description: 'Количество на странице' }),
    (0, swagger_1.ApiQuery)({ name: 'type', required: false, enum: pet_entity_1.PetType, description: 'Тип объявления' }),
    (0, swagger_1.ApiQuery)({ name: 'status', required: false, enum: pet_entity_1.PetStatus, description: 'Статус объявления' }),
    (0, swagger_1.ApiQuery)({ name: 'animalType', required: false, description: 'Тип животного' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Список объявлений получен' }),
    __param(0, (0, common_1.Query)('page')),
    __param(1, (0, common_1.Query)('limit')),
    __param(2, (0, common_1.Query)('type')),
    __param(3, (0, common_1.Query)('status')),
    __param(4, (0, common_1.Query)('animalType')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String, String]),
    __metadata("design:returntype", Promise)
], PetsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('stats'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить статистику объявлений' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Статистика получена' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], PetsController.prototype, "getStats", null);
__decorate([
    (0, common_1.Get)('nearby'),
    (0, swagger_1.ApiOperation)({ summary: 'Найти животных поблизости' }),
    (0, swagger_1.ApiQuery)({ name: 'lat', required: true, description: 'Широта' }),
    (0, swagger_1.ApiQuery)({ name: 'lng', required: true, description: 'Долгота' }),
    (0, swagger_1.ApiQuery)({ name: 'radius', required: false, description: 'Радиус поиска в км' }),
    (0, swagger_1.ApiQuery)({ name: 'type', required: false, enum: pet_entity_1.PetType, description: 'Тип объявления' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Список найденных животных' }),
    __param(0, (0, common_1.Query)('lat')),
    __param(1, (0, common_1.Query)('lng')),
    __param(2, (0, common_1.Query)('radius')),
    __param(3, (0, common_1.Query)('type')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String, String, String]),
    __metadata("design:returntype", Promise)
], PetsController.prototype, "findNearby", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить объявление по ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Объявление найдено', type: pet_entity_1.Pet }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Объявление не найдено' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PetsController.prototype, "findOne", null);
__decorate([
    (0, common_1.Patch)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Обновить объявление' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Объявление обновлено', type: pet_entity_1.Pet }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Объявление не найдено' }),
    (0, common_1.UsePipes)(common_1.ValidationPipe),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], PetsController.prototype, "update", null);
__decorate([
    (0, common_1.Patch)(':id/status'),
    (0, swagger_1.ApiOperation)({ summary: 'Изменить статус объявления' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Статус изменен', type: pet_entity_1.Pet }),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __param(1, (0, common_1.Body)('status')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], PetsController.prototype, "updateStatus", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Удалить объявление' }),
    (0, swagger_1.ApiResponse)({ status: 204, description: 'Объявление удалено' }),
    (0, swagger_1.ApiResponse)({ status: 404, description: 'Объявление не найдено' }),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    __param(0, (0, common_1.Param)('id', common_1.ParseUUIDPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], PetsController.prototype, "remove", null);
exports.PetsController = PetsController = __decorate([
    (0, swagger_1.ApiTags)('Pets - FindThePuppy'),
    (0, common_1.Controller)('pets'),
    __metadata("design:paramtypes", [pets_service_1.PetsService])
], PetsController);
//# sourceMappingURL=pets.controller.js.map