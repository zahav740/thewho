export declare class PetsModule {
}
