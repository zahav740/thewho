import { Repository } from 'typeorm';
import { Pet, PetStatus, PetType } from './entities/pet.entity';
import { CreatePetDto } from './dto/create-pet.dto';
export declare class PetsService {
    private readonly petRepository;
    constructor(petRepository: Repository<Pet>);
    create(createPetDto: CreatePetDto): Promise<Pet>;
    findAll(page?: number, limit?: number, type?: PetType, status?: PetStatus, animalType?: string): Promise<{
        pets: Pet[];
        total: number;
        page: number;
        limit: number;
    }>;
    findOne(id: string): Promise<Pet>;
    update(id: string, updateData: Partial<CreatePetDto>): Promise<Pet>;
    remove(id: string): Promise<void>;
    updateStatus(id: string, status: PetStatus): Promise<Pet>;
    findNearby(latitude: number, longitude: number, radiusKm?: number, type?: PetType): Promise<Pet[]>;
    getStats(): Promise<{
        total: number;
        lost: number;
        found: number;
        resolved: number;
        active: number;
    }>;
}
