"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PetsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const pet_entity_1 = require("./entities/pet.entity");
let PetsService = class PetsService {
    constructor(petRepository) {
        this.petRepository = petRepository;
    }
    async create(createPetDto) {
        const pet = this.petRepository.create(createPetDto);
        return await this.petRepository.save(pet);
    }
    async findAll(page = 1, limit = 10, type, status, animalType) {
        const query = this.petRepository.createQueryBuilder('pet');
        if (type) {
            query.andWhere('pet.type = :type', { type });
        }
        if (status) {
            query.andWhere('pet.status = :status', { status });
        }
        else {
            query.andWhere('pet.status = :status', { status: pet_entity_1.PetStatus.ACTIVE });
        }
        if (animalType) {
            query.andWhere('LOWER(pet.animalType) LIKE LOWER(:animalType)', {
                animalType: `%${animalType}%`
            });
        }
        query.orderBy('pet.createdAt', 'DESC');
        query.skip((page - 1) * limit);
        query.take(limit);
        const [pets, total] = await query.getManyAndCount();
        return {
            pets,
            total,
            page,
            limit,
        };
    }
    async findOne(id) {
        const pet = await this.petRepository.findOne({ where: { id } });
        if (!pet) {
            throw new common_1.NotFoundException(`Pet with ID ${id} not found`);
        }
        return pet;
    }
    async update(id, updateData) {
        const pet = await this.findOne(id);
        Object.assign(pet, updateData);
        return await this.petRepository.save(pet);
    }
    async remove(id) {
        const pet = await this.findOne(id);
        await this.petRepository.remove(pet);
    }
    async updateStatus(id, status) {
        const pet = await this.findOne(id);
        pet.status = status;
        return await this.petRepository.save(pet);
    }
    async findNearby(latitude, longitude, radiusKm = 10, type) {
        const query = `
      SELECT *, 
        (6371 * acos(
          cos(radians($1)) * 
          cos(radians("lastSeenLatitude")) * 
          cos(radians("lastSeenLongitude") - radians($2)) + 
          sin(radians($1)) * 
          sin(radians("lastSeenLatitude"))
        )) AS distance
      FROM pets 
      WHERE "lastSeenLatitude" IS NOT NULL 
        AND "lastSeenLongitude" IS NOT NULL
        AND status = 'active'
        ${type ? `AND type = '${type}'` : ''}
      HAVING distance < $3
      ORDER BY distance;
    `;
        return await this.petRepository.query(query, [latitude, longitude, radiusKm]);
    }
    async getStats() {
        const [total, lost, found, resolved, active] = await Promise.all([
            this.petRepository.count(),
            this.petRepository.count({ where: { type: pet_entity_1.PetType.LOST } }),
            this.petRepository.count({ where: { type: pet_entity_1.PetType.FOUND } }),
            this.petRepository.count({ where: { status: pet_entity_1.PetStatus.RESOLVED } }),
            this.petRepository.count({ where: { status: pet_entity_1.PetStatus.ACTIVE } }),
        ]);
        return { total, lost, found, resolved, active };
    }
};
exports.PetsService = PetsService;
exports.PetsService = PetsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(pet_entity_1.Pet)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], PetsService);
//# sourceMappingURL=pets.service.js.map