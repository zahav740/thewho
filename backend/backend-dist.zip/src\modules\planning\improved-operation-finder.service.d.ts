import { DataSource } from 'typeorm';
interface OperationInfo {
    id: number;
    orderId: number;
    operationNumber: number;
    operationType: string;
    estimatedTime: number;
    machineAxes: number;
    status: string;
    description: string;
    orderInfo: {
        drawingNumber: string;
        priority: number;
        quantity: number;
        deadline: string;
        workType: string;
    };
    canStart: boolean;
    blockingReason?: string;
    compatibleMachines: any[];
}
export declare class ImprovedOperationFinderService {
    private readonly dataSource;
    private readonly logger;
    constructor(dataSource: DataSource);
    findAllAvailableOperations(selectedMachineIds?: number[]): Promise<{
        totalOrders: number;
        totalOperations: number;
        availableOperations: OperationInfo[];
        readyToStart: number;
        needsPrerequisites: number;
        summary: string;
    }>;
    private findCompatibleMachines;
    private getAvailableMachines;
    private isOperationInProgress;
    getTopRecommendedOperations(selectedMachineIds?: number[]): Promise<OperationInfo[]>;
}
export {};
