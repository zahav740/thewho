import { ProductionPlanningExtensionsService } from './production-planning-extensions.service';
export declare class OperationSelectionController {
    private readonly planningExtensionsService;
    private readonly logger;
    constructor(planningExtensionsService: ProductionPlanningExtensionsService);
    getAvailableOperations(machineIds?: string): Promise<{
        success: boolean;
        data: {
            orders: import("./production-planning.service").OrderWithPriority[];
            availableOperations: {
                operationId: number;
                operationNumber: number;
                operationType: string;
                estimatedTime: number;
                estimatedTimeFormatted: string;
                machineAxes: number;
                status: string;
                canStart: boolean;
                blockingReason: string;
                order: {
                    id: number;
                    drawingNumber: string;
                    priority: number;
                    quantity: number;
                    deadline: Date;
                    workType: string;
                };
                compatibleMachines: {
                    id: number;
                    code: string;
                    type: string;
                    axes: number;
                    isActive: boolean;
                    isOccupied: boolean;
                }[];
            }[];
            totalOperations: number;
            summary: {
                totalOrders: number;
                totalOperations: number;
                readyToStart: number;
                waiting: number;
            };
        };
        error?: undefined;
        message?: undefined;
    } | {
        success: boolean;
        error: string;
        message: any;
        data?: undefined;
    }>;
    planWithSelectedOperations(request: {
        selectedMachines: number[];
        selectedOperations: {
            operationId: number;
            machineId: number;
        }[];
    }): Promise<{
        success: boolean;
        error: string;
        message?: undefined;
        data?: undefined;
    } | {
        success: boolean;
        message: string;
        data: {
            selectedOrdersCount: number;
            operationsQueueLength: number;
            totalTime: number;
            totalTimeFormatted: string;
            calculationDate: Date;
            details: import("./production-planning.service").PlanningResult;
        };
        error?: undefined;
    } | {
        success: boolean;
        error: string;
        message: any;
        data?: undefined;
    }>;
    private formatTime;
}
