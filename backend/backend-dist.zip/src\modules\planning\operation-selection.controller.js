"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var OperationSelectionController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationSelectionController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const production_planning_extensions_service_1 = require("./production-planning-extensions.service");
let OperationSelectionController = OperationSelectionController_1 = class OperationSelectionController {
    constructor(planningExtensionsService) {
        this.planningExtensionsService = planningExtensionsService;
        this.logger = new common_1.Logger(OperationSelectionController_1.name);
    }
    async getAvailableOperations(machineIds) {
        try {
            this.logger.log('Запрос доступных операций для выбора');
            let selectedMachineIds;
            if (machineIds) {
                selectedMachineIds = machineIds.split(',')
                    .map(id => parseInt(id.trim(), 10))
                    .filter(id => !isNaN(id));
            }
            const result = await this.planningExtensionsService.getAvailableOperations(selectedMachineIds);
            return {
                success: true,
                data: {
                    orders: result.orders,
                    availableOperations: result.availableOperations.map(op => ({
                        operationId: op.id,
                        operationNumber: op.operationNumber,
                        operationType: op.operationType,
                        estimatedTime: op.estimatedTime,
                        estimatedTimeFormatted: this.formatTime(op.estimatedTime),
                        machineAxes: op.machineAxes,
                        status: op.status,
                        canStart: op.canStart,
                        blockingReason: op.blockingReason,
                        order: {
                            id: op.orderInfo.id,
                            drawingNumber: op.orderInfo.drawingNumber,
                            priority: op.orderInfo.priority,
                            quantity: op.orderInfo.quantity,
                            deadline: op.orderInfo.deadline,
                            workType: op.orderInfo.workType
                        },
                        compatibleMachines: op.compatibleMachines.map(machine => ({
                            id: machine.id,
                            code: machine.code,
                            type: machine.type,
                            axes: machine.axes,
                            isActive: machine.isActive,
                            isOccupied: machine.isOccupied
                        }))
                    })),
                    totalOperations: result.totalOperations,
                    summary: {
                        totalOrders: result.orders.length,
                        totalOperations: result.totalOperations,
                        readyToStart: result.availableOperations.filter(op => op.canStart).length,
                        waiting: result.availableOperations.filter(op => !op.canStart).length
                    }
                }
            };
        }
        catch (error) {
            this.logger.error('Ошибка при получении доступных операций:', error);
            return {
                success: false,
                error: 'Ошибка при получении доступных операций',
                message: error.message
            };
        }
    }
    async planWithSelectedOperations(request) {
        try {
            this.logger.log('Запрос планирования с выбранными операциями');
            this.logger.log(`Выбрано операций: ${request.selectedOperations.length}`);
            if (!request.selectedOperations || request.selectedOperations.length === 0) {
                return {
                    success: false,
                    error: 'Не выбрано ни одной операции для планирования'
                };
            }
            const result = await this.planningExtensionsService.planWithSelectedOperations(request);
            return {
                success: true,
                message: `Планирование выполнено для ${request.selectedOperations.length} операций`,
                data: {
                    selectedOrdersCount: result.selectedOrders.length,
                    operationsQueueLength: result.operationsQueue.length,
                    totalTime: result.totalTime,
                    totalTimeFormatted: this.formatTime(result.totalTime),
                    calculationDate: result.calculationDate,
                    details: result
                }
            };
        }
        catch (error) {
            this.logger.error('Ошибка при планировании с выбранными операциями:', error);
            return {
                success: false,
                error: 'Ошибка при планировании',
                message: error.message
            };
        }
    }
    formatTime(minutes) {
        if (!minutes || minutes <= 0)
            return '0 мин';
        const hours = Math.floor(minutes / 60);
        const remainingMinutes = minutes % 60;
        if (hours === 0) {
            return `${remainingMinutes} мин`;
        }
        else if (remainingMinutes === 0) {
            return `${hours} ч`;
        }
        else {
            return `${hours} ч ${remainingMinutes} мин`;
        }
    }
};
exports.OperationSelectionController = OperationSelectionController;
__decorate([
    (0, common_1.Get)('available-operations'),
    (0, swagger_1.ApiOperation)({
        summary: 'Получить доступные операции для выбора',
        description: 'Возвращает список операций, которые пользователь может выбрать для планирования'
    }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Список доступных операций получен' }),
    __param(0, (0, common_1.Query)('machineIds')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], OperationSelectionController.prototype, "getAvailableOperations", null);
__decorate([
    (0, common_1.Post)('plan-selected'),
    (0, swagger_1.ApiOperation)({
        summary: 'Планирование с выбранными операциями',
        description: 'Выполняет планирование для операций, выбранных пользователем'
    }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Планирование выполнено' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], OperationSelectionController.prototype, "planWithSelectedOperations", null);
exports.OperationSelectionController = OperationSelectionController = OperationSelectionController_1 = __decorate([
    (0, swagger_1.ApiTags)('operation-selection'),
    (0, common_1.Controller)('planning'),
    __metadata("design:paramtypes", [production_planning_extensions_service_1.ProductionPlanningExtensionsService])
], OperationSelectionController);
//# sourceMappingURL=operation-selection.controller.js.map