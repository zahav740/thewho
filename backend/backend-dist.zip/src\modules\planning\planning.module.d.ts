export declare class PlanningModule {
}
