"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlanningModule = void 0;
const common_1 = require("@nestjs/common");
const production_planning_service_1 = require("./production-planning.service");
const production_planning_controller_1 = require("./production-planning.controller");
const production_planning_extensions_service_1 = require("./production-planning-extensions.service");
const operation_selection_controller_1 = require("./operation-selection.controller");
const synchronization_module_1 = require("../synchronization/synchronization.module");
const production_planning_improved_service_1 = require("./production-planning-improved.service");
const production_planning_improved_controller_1 = require("./production-planning-improved.controller");
let PlanningModule = class PlanningModule {
};
exports.PlanningModule = PlanningModule;
exports.PlanningModule = PlanningModule = __decorate([
    (0, common_1.Module)({
        imports: [
            synchronization_module_1.SynchronizationModule,
        ],
        providers: [
            production_planning_service_1.ProductionPlanningService,
            production_planning_extensions_service_1.ProductionPlanningExtensionsService,
            production_planning_improved_service_1.ProductionPlanningImprovedService
        ],
        controllers: [
            production_planning_controller_1.ProductionPlanningController,
            operation_selection_controller_1.OperationSelectionController,
            production_planning_improved_controller_1.ProductionPlanningImprovedController
        ],
        exports: [
            production_planning_service_1.ProductionPlanningService,
            production_planning_extensions_service_1.ProductionPlanningExtensionsService,
            production_planning_improved_service_1.ProductionPlanningImprovedService
        ],
    })
], PlanningModule);
//# sourceMappingURL=planning.module.js.map