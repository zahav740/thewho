import { DataSource } from 'typeorm';
import { OrderWithPriority, OperationData, MachineAvailability, PlanningResult } from './production-planning.service';
export declare class ProductionPlanningExtensionsService {
    private readonly dataSource;
    private readonly logger;
    constructor(dataSource: DataSource);
    getAvailableOperations(selectedMachineIds?: number[]): Promise<{
        orders: OrderWithPriority[];
        availableOperations: (OperationData & {
            orderInfo: OrderWithPriority;
            compatibleMachines: MachineAvailability[];
            canStart: boolean;
            blockingReason?: string;
        })[];
        totalOperations: number;
    }>;
    planWithSelectedOperations(request: {
        selectedMachines: number[];
        selectedOperations: {
            operationId: number;
            machineId: number;
        }[];
    }): Promise<PlanningResult>;
    private getOrdersWithPriorities;
    private getAvailableMachines;
    private getAvailableOperationsForOrders;
    private isOperationInProgress;
    private calculateTimelines;
    private saveResults;
}
