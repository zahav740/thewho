import { ProductionPlanningImprovedService, PlanningRequest, PlanningResult } from './production-planning-improved.service';
export declare class ProductionPlanningImprovedController {
    private readonly planningService;
    private readonly logger;
    constructor(planningService: ProductionPlanningImprovedService);
    planProductionImproved(request: PlanningRequest): Promise<any>;
    demoImprovedPlanning(): Promise<{
        success: boolean;
        error: string;
        suggestion: string;
        analysis: {
            availableMachines: number;
            activeMachines: number;
            occupiedMachines: number;
        };
        message?: undefined;
        result?: undefined;
        machinesUsed?: undefined;
    } | {
        success: boolean;
        message: string;
        result: {
            selectedOrdersCount: number;
            operationsQueueLength: number;
            totalTime: number;
            totalTimeFormatted: string;
            calculationDate: Date;
            hasWarnings: boolean;
            warnings: string[];
            details: PlanningResult;
        };
        machinesUsed: {
            total: any;
            machineIds: any;
            machineDetails: any;
        };
        error?: undefined;
        suggestion?: undefined;
        analysis?: undefined;
    } | {
        success: boolean;
        error: string;
        message: any;
        suggestion: string;
        analysis?: undefined;
        result?: undefined;
        machinesUsed?: undefined;
    }>;
    getSystemAnalysis(): Promise<{
        success: boolean;
        timestamp: Date;
        analysis: {
            machines: {
                total: number;
                active: number;
                available: number;
                occupied: number;
                byType: any;
            };
            operations: {
                total: number;
                inProgress: number;
                byStatus: any;
            };
            orders: {
                total: number;
                withPriorities: number;
                byPriority: any;
            };
            recommendations: any[];
        };
        error?: undefined;
        message?: undefined;
    } | {
        success: boolean;
        error: string;
        message: any;
        timestamp?: undefined;
        analysis?: undefined;
    }>;
    private getAvailableMachinesFromDB;
    private getActiveMachinesCount;
    private getOccupiedMachinesCount;
    private getMachinesAnalysis;
    private getOperationsAnalysis;
    private getOrdersAnalysis;
    private getRecommendations;
    private groupOperationsByType;
    private groupOperationsByPriority;
    private formatTime;
}
