"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var ProductionPlanningImprovedController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductionPlanningImprovedController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const production_planning_improved_service_1 = require("./production-planning-improved.service");
let ProductionPlanningImprovedController = ProductionPlanningImprovedController_1 = class ProductionPlanningImprovedController {
    constructor(planningService) {
        this.planningService = planningService;
        this.logger = new common_1.Logger(ProductionPlanningImprovedController_1.name);
    }
    async planProductionImproved(request) {
        try {
            this.logger.log('🚀 УЛУЧШЕННОЕ ПЛАНИРОВАНИЕ: Получен запрос');
            this.logger.log(`Выбранные станки: ${request.selectedMachines.join(', ')}`);
            const result = await this.planningService.planProduction(request);
            const response = {
                success: true,
                message: 'Улучшенное планирование выполнено успешно',
                result: {
                    selectedOrdersCount: result.selectedOrders.length,
                    operationsQueueLength: result.operationsQueue.length,
                    totalTime: result.totalTime,
                    totalTimeFormatted: this.formatTime(result.totalTime),
                    calculationDate: result.calculationDate,
                    hasWarnings: result.warnings && result.warnings.length > 0,
                    warnings: result.warnings || [],
                    details: result
                },
                analysis: {
                    availableOperations: result.operationsQueue.length,
                    totalEstimatedTime: result.totalTime,
                    operationsByType: this.groupOperationsByType(result.operationsQueue),
                    operationsByPriority: this.groupOperationsByPriority(result.operationsQueue, result.selectedOrders)
                }
            };
            this.logger.log('✅ УЛУЧШЕННОЕ ПЛАНИРОВАНИЕ: Завершено успешно');
            return response;
        }
        catch (error) {
            this.logger.error('❌ Ошибка при улучшенном планировании:', error);
            return {
                success: false,
                error: 'Ошибка при выполнении улучшенного планирования',
                message: error.message,
                suggestion: 'Проверьте доступность станков и операций в БД'
            };
        }
    }
    async demoImprovedPlanning() {
        try {
            this.logger.log('🎯 ДЕМО УЛУЧШЕННОГО ПЛАНИРОВАНИЯ: Запуск');
            const availableMachines = await this.getAvailableMachinesFromDB();
            const machineIds = availableMachines.map(m => m.id);
            if (machineIds.length === 0) {
                return {
                    success: false,
                    error: 'Нет доступных станков для демо планирования',
                    suggestion: 'Убедитесь что в БД есть активные и свободные станки (isActive=true, isOccupied=false)',
                    analysis: {
                        availableMachines: 0,
                        activeMachines: await this.getActiveMachinesCount(),
                        occupiedMachines: await this.getOccupiedMachinesCount()
                    }
                };
            }
            this.logger.log(`Используем ${machineIds.length} доступных станков: ${machineIds.join(', ')}`);
            const planningRequest = {
                selectedMachines: machineIds
            };
            const result = await this.planningService.planProduction(planningRequest);
            return {
                success: true,
                message: `Демо улучшенного планирования выполнено с ${machineIds.length} станками`,
                result: {
                    selectedOrdersCount: result.selectedOrders.length,
                    operationsQueueLength: result.operationsQueue.length,
                    totalTime: result.totalTime,
                    totalTimeFormatted: this.formatTime(result.totalTime),
                    calculationDate: result.calculationDate,
                    hasWarnings: result.warnings && result.warnings.length > 0,
                    warnings: result.warnings || [],
                    details: result
                },
                machinesUsed: {
                    total: machineIds.length,
                    machineIds: machineIds,
                    machineDetails: availableMachines.map(m => ({
                        id: m.id,
                        code: m.code,
                        type: m.type,
                        axes: m.axes
                    }))
                }
            };
        }
        catch (error) {
            this.logger.error('❌ Ошибка при демо планировании:', error);
            return {
                success: false,
                error: 'Ошибка при выполнении демо планирования',
                message: error.message,
                suggestion: 'Проверьте что в БД есть заказы с приоритетами 1, 2, 3 и соответствующие операции'
            };
        }
    }
    async getSystemAnalysis() {
        try {
            this.logger.log('📊 Выполнение анализа состояния системы');
            const analysis = {
                machines: await this.getMachinesAnalysis(),
                operations: await this.getOperationsAnalysis(),
                orders: await this.getOrdersAnalysis(),
                recommendations: await this.getRecommendations()
            };
            return {
                success: true,
                timestamp: new Date(),
                analysis
            };
        }
        catch (error) {
            this.logger.error('❌ Ошибка при анализе системы:', error);
            return {
                success: false,
                error: 'Ошибка при анализе системы',
                message: error.message
            };
        }
    }
    async getAvailableMachinesFromDB() {
        return await this.planningService['dataSource'].query(`
      SELECT id, code, type, axes, "isActive", "isOccupied"
      FROM machines 
      WHERE "isActive" = true AND "isOccupied" = false
      ORDER BY type, code
    `);
    }
    async getActiveMachinesCount() {
        const result = await this.planningService['dataSource'].query(`
      SELECT COUNT(*) as count FROM machines WHERE "isActive" = true
    `);
        return parseInt(result[0].count);
    }
    async getOccupiedMachinesCount() {
        const result = await this.planningService['dataSource'].query(`
      SELECT COUNT(*) as count FROM machines WHERE "isOccupied" = true
    `);
        return parseInt(result[0].count);
    }
    async getMachinesAnalysis() {
        const total = await this.planningService['dataSource'].query(`
      SELECT COUNT(*) as count FROM machines
    `);
        const active = await this.planningService['dataSource'].query(`
      SELECT COUNT(*) as count FROM machines WHERE "isActive" = true
    `);
        const available = await this.planningService['dataSource'].query(`
      SELECT COUNT(*) as count FROM machines WHERE "isActive" = true AND "isOccupied" = false
    `);
        const byType = await this.planningService['dataSource'].query(`
      SELECT type, COUNT(*) as count 
      FROM machines 
      WHERE "isActive" = true 
      GROUP BY type
    `);
        return {
            total: parseInt(total[0].count),
            active: parseInt(active[0].count),
            available: parseInt(available[0].count),
            occupied: parseInt(active[0].count) - parseInt(available[0].count),
            byType: byType.reduce((acc, item) => {
                acc[item.type] = parseInt(item.count);
                return acc;
            }, {})
        };
    }
    async getOperationsAnalysis() {
        const total = await this.planningService['dataSource'].query(`
      SELECT COUNT(*) as count FROM operations
    `);
        const byStatus = await this.planningService['dataSource'].query(`
      SELECT 
        COALESCE(status, 'PENDING') as status, 
        COUNT(*) as count 
      FROM operations 
      GROUP BY status
    `);
        const inProgress = await this.planningService['dataSource'].query(`
      SELECT COUNT(*) as count 
      FROM operations 
      WHERE status = 'IN_PROGRESS' OR id IN (
        SELECT "currentOperation" FROM machines WHERE "currentOperation" IS NOT NULL
      )
    `);
        return {
            total: parseInt(total[0].count),
            inProgress: parseInt(inProgress[0].count),
            byStatus: byStatus.reduce((acc, item) => {
                acc[item.status || 'PENDING'] = parseInt(item.count);
                return acc;
            }, {})
        };
    }
    async getOrdersAnalysis() {
        const total = await this.planningService['dataSource'].query(`
      SELECT COUNT(*) as count FROM orders
    `);
        const withPriorities = await this.planningService['dataSource'].query(`
      SELECT COUNT(*) as count FROM orders WHERE priority IN (1, 2, 3)
    `);
        const byPriority = await this.planningService['dataSource'].query(`
      SELECT priority, COUNT(*) as count 
      FROM orders 
      WHERE priority IN (1, 2, 3)
      GROUP BY priority
      ORDER BY priority
    `);
        return {
            total: parseInt(total[0].count),
            withPriorities: parseInt(withPriorities[0].count),
            byPriority: byPriority.reduce((acc, item) => {
                acc[`priority_${item.priority}`] = parseInt(item.count);
                return acc;
            }, {})
        };
    }
    async getRecommendations() {
        const recommendations = [];
        const availableMachines = await this.getAvailableMachinesFromDB();
        if (availableMachines.length === 0) {
            recommendations.push({
                type: 'warning',
                message: 'Нет доступных станков для планирования',
                action: 'Освободите станки или проверьте их статус в системе'
            });
        }
        const ordersWithPriorities = await this.planningService['dataSource'].query(`
      SELECT COUNT(*) as count FROM orders WHERE priority IN (1, 2, 3)
    `);
        if (parseInt(ordersWithPriorities[0].count) === 0) {
            recommendations.push({
                type: 'error',
                message: 'Нет заказов с приоритетами 1, 2, 3',
                action: 'Добавьте заказы с соответствующими приоритетами в систему'
            });
        }
        const operationsInProgress = await this.planningService['dataSource'].query(`
      SELECT COUNT(*) as count FROM operations WHERE status = 'IN_PROGRESS'
    `);
        if (parseInt(operationsInProgress[0].count) > 0) {
            recommendations.push({
                type: 'info',
                message: `${operationsInProgress[0].count} операций в процессе выполнения`,
                action: 'Система корректно учитывает эти операции при планировании'
            });
        }
        return recommendations;
    }
    groupOperationsByType(operations) {
        return operations.reduce((acc, op) => {
            acc[op.operationType] = (acc[op.operationType] || 0) + 1;
            return acc;
        }, {});
    }
    groupOperationsByPriority(operations, orders) {
        return operations.reduce((acc, op) => {
            const order = orders.find(o => o.id === op.orderId);
            if (order) {
                const priority = `priority_${order.priority}`;
                acc[priority] = (acc[priority] || 0) + 1;
            }
            return acc;
        }, {});
    }
    formatTime(minutes) {
        if (!minutes || minutes <= 0)
            return '0 мин';
        const hours = Math.floor(minutes / 60);
        const remainingMinutes = minutes % 60;
        if (hours === 0) {
            return `${remainingMinutes} мин`;
        }
        else if (remainingMinutes === 0) {
            return `${hours} ч`;
        }
        else {
            return `${hours} ч ${remainingMinutes} мин`;
        }
    }
};
exports.ProductionPlanningImprovedController = ProductionPlanningImprovedController;
__decorate([
    (0, common_1.Post)('plan'),
    (0, swagger_1.ApiOperation)({
        summary: '🚀 УЛУЧШЕННОЕ планирование производства',
        description: 'Реализует улучшенный алгоритм с правильным учетом операций в работе'
    }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Планирование выполнено успешно' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Ошибка в данных запроса' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ProductionPlanningImprovedController.prototype, "planProductionImproved", null);
__decorate([
    (0, common_1.Post)('demo'),
    (0, swagger_1.ApiOperation)({
        summary: '🎯 ДЕМО улучшенного планирования',
        description: 'Запускает улучшенное планирование со всеми доступными станками'
    }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ProductionPlanningImprovedController.prototype, "demoImprovedPlanning", null);
__decorate([
    (0, common_1.Get)('analysis'),
    (0, swagger_1.ApiOperation)({
        summary: '📊 Анализ состояния системы',
        description: 'Предоставляет детальный анализ доступности операций и станков'
    }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ProductionPlanningImprovedController.prototype, "getSystemAnalysis", null);
exports.ProductionPlanningImprovedController = ProductionPlanningImprovedController = ProductionPlanningImprovedController_1 = __decorate([
    (0, swagger_1.ApiTags)('planning-improved'),
    (0, common_1.Controller)('planning-improved'),
    __metadata("design:paramtypes", [production_planning_improved_service_1.ProductionPlanningImprovedService])
], ProductionPlanningImprovedController);
//# sourceMappingURL=production-planning-improved.controller.js.map