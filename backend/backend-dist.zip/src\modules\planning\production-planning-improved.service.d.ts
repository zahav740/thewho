import { DataSource } from 'typeorm';
export interface OrderWithPriority {
    id: number;
    drawingNumber: string;
    priority: number;
    quantity: number;
    deadline: Date;
    workType: string;
}
export interface OperationData {
    id: number;
    orderId: number;
    operationNumber: number;
    operationType: string;
    estimatedTime: number;
    machineAxes: number;
    status?: string;
}
export interface MachineAvailability {
    id: number;
    code: string;
    type: string;
    axes: number;
    isActive: boolean;
    isOccupied: boolean;
    currentOperation?: number;
}
export interface PlanningRequest {
    selectedMachines: number[];
    excelData?: any;
}
export interface PlanningResult {
    selectedOrders: OrderWithPriority[];
    operationsQueue: {
        orderId: number;
        operationId: number;
        operationNumber: number;
        operationType: string;
        machineId: number;
        machineAxes: number;
        priority: number;
        estimatedTime: number;
        startTime?: Date;
        endTime?: Date;
    }[];
    totalTime: number;
    calculationDate: Date;
    warnings?: string[];
}
export interface OperationAvailabilityCheck {
    operation: OperationData;
    isAvailable: boolean;
    reason?: string;
    compatibleMachines: MachineAvailability[];
    availableMachines: MachineAvailability[];
}
export declare class ProductionPlanningImprovedService {
    private readonly dataSource;
    private readonly logger;
    constructor(dataSource: DataSource);
    planProduction(request: PlanningRequest): Promise<PlanningResult>;
    private getDetailedOperationAvailability;
    private checkOperationAvailability;
    private getCompatibleMachines;
    private isOperationCompatibleWithMachine;
    private isOperationCurrentlyInProgress;
    private findNextAvailableOperation;
    private getAllOperationsForOrder;
    private buildSmartQueue;
    private findBestMachineForOperation;
    private logAvailabilityAnalysis;
    private createEmptyResult;
    private getOrdersWithPriorities;
    private selectOrdersWithDifferentPriorities;
    private calculateTimelines;
    private saveResults;
}
