"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var ProductionPlanningImprovedService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductionPlanningImprovedService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
let ProductionPlanningImprovedService = ProductionPlanningImprovedService_1 = class ProductionPlanningImprovedService {
    constructor(dataSource) {
        this.dataSource = dataSource;
        this.logger = new common_1.Logger(ProductionPlanningImprovedService_1.name);
    }
    async planProduction(request) {
        this.logger.log('🚀 УЛУЧШЕННОЕ ПЛАНИРОВАНИЕ: Начинаем анализ');
        try {
            const orders = await this.getOrdersWithPriorities();
            const selectedOrders = await this.selectOrdersWithDifferentPriorities(orders);
            const availabilityChecks = await this.getDetailedOperationAvailability(selectedOrders, request.selectedMachines);
            const availableOperations = availabilityChecks
                .filter(check => check.isAvailable)
                .map(check => check.operation);
            this.logAvailabilityAnalysis(availabilityChecks);
            if (availableOperations.length === 0) {
                this.logger.warn('❌ НЕТ ДОСТУПНЫХ ОПЕРАЦИЙ для планирования!');
                return this.createEmptyResult(selectedOrders, availabilityChecks);
            }
            const operationsQueue = await this.buildSmartQueue(availableOperations, selectedOrders, request.selectedMachines);
            const result = this.calculateTimelines(operationsQueue, selectedOrders);
            await this.saveResults(result);
            this.logger.log('✅ УЛУЧШЕННОЕ ПЛАНИРОВАНИЕ: Завершено успешно');
            return result;
        }
        catch (error) {
            this.logger.error('❌ Ошибка при улучшенном планировании:', error);
            throw error;
        }
    }
    async getDetailedOperationAvailability(orders, selectedMachineIds) {
        this.logger.log('🔍 АНАЛИЗ ДОСТУПНОСТИ: Начинаем детальную проверку операций');
        const checks = [];
        for (const order of orders) {
            this.logger.log(`\n📋 Анализируем заказ ID:${order.id} (${order.drawingNumber})`);
            const allOperations = await this.getAllOperationsForOrder(order.id);
            const nextOperation = await this.findNextAvailableOperation(allOperations);
            if (nextOperation) {
                this.logger.log(`🎯 Найдена кандидат-операция: ${nextOperation.operationNumber} (${nextOperation.operationType})`);
                const availabilityCheck = await this.checkOperationAvailability(nextOperation, selectedMachineIds);
                checks.push(availabilityCheck);
                this.logger.log(`${availabilityCheck.isAvailable ? '✅' : '❌'} Операция ${nextOperation.operationNumber}: ${availabilityCheck.reason || 'доступна'}`);
            }
            else {
                this.logger.warn(`⚠️ Нет доступных операций для заказа ${order.drawingNumber}`);
            }
        }
        return checks;
    }
    async checkOperationAvailability(operation, selectedMachineIds) {
        if (operation.status === 'IN_PROGRESS') {
            return {
                operation,
                isAvailable: false,
                reason: 'Операция уже выполняется',
                compatibleMachines: [],
                availableMachines: []
            };
        }
        if (operation.status === 'COMPLETED') {
            return {
                operation,
                isAvailable: false,
                reason: 'Операция уже завершена',
                compatibleMachines: [],
                availableMachines: []
            };
        }
        const isInProgress = await this.isOperationCurrentlyInProgress(operation.id);
        if (isInProgress) {
            return {
                operation,
                isAvailable: false,
                reason: 'Операция выполняется на другом станке',
                compatibleMachines: [],
                availableMachines: []
            };
        }
        const compatibleMachines = await this.getCompatibleMachines(operation, selectedMachineIds);
        if (compatibleMachines.length === 0) {
            return {
                operation,
                isAvailable: false,
                reason: `Нет совместимых станков для операции ${operation.operationType}`,
                compatibleMachines: [],
                availableMachines: []
            };
        }
        const availableMachines = compatibleMachines.filter(machine => !machine.isOccupied);
        if (availableMachines.length === 0) {
            return {
                operation,
                isAvailable: false,
                reason: `Все совместимые станки заняты (${compatibleMachines.length} станков)`,
                compatibleMachines,
                availableMachines: []
            };
        }
        return {
            operation,
            isAvailable: true,
            reason: `Доступно ${availableMachines.length} станков`,
            compatibleMachines,
            availableMachines
        };
    }
    async getCompatibleMachines(operation, selectedMachineIds) {
        let query = `
      SELECT 
        id, code, type, axes, "isActive", "isOccupied", "currentOperation"
      FROM machines 
      WHERE "isActive" = true
    `;
        let params = [];
        if (selectedMachineIds && selectedMachineIds.length > 0) {
            query += ' AND id = ANY($1)';
            params = [selectedMachineIds];
        }
        const allMachines = await this.dataSource.query(query, params);
        const compatibleMachines = allMachines.filter(machine => {
            return this.isOperationCompatibleWithMachine(operation, machine);
        });
        return compatibleMachines;
    }
    isOperationCompatibleWithMachine(operation, machine) {
        const opType = operation.operationType?.toUpperCase();
        const machineType = machine.type?.toUpperCase();
        switch (opType) {
            case 'TURNING':
                return machineType === 'TURNING';
            case 'MILLING':
                if (operation.machineAxes === 4) {
                    return machineType === 'MILLING' && machine.axes >= 4;
                }
                else {
                    return machineType === 'MILLING';
                }
            default:
                this.logger.warn(`Неподдерживаемый тип операции: ${opType}. Поддерживаются только: TURNING, MILLING (3-осевая), MILLING (4-осевая)`);
                return false;
        }
    }
    async isOperationCurrentlyInProgress(operationId) {
        const result = await this.dataSource.query(`
      SELECT COUNT(*) as count 
      FROM machines 
      WHERE "currentOperation" = $1 AND "isOccupied" = true
    `, [operationId]);
        return parseInt(result[0].count) > 0;
    }
    async findNextAvailableOperation(operations) {
        if (!operations || operations.length === 0) {
            return null;
        }
        const sortedOperations = operations.sort((a, b) => a.operationNumber - b.operationNumber);
        for (const operation of sortedOperations) {
            if (operation.status === 'COMPLETED') {
                continue;
            }
            if (operation.operationNumber === 1) {
                return operation;
            }
            const prevOperation = sortedOperations.find(op => op.operationNumber === operation.operationNumber - 1);
            if (!prevOperation) {
                this.logger.log(`✅ Операция ${operation.operationNumber} доступна (нет предыдущей операции ${operation.operationNumber - 1})`);
                return operation;
            }
            if (prevOperation.status === 'COMPLETED') {
                return operation;
            }
            if (prevOperation.status !== 'COMPLETED') {
                this.logger.log(`❌ Операция ${operation.operationNumber} недоступна (операция ${prevOperation.operationNumber} не завершена: ${prevOperation.status})`);
                break;
            }
        }
        return null;
    }
    async getAllOperationsForOrder(orderId) {
        const operations = await this.dataSource.query(`
      SELECT 
        id,
        "orderId",
        "operationNumber",
        operationtype as "operationType",
        "estimatedTime",
        machineaxes as "machineAxes",
        status,
        "assignedMachine",
        "assignedAt"
      FROM operations 
      WHERE "orderId" = $1
      ORDER BY "operationNumber" ASC
    `, [orderId]);
        return operations;
    }
    async buildSmartQueue(operations, orders, selectedMachineIds) {
        this.logger.log('🏗️ Строим умную очередь операций');
        const queue = [];
        for (const operation of operations) {
            const order = orders.find(o => o.id === operation.orderId);
            if (!order)
                continue;
            const bestMachine = await this.findBestMachineForOperation(operation, selectedMachineIds);
            if (bestMachine) {
                queue.push({
                    orderId: operation.orderId,
                    operationId: operation.id,
                    operationNumber: operation.operationNumber,
                    operationType: operation.operationType,
                    machineId: bestMachine.id,
                    machineAxes: operation.machineAxes,
                    priority: order.priority,
                    estimatedTime: operation.estimatedTime
                });
            }
        }
        queue.sort((a, b) => a.priority - b.priority);
        this.logger.log(`✅ Построена очередь из ${queue.length} операций`);
        return queue;
    }
    async findBestMachineForOperation(operation, selectedMachineIds) {
        const compatibleMachines = await this.getCompatibleMachines(operation, selectedMachineIds);
        const availableMachines = compatibleMachines.filter(m => !m.isOccupied);
        if (availableMachines.length === 0) {
            return null;
        }
        return availableMachines[0];
    }
    logAvailabilityAnalysis(checks) {
        this.logger.log('\n📊 РЕЗУЛЬТАТЫ АНАЛИЗА ДОСТУПНОСТИ:');
        this.logger.log('='.repeat(60));
        const available = checks.filter(c => c.isAvailable);
        const unavailable = checks.filter(c => !c.isAvailable);
        this.logger.log(`✅ Доступных операций: ${available.length}`);
        this.logger.log(`❌ Недоступных операций: ${unavailable.length}`);
        if (available.length > 0) {
            this.logger.log('\n🎯 ДОСТУПНЫЕ ОПЕРАЦИИ:');
            available.forEach(check => {
                this.logger.log(`  - Операция ${check.operation.operationNumber} (${check.operation.operationType}): ${check.reason}`);
            });
        }
        if (unavailable.length > 0) {
            this.logger.log('\n⚠️ НЕДОСТУПНЫЕ ОПЕРАЦИИ:');
            unavailable.forEach(check => {
                this.logger.log(`  - Операция ${check.operation.operationNumber} (${check.operation.operationType}): ${check.reason}`);
            });
        }
        this.logger.log('='.repeat(60));
    }
    createEmptyResult(orders, checks) {
        const warnings = [
            'Нет доступных операций для планирования',
            ...checks.filter(c => !c.isAvailable).map(c => `${c.operation.operationType} ${c.operation.operationNumber}: ${c.reason}`)
        ];
        return {
            selectedOrders: orders,
            operationsQueue: [],
            totalTime: 0,
            calculationDate: new Date(),
            warnings
        };
    }
    async getOrdersWithPriorities() {
        this.logger.log('📋 Загрузка заказов с приоритетами');
        const orders = await this.dataSource.query(`
      SELECT 
        id,
        drawing_number as "drawingNumber",
        priority,
        quantity,
        deadline,
        "workType"
      FROM orders 
      WHERE priority IN (1, 2, 3)
      ORDER BY priority ASC, deadline ASC
    `);
        this.logger.log(`Найдено ${orders.length} заказов с приоритетами`);
        return orders;
    }
    async selectOrdersWithDifferentPriorities(orders) {
        this.logger.log('🎯 ИСПРАВЛЕНО: Выбор ВСЕХ заказов с приоритетами для более широкого планирования');
        const selectedOrders = orders.filter(order => order.priority >= 1 && order.priority <= 3);
        if (selectedOrders.length === 0) {
            throw new common_1.NotFoundException('Не найдено ни одного заказа с приоритетами 1, 2 или 3');
        }
        selectedOrders.sort((a, b) => {
            if (a.priority !== b.priority) {
                return a.priority - b.priority;
            }
            return new Date(a.deadline).getTime() - new Date(b.deadline).getTime();
        });
        const priorityStats = selectedOrders.reduce((stats, order) => {
            stats[order.priority] = (stats[order.priority] || 0) + 1;
            return stats;
        }, {});
        this.logger.log(`Выбрано ${selectedOrders.length} заказов:`);
        this.logger.log(`  - Приоритет 1: ${priorityStats[1] || 0} заказов`);
        this.logger.log(`  - Приоритет 2: ${priorityStats[2] || 0} заказов`);
        this.logger.log(`  - Приоритет 3: ${priorityStats[3] || 0} заказов`);
        return selectedOrders;
    }
    calculateTimelines(queue, orders) {
        this.logger.log('⏱️ Расчет временных рамок');
        let currentTime = new Date();
        let totalTime = 0;
        const operationsQueue = queue.map(queueItem => {
            const startTime = new Date(currentTime);
            const endTime = new Date(currentTime.getTime() + queueItem.estimatedTime * 60000);
            totalTime += queueItem.estimatedTime;
            currentTime = endTime;
            return {
                ...queueItem,
                startTime,
                endTime
            };
        });
        return {
            selectedOrders: orders,
            operationsQueue,
            totalTime,
            calculationDate: new Date()
        };
    }
    async saveResults(result) {
        this.logger.log('💾 Сохранение результатов планирования');
        try {
            await this.dataSource.query(`
        INSERT INTO planning_results (
          calculation_date,
          selected_orders,
          selected_machines,
          queue_plan,
          total_time
        ) VALUES ($1, $2, $3, $4, $5)
      `, [
                result.calculationDate,
                JSON.stringify(result.selectedOrders),
                JSON.stringify(result.operationsQueue.map(op => op.machineId)),
                JSON.stringify(result.operationsQueue),
                result.totalTime
            ]);
            this.logger.log('✅ Результаты сохранены успешно');
        }
        catch (error) {
            this.logger.error('❌ Ошибка при сохранении результатов:', error);
            throw error;
        }
    }
};
exports.ProductionPlanningImprovedService = ProductionPlanningImprovedService;
exports.ProductionPlanningImprovedService = ProductionPlanningImprovedService = ProductionPlanningImprovedService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectDataSource)()),
    __metadata("design:paramtypes", [typeorm_2.DataSource])
], ProductionPlanningImprovedService);
//# sourceMappingURL=production-planning-improved.service.js.map