import { ProductionPlanningService, PlanningRequest, PlanningResult } from './production-planning.service';
import { SynchronizationService } from '../synchronization/synchronization.service';
export declare class ProductionPlanningController {
    private readonly planningService;
    private readonly syncService;
    private readonly logger;
    constructor(planningService: ProductionPlanningService, syncService: SynchronizationService);
    planProduction(request: PlanningRequest): Promise<PlanningResult>;
    getLatestResults(): Promise<{
        message: string;
        hasResults: boolean;
        data?: undefined;
    } | {
        hasResults: boolean;
        data: {
            id: any;
            calculationDate: any;
            selectedOrders: any;
            selectedMachines: any;
            queuePlan: any;
            totalTime: any;
            totalTimeFormatted: string;
        };
        message?: undefined;
    }>;
    getOperationProgress(orderIds?: string): Promise<{
        count: number;
        data: {
            id: any;
            orderId: any;
            calculationDate: any;
            deadline: any;
            quantity: any;
            totalProductionTime: any;
            totalProductionTimeFormatted: string;
            operations: any;
        }[];
    }>;
    demoPlanning(): Promise<{
        success: boolean;
        error: string;
        suggestion: string;
        message?: undefined;
        result?: undefined;
    } | {
        success: boolean;
        message: string;
        result: {
            selectedOrdersCount: number;
            operationsQueueLength: number;
            totalTime: number;
            totalTimeFormatted: string;
            calculationDate: Date;
            details: PlanningResult;
        };
        error?: undefined;
        suggestion?: undefined;
    } | {
        success: boolean;
        error: string;
        message: any;
        suggestion: string;
        result?: undefined;
    }>;
    assignOperation(request: {
        operationId: number;
        machineId: number;
    }): Promise<{
        success: boolean;
        error: string;
        message?: undefined;
        data?: undefined;
    } | {
        success: boolean;
        message: string;
        data: {
            operationId: number;
            machineId: number;
            assignedAt: Date;
            syncedWithShifts: boolean;
            synchronizationStatus: import("../synchronization/synchronization.service").SynchronizationStatus;
        };
        error?: undefined;
    } | {
        success: boolean;
        error: string;
        message: any;
        data?: undefined;
    }>;
    getSyncStatus(operationId: string): Promise<{
        success: boolean;
        operationId: number;
        status: import("../synchronization/synchronization.service").SynchronizationStatus;
        timestamp: Date;
        error?: undefined;
    } | {
        success: boolean;
        error: any;
        operationId?: undefined;
        status?: undefined;
        timestamp?: undefined;
    }>;
    assignOperationLegacy(request: {
        operationId: number;
        machineId: number;
    }): Promise<{
        success: boolean;
        error: string;
        message?: undefined;
        warning?: undefined;
        data?: undefined;
    } | {
        success: boolean;
        message: string;
        warning: string;
        data: {
            operationId: number;
            machineId: number;
            machineName: any;
            assignedAt: Date;
            syncedWithShifts: boolean;
        };
        error?: undefined;
    } | {
        success: boolean;
        error: string;
        message: any;
        warning?: undefined;
        data?: undefined;
    }>;
    private getMachineTypeFromCode;
    private formatTime;
}
