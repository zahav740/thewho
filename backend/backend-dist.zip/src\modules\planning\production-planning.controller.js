"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var ProductionPlanningController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductionPlanningController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const production_planning_service_1 = require("./production-planning.service");
const synchronization_service_1 = require("../synchronization/synchronization.service");
let ProductionPlanningController = ProductionPlanningController_1 = class ProductionPlanningController {
    constructor(planningService, syncService) {
        this.planningService = planningService;
        this.syncService = syncService;
        this.logger = new common_1.Logger(ProductionPlanningController_1.name);
    }
    async planProduction(request) {
        try {
            this.logger.log('Получен запрос на планирование производства');
            this.logger.log(`Выбранные станки: ${request.selectedMachines.join(', ')}`);
            const result = await this.planningService.planProduction(request);
            this.logger.log('Планирование завершено успешно');
            return result;
        }
        catch (error) {
            this.logger.error('Ошибка при планировании:', error);
            throw error;
        }
    }
    async getLatestResults() {
        try {
            this.logger.log('Запрос последних результатов планирования');
            const results = await this.planningService.getLatestPlanningResults();
            if (!results) {
                return {
                    message: 'Результаты планирования не найдены',
                    hasResults: false
                };
            }
            return {
                hasResults: true,
                data: {
                    id: results.id,
                    calculationDate: results.calculation_date,
                    selectedOrders: results.selected_orders,
                    selectedMachines: results.selected_machines,
                    queuePlan: results.queue_plan,
                    totalTime: results.total_time,
                    totalTimeFormatted: this.formatTime(results.total_time)
                }
            };
        }
        catch (error) {
            this.logger.error('Ошибка при получении результатов:', error);
            throw error;
        }
    }
    async getOperationProgress(orderIds) {
        try {
            this.logger.log('Запрос прогресса операций');
            let orderIdArray;
            if (orderIds) {
                orderIdArray = orderIds.split(',').map(id => parseInt(id.trim(), 10)).filter(id => !isNaN(id));
            }
            const progress = await this.planningService.getOperationProgress(orderIdArray);
            return {
                count: progress.length,
                data: progress.map(p => ({
                    id: p.id,
                    orderId: p.order_id,
                    calculationDate: p.calculation_date,
                    deadline: p.deadline,
                    quantity: p.quantity,
                    totalProductionTime: p.total_production_time,
                    totalProductionTimeFormatted: this.formatTime(p.total_production_time),
                    operations: p.operations
                }))
            };
        }
        catch (error) {
            this.logger.error('Ошибка при получении прогресса:', error);
            throw error;
        }
    }
    async demoPlanning() {
        try {
            this.logger.log('Запуск планирования с доступными станками');
            const availableMachines = await this.planningService['getAvailableMachines']([]);
            const machineIds = availableMachines.map(m => m.id);
            if (machineIds.length === 0) {
                return {
                    success: false,
                    error: 'Нет доступных станков для планирования',
                    suggestion: 'Убедитесь что в БД есть активные и свободные станки (isActive=true, isOccupied=false)'
                };
            }
            this.logger.log(`Используем ${machineIds.length} доступных станков: ${machineIds.join(', ')}`);
            const planningRequest = {
                selectedMachines: machineIds
            };
            const result = await this.planningService.planProduction(planningRequest);
            return {
                success: true,
                message: `Планирование выполнено с ${machineIds.length} станками`,
                result: {
                    selectedOrdersCount: result.selectedOrders.length,
                    operationsQueueLength: result.operationsQueue.length,
                    totalTime: result.totalTime,
                    totalTimeFormatted: this.formatTime(result.totalTime),
                    calculationDate: result.calculationDate,
                    details: result
                }
            };
        }
        catch (error) {
            this.logger.error('Ошибка при планировании:', error);
            return {
                success: false,
                error: 'Ошибка при выполнении планирования',
                message: error.message,
                suggestion: 'Проверьте что в БД есть заказы с приоритетами 1, 2, 3 и соответствующие операции'
            };
        }
    }
    async assignOperation(request) {
        try {
            this.logger.log(`🔗 НОВОЕ назначение операции ${request.operationId} на станок ${request.machineId} с синхронизацией`);
            if (!request.operationId || !request.machineId) {
                return {
                    success: false,
                    error: 'operationId и machineId обязательны'
                };
            }
            const syncResult = await this.syncService.assignOperationWithSync(request.operationId, request.machineId);
            this.logger.log(`✅ Операция успешно назначена и синхронизирована:`);
            this.logger.log(`   - Операция ID: ${request.operationId}`);
            this.logger.log(`   - Станок ID: ${request.machineId}`);
            this.logger.log(`   - Статус синхронизации:`, syncResult);
            return {
                success: true,
                message: `Операция ${request.operationId} назначена и синхронизирована`,
                data: {
                    operationId: request.operationId,
                    machineId: request.machineId,
                    assignedAt: new Date(),
                    syncedWithShifts: true,
                    synchronizationStatus: syncResult
                }
            };
        }
        catch (error) {
            this.logger.error('❌ Ошибка при назначении операции с синхронизацией:', error);
            return {
                success: false,
                error: 'Ошибка при назначении операции',
                message: error.message
            };
        }
    }
    async getSyncStatus(operationId) {
        try {
            const status = await this.syncService.getSynchronizationStatus(Number(operationId));
            return {
                success: true,
                operationId: Number(operationId),
                status,
                timestamp: new Date()
            };
        }
        catch (error) {
            this.logger.error(`Ошибка получения статуса синхронизации операции ${operationId}:`, error);
            return {
                success: false,
                error: error.message
            };
        }
    }
    async assignOperationLegacy(request) {
        try {
            this.logger.log(`⚠️ УСТАРЕВШИЙ метод: назначение операции ${request.operationId} на станок ${request.machineId}`);
            const operation = await this.planningService['dataSource'].query('SELECT * FROM operations WHERE id = $1', [request.operationId]);
            if (!operation || operation.length === 0) {
                return {
                    success: false,
                    error: 'Операция не найдена'
                };
            }
            const machine = await this.planningService['dataSource'].query('SELECT * FROM machines WHERE id = $1 AND "isActive" = true AND "isOccupied" = false', [request.machineId]);
            if (!machine || machine.length === 0) {
                return {
                    success: false,
                    error: 'Станок недоступен или занят'
                };
            }
            const machineName = machine[0].code;
            await this.planningService['dataSource'].query('UPDATE machines SET "isOccupied" = true, "currentOperation" = $1, "assignedAt" = NOW() WHERE id = $2', [request.operationId, request.machineId]);
            await this.planningService['dataSource'].query('UPDATE operations SET "assignedMachine" = $1, "assignedAt" = NOW(), status = \'ASSIGNED\' WHERE id = $2', [request.machineId, request.operationId]);
            return {
                success: true,
                message: `Операция ${operation[0].operationNumber || request.operationId} назначена на станок ${machineName} (БЕЗ синхронизации)`,
                warning: 'Используется устаревший метод без синхронизации со сменами',
                data: {
                    operationId: request.operationId,
                    machineId: request.machineId,
                    machineName: machineName,
                    assignedAt: new Date(),
                    syncedWithShifts: false
                }
            };
        }
        catch (error) {
            this.logger.error('Ошибка при назначении операции (устаревший метод):', error);
            return {
                success: false,
                error: 'Ошибка при назначении операции',
                message: error.message
            };
        }
    }
    getMachineTypeFromCode(machineCode) {
        if (machineCode.startsWith('F')) {
            return 'milling-4axis';
        }
        else if (machineCode.startsWith('T')) {
            return 'turning';
        }
        else {
            return 'milling-3axis';
        }
    }
    formatTime(minutes) {
        if (!minutes || minutes <= 0)
            return '0 мин';
        const hours = Math.floor(minutes / 60);
        const remainingMinutes = minutes % 60;
        if (hours === 0) {
            return `${remainingMinutes} мин`;
        }
        else if (remainingMinutes === 0) {
            return `${hours} ч`;
        }
        else {
            return `${hours} ч ${remainingMinutes} мин`;
        }
    }
};
exports.ProductionPlanningController = ProductionPlanningController;
__decorate([
    (0, common_1.Post)('plan'),
    (0, swagger_1.ApiOperation)({
        summary: 'Запустить планирование производства',
        description: 'Реализует алгоритм выбора операций для 3 заказов с разными приоритетами'
    }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Планирование выполнено успешно' }),
    (0, swagger_1.ApiResponse)({ status: 400, description: 'Ошибка в данных запроса' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ProductionPlanningController.prototype, "planProduction", null);
__decorate([
    (0, common_1.Get)('results/latest'),
    (0, swagger_1.ApiOperation)({
        summary: 'Получить последние результаты планирования',
        description: 'Возвращает последний расчет планирования производства'
    }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ProductionPlanningController.prototype, "getLatestResults", null);
__decorate([
    (0, common_1.Get)('progress'),
    (0, swagger_1.ApiOperation)({
        summary: 'Получить прогресс операций',
        description: 'Возвращает прогресс выполнения операций для заказов'
    }),
    __param(0, (0, common_1.Query)('orderIds')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ProductionPlanningController.prototype, "getOperationProgress", null);
__decorate([
    (0, common_1.Post)('demo'),
    (0, swagger_1.ApiOperation)({
        summary: 'Запуск планирования с доступными станками',
        description: 'Запускает планирование используя все доступные станки из БД'
    }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ProductionPlanningController.prototype, "demoPlanning", null);
__decorate([
    (0, common_1.Post)('assign-operation'),
    (0, swagger_1.ApiOperation)({
        summary: 'Назначить операцию на станок с синхронизацией',
        description: 'Назначает операцию на станок и автоматически создает связанную запись смены'
    }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ProductionPlanningController.prototype, "assignOperation", null);
__decorate([
    (0, common_1.Get)('sync-status/:operationId'),
    (0, swagger_1.ApiOperation)({
        summary: 'Получить статус синхронизации операции',
        description: 'Возвращает статус синхронизации между операцией и сменами'
    }),
    __param(0, (0, common_1.Param)('operationId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ProductionPlanningController.prototype, "getSyncStatus", null);
__decorate([
    (0, common_1.Post)('assign-operation-legacy'),
    (0, swagger_1.ApiOperation)({
        summary: 'Назначить операцию на станок (устаревший метод)',
        description: 'УСТАРЕЛ: Используйте assign-operation для полной синхронизации'
    }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ProductionPlanningController.prototype, "assignOperationLegacy", null);
exports.ProductionPlanningController = ProductionPlanningController = ProductionPlanningController_1 = __decorate([
    (0, swagger_1.ApiTags)('production-planning'),
    (0, common_1.Controller)('planning'),
    __metadata("design:paramtypes", [production_planning_service_1.ProductionPlanningService,
        synchronization_service_1.SynchronizationService])
], ProductionPlanningController);
//# sourceMappingURL=production-planning.controller.js.map