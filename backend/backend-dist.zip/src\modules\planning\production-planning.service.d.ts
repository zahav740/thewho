import { DataSource } from 'typeorm';
export interface OrderWithPriority {
    id: number;
    drawingNumber: string;
    priority: number;
    quantity: number;
    deadline: Date;
    workType: string;
}
export interface OperationData {
    id: number;
    orderId: number;
    operationNumber: number;
    operationType: string;
    estimatedTime: number;
    machineAxes: number;
    status?: string;
}
export interface MachineAvailability {
    id: number;
    code: string;
    type: string;
    axes: number;
    isActive: boolean;
    isOccupied: boolean;
}
export interface PlanningRequest {
    selectedMachines: number[];
    excelData?: any;
}
export interface PlanningResult {
    selectedOrders: OrderWithPriority[];
    operationsQueue: {
        orderId: number;
        operationId: number;
        machineId: number;
        priority: number;
        estimatedTime: number;
        startTime?: Date;
        endTime?: Date;
    }[];
    totalTime: number;
    calculationDate: Date;
}
export declare class ProductionPlanningService {
    private readonly dataSource;
    private readonly logger;
    constructor(dataSource: DataSource);
    planProduction(request: PlanningRequest): Promise<PlanningResult>;
    private getOrdersWithPriorities;
    private selectOrdersWithDifferentPriorities;
    private getAvailableOperationsForOrders;
    private isOperationInProgress;
    private getAvailableMachines;
    private matchOperationsWithMachines;
    private buildPriorityQueue;
    private calculateTimelines;
    private saveResults;
    getLatestPlanningResults(): Promise<any>;
    getOperationProgress(orderIds?: number[]): Promise<any[]>;
}
