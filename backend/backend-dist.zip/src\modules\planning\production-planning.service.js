"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var ProductionPlanningService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductionPlanningService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
let ProductionPlanningService = ProductionPlanningService_1 = class ProductionPlanningService {
    constructor(dataSource) {
        this.dataSource = dataSource;
        this.logger = new common_1.Logger(ProductionPlanningService_1.name);
    }
    async planProduction(request) {
        this.logger.log('Начинаем планирование производства');
        try {
            const orders = await this.getOrdersWithPriorities();
            const machines = await this.getAvailableMachines(request.selectedMachines);
            const selectedOrders = await this.selectOrdersWithDifferentPriorities(orders);
            const operations = await this.getAvailableOperationsForOrders(selectedOrders);
            const machineMatching = this.matchOperationsWithMachines(operations, machines);
            const queue = this.buildPriorityQueue(machineMatching, selectedOrders);
            const result = this.calculateTimelines(queue, selectedOrders);
            await this.saveResults(result);
            this.logger.log('Планирование завершено успешно');
            return result;
        }
        catch (error) {
            this.logger.error('Ошибка при планировании:', error);
            throw error;
        }
    }
    async getOrdersWithPriorities() {
        this.logger.log('Загрузка заказов с приоритетами');
        const orders = await this.dataSource.query(`
      SELECT 
        id,
        drawing_number as "drawingNumber",
        priority,
        quantity,
        deadline,
        "workType"
      FROM orders 
      WHERE priority IN (1, 2, 3)
      ORDER BY priority ASC, deadline ASC
    `);
        this.logger.log(`Найдено ${orders.length} заказов с приоритетами`);
        return orders;
    }
    async selectOrdersWithDifferentPriorities(orders) {
        this.logger.log('Выбор заказов с разными приоритетами');
        const selectedOrders = [];
        for (let priority = 1; priority <= 3; priority++) {
            const orderWithPriority = orders.find(order => order.priority === priority);
            if (orderWithPriority) {
                selectedOrders.push(orderWithPriority);
            }
        }
        if (selectedOrders.length === 0) {
            throw new common_1.NotFoundException('Не найдено ни одного заказа с приоритетами 1, 2 или 3');
        }
        this.logger.log(`Выбрано ${selectedOrders.length} заказов с приоритетами: ${selectedOrders.map(o => o.priority).join(', ')}`);
        return selectedOrders;
    }
    async getAvailableOperationsForOrders(orders) {
        this.logger.log('=== ИСПРАВЛЕННАЯ ЛОГИКА: Получение доступных операций для заказов ===');
        const orderIds = orders.map(o => o.id);
        const availableOperations = [];
        for (const order of orders) {
            this.logger.log(`\n--- Анализируем заказ ID:${order.id} (${order.drawingNumber}) ---`);
            const allOperations = await this.dataSource.query(`
        SELECT 
          id,
          "orderId",
          "operationNumber",
          operationtype as "operationType",
          "estimatedTime",
          machineaxes as "machineAxes",
          status,
          "assignedMachine",
          "assignedAt"
        FROM operations 
        WHERE "orderId" = $1
        ORDER BY "operationNumber" ASC
      `, [order.id]);
            this.logger.log(`Найдено ${allOperations.length} операций для заказа`);
            let nextOperation = null;
            for (const operation of allOperations) {
                this.logger.log(`Операция ${operation.operationNumber}: статус="${operation.status}", назначена=${operation.assignedMachine}`);
                const isInProgress = await this.isOperationInProgress(operation.id);
                if (isInProgress) {
                    this.logger.log(`  ❌ Операция ${operation.operationNumber} уже выполняется на станке`);
                    continue;
                }
                if (operation.status === 'COMPLETED') {
                    this.logger.log(`  ✅ Операция ${operation.operationNumber} завершена, переходим к следующей`);
                    continue;
                }
                if (operation.status === 'IN_PROGRESS') {
                    this.logger.log(`  ⏳ Операция ${operation.operationNumber} в процессе выполнения, пропускаем`);
                    continue;
                }
                if (!operation.status || operation.status === 'PENDING') {
                    if (operation.operationNumber === 1) {
                        this.logger.log(`  🎯 Первая операция ${operation.operationNumber} доступна для назначения`);
                        nextOperation = operation;
                        break;
                    }
                    else {
                        const prevOperation = allOperations.find(op => op.operationNumber === operation.operationNumber - 1);
                        if (prevOperation && prevOperation.status === 'COMPLETED') {
                            this.logger.log(`  🎯 Операция ${operation.operationNumber} доступна (предыдущая завершена)`);
                            nextOperation = operation;
                            break;
                        }
                        else {
                            this.logger.log(`  ⏸️ Операция ${operation.operationNumber} ожидает завершения предыдущей`);
                        }
                    }
                }
            }
            if (nextOperation) {
                this.logger.log(`✅ Для заказа ${order.drawingNumber} выбрана операция ${nextOperation.operationNumber}`);
                availableOperations.push({
                    id: nextOperation.id,
                    orderId: nextOperation.orderId,
                    operationNumber: nextOperation.operationNumber,
                    operationType: nextOperation.operationType,
                    estimatedTime: nextOperation.estimatedTime,
                    machineAxes: nextOperation.machineAxes,
                    status: nextOperation.status
                });
            }
            else {
                this.logger.warn(`❌ Для заказа ${order.drawingNumber} нет доступных операций`);
            }
        }
        this.logger.log(`\n=== ИТОГО: Найдено ${availableOperations.length} доступных операций ===`);
        availableOperations.forEach(op => {
            this.logger.log(`- Заказ ${op.orderId}, Операция ${op.operationNumber} (${op.operationType})`);
        });
        return availableOperations;
    }
    async isOperationInProgress(operationId) {
        const result = await this.dataSource.query(`
      SELECT COUNT(*) as count 
      FROM machines 
      WHERE "currentOperation" = $1 AND "isOccupied" = true
    `, [operationId]);
        return parseInt(result[0].count) > 0;
    }
    async getAvailableMachines(selectedMachineIds) {
        this.logger.log('Получение доступных станков');
        let query = `
      SELECT 
        id,
        code,
        type,
        axes,
        "isActive",
        "isOccupied"
      FROM machines 
      WHERE "isActive" = true AND "isOccupied" = false
    `;
        let params = [];
        if (selectedMachineIds && selectedMachineIds.length > 0) {
            query += ' AND id = ANY($1)';
            params = [selectedMachineIds];
        }
        const machines = await this.dataSource.query(query, params);
        this.logger.log(`Найдено ${machines.length} доступных станков`);
        machines.forEach(machine => {
            this.logger.log(`Станок ID:${machine.id}, Код:${machine.code}, Тип:${machine.type}, Оси:${machine.axes}`);
        });
        return machines;
    }
    matchOperationsWithMachines(operations, machines) {
        this.logger.log('=== НАЧАЛО СОПОСТАВЛЕНИЯ ОПЕРАЦИЙ СО СТАНКАМИ ===');
        this.logger.log(`Всего операций: ${operations.length}`);
        this.logger.log(`Всего доступных станков: ${machines.length}`);
        const matching = [];
        for (const operation of operations) {
            this.logger.log(`\n--- Обрабатываем операцию ID:${operation.id} ---`);
            this.logger.log(`Тип: ${operation.operationType}, Оси: ${operation.machineAxes}, Заказ: ${operation.orderId}`);
            const compatibleMachines = machines.filter(machine => {
                this.logger.log(`Проверяем станок ${machine.code} (${machine.type}, ${machine.axes} осей)`);
                let isCompatible = false;
                if (operation.operationType === 'TURNING') {
                    isCompatible = machine.type === 'TURNING';
                    this.logger.log(`TURNING операция: совместим = ${isCompatible}`);
                }
                else if (operation.operationType === 'MILLING') {
                    if (operation.machineAxes === 4) {
                        isCompatible = machine.type === 'MILLING' && machine.axes >= 4;
                        this.logger.log(`MILLING 4-осевая операция: совместим = ${isCompatible}`);
                    }
                    else {
                        isCompatible = machine.type === 'MILLING';
                        this.logger.log(`MILLING 3-осевая операция: совместим = ${isCompatible}`);
                    }
                }
                else {
                    this.logger.warn(`Неподдерживаемый тип операции: ${operation.operationType}. Поддерживаются только: TURNING, MILLING (3-осевая), MILLING (4-осевая)`);
                    isCompatible = false;
                }
                return isCompatible;
            });
            this.logger.log(`Найдено ${compatibleMachines.length} совместимых станков для операции ${operation.operationType}`);
            if (compatibleMachines.length > 0) {
                const selectedMachine = compatibleMachines[0];
                this.logger.log(`✅ Выбран станок: ${selectedMachine.code} (ID:${selectedMachine.id}, тип: ${selectedMachine.type}, оси: ${selectedMachine.axes})`);
                matching.push({
                    operation,
                    machines: compatibleMachines,
                    selectedMachine
                });
            }
            else {
                this.logger.error(`❌ НЕ НАЙДЕНО совместимых станков для операции ${operation.operationType}!`);
                this.logger.error(`Операция требует: ${operation.operationType}, оси: ${operation.machineAxes}`);
                this.logger.error(`Доступные станки:`);
                machines.forEach(m => {
                    this.logger.error(`- ${m.code}: ${m.type}, ${m.axes} осей`);
                });
            }
        }
        this.logger.log(`\n=== ИТОГ СОПОСТАВЛЕНИЯ ===`);
        this.logger.log(`Сопоставлено ${matching.length} операций из ${operations.length}`);
        if (matching.length === 0) {
            this.logger.error('🚨 КРИТИЧЕСКАЯ ОШИБКА: НЕ СОПОСТАВЛЕНО НИ ОДНОЙ ОПЕРАЦИИ!');
        }
        return matching;
    }
    buildPriorityQueue(machineMatching, orders) {
        this.logger.log('Построение очереди по приоритетам');
        const queue = machineMatching.map(match => {
            const order = orders.find(o => o.id === match.operation.orderId);
            return {
                orderId: match.operation.orderId,
                operationId: match.operation.id,
                operationNumber: match.operation.operationNumber,
                operationType: match.operation.operationType,
                machineId: match.selectedMachine.id,
                machineAxes: match.operation.machineAxes,
                priority: order?.priority || 999,
                estimatedTime: match.operation.estimatedTime
            };
        });
        queue.sort((a, b) => a.priority - b.priority);
        this.logger.log(`Построена очередь из ${queue.length} операций`);
        return queue;
    }
    calculateTimelines(queue, orders) {
        this.logger.log('Расчет временных рамок');
        let currentTime = new Date();
        let totalTime = 0;
        const operationsQueue = queue.map(queueItem => {
            const startTime = new Date(currentTime);
            const endTime = new Date(currentTime.getTime() + queueItem.estimatedTime * 60000);
            totalTime += queueItem.estimatedTime;
            currentTime = endTime;
            return {
                ...queueItem,
                startTime,
                endTime
            };
        });
        return {
            selectedOrders: orders,
            operationsQueue,
            totalTime,
            calculationDate: new Date()
        };
    }
    async saveResults(result) {
        this.logger.log('Сохранение результатов планирования');
        try {
            await this.dataSource.query(`
        INSERT INTO planning_results (
          calculation_date,
          selected_orders,
          selected_machines,
          queue_plan,
          total_time
        ) VALUES ($1, $2, $3, $4, $5)
      `, [
                result.calculationDate,
                JSON.stringify(result.selectedOrders),
                JSON.stringify(result.operationsQueue.map(op => op.machineId)),
                JSON.stringify(result.operationsQueue),
                result.totalTime
            ]);
            for (const order of result.selectedOrders) {
                const orderOperations = result.operationsQueue.filter(op => op.orderId === order.id);
                await this.dataSource.query(`
          INSERT INTO operation_progress (
            order_id,
            calculation_date,
            deadline,
            quantity,
            total_production_time,
            operations
          ) VALUES ($1, $2, $3, $4, $5, $6)
        `, [
                    order.id,
                    result.calculationDate,
                    order.deadline,
                    order.quantity,
                    orderOperations.reduce((sum, op) => sum + op.estimatedTime, 0),
                    JSON.stringify(orderOperations)
                ]);
            }
            this.logger.log('Результаты сохранены успешно');
        }
        catch (error) {
            this.logger.error('Ошибка при сохранении результатов:', error);
            throw error;
        }
    }
    async getLatestPlanningResults() {
        this.logger.log('Получение последних результатов планирования');
        const results = await this.dataSource.query(`
      SELECT * FROM planning_results 
      ORDER BY calculation_date DESC 
      LIMIT 1
    `);
        return results[0] || null;
    }
    async getOperationProgress(orderIds) {
        this.logger.log('Получение прогресса операций');
        let query = 'SELECT * FROM operation_progress ORDER BY calculation_date DESC';
        let params = [];
        if (orderIds && orderIds.length > 0) {
            query = 'SELECT * FROM operation_progress WHERE order_id = ANY($1) ORDER BY calculation_date DESC';
            params = [orderIds];
        }
        return await this.dataSource.query(query, params);
    }
};
exports.ProductionPlanningService = ProductionPlanningService;
exports.ProductionPlanningService = ProductionPlanningService = ProductionPlanningService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectDataSource)()),
    __metadata("design:paramtypes", [typeorm_2.DataSource])
], ProductionPlanningService);
//# sourceMappingURL=production-planning.service.js.map