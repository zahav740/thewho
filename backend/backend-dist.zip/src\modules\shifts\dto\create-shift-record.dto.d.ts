export declare class CreateShiftRecordDto {
    date: string;
    shiftType: string;
    setupTime?: number;
    setupOperator?: string;
    dayShiftQuantity?: number;
    dayShiftOperator?: string;
    dayShiftTimePerUnit?: number;
    nightShiftQuantity?: number;
    nightShiftOperator?: string;
    nightShiftTimePerUnit?: number;
    operationId?: number;
    machineId?: number;
    drawingNumber?: string;
}
