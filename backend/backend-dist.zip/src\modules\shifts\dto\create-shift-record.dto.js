"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateShiftRecordDto = void 0;
const class_validator_1 = require("class-validator");
const swagger_1 = require("@nestjs/swagger");
const class_transformer_1 = require("class-transformer");
class CreateShiftRecordDto {
}
exports.CreateShiftRecordDto = CreateShiftRecordDto;
__decorate([
    (0, swagger_1.ApiProperty)({ example: '2024-01-15', description: 'Дата смены' }),
    (0, class_validator_1.IsDateString)({}, { message: 'Поле date должно быть корректной датой в формате YYYY-MM-DD' }),
    __metadata("design:type", String)
], CreateShiftRecordDto.prototype, "date", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ example: 'DAY', description: 'Тип смены (DAY/NIGHT)' }),
    (0, class_validator_1.IsString)({ message: 'Поле shiftType должно быть строкой' }),
    __metadata("design:type", String)
], CreateShiftRecordDto.prototype, "shiftType", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 120, description: 'Время наладки в минутах' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsNumber)({}, { message: 'Поле setupTime должно быть числом' }),
    (0, class_validator_1.Min)(0, { message: 'Время наладки не может быть отрицательным' }),
    __metadata("design:type", Number)
], CreateShiftRecordDto.prototype, "setupTime", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 'Иван', description: 'Оператор наладки' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: 'Поле setupOperator должно быть строкой' }),
    __metadata("design:type", String)
], CreateShiftRecordDto.prototype, "setupOperator", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 50, description: 'Количество деталей в дневную смену' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsNumber)({}, { message: 'Поле dayShiftQuantity должно быть числом' }),
    (0, class_validator_1.Min)(0, { message: 'Количество деталей не может быть отрицательным' }),
    __metadata("design:type", Number)
], CreateShiftRecordDto.prototype, "dayShiftQuantity", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 'Петр', description: 'Оператор дневной смены' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: 'Поле dayShiftOperator должно быть строкой' }),
    __metadata("design:type", String)
], CreateShiftRecordDto.prototype, "dayShiftOperator", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 5.5, description: 'Время на деталь в дневную смену (в минутах)' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsNumber)({}, { message: 'Поле dayShiftTimePerUnit должно быть числом' }),
    (0, class_validator_1.Min)(0, { message: 'Время на деталь не может быть отрицательным' }),
    __metadata("design:type", Number)
], CreateShiftRecordDto.prototype, "dayShiftTimePerUnit", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 45, description: 'Количество деталей в ночную смену' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsNumber)({}, { message: 'Поле nightShiftQuantity должно быть числом' }),
    (0, class_validator_1.Min)(0, { message: 'Количество деталей не может быть отрицательным' }),
    __metadata("design:type", Number)
], CreateShiftRecordDto.prototype, "nightShiftQuantity", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 'Аркадий', description: 'Оператор ночной смены' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: 'Поле nightShiftOperator должно быть строкой' }),
    __metadata("design:type", String)
], CreateShiftRecordDto.prototype, "nightShiftOperator", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 6.0, description: 'Время на деталь в ночную смену (в минутах)' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsNumber)({}, { message: 'Поле nightShiftTimePerUnit должно быть числом' }),
    (0, class_validator_1.Min)(0, { message: 'Время на деталь не может быть отрицательным' }),
    __metadata("design:type", Number)
], CreateShiftRecordDto.prototype, "nightShiftTimePerUnit", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 1, description: 'ID операции' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsNumber)({}, { message: 'Поле operationId должно быть числом' }),
    __metadata("design:type", Number)
], CreateShiftRecordDto.prototype, "operationId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 1, description: 'ID станка' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Type)(() => Number),
    (0, class_validator_1.IsNumber)({}, { message: 'Поле machineId должно быть числом' }),
    __metadata("design:type", Number)
], CreateShiftRecordDto.prototype, "machineId", void 0);
__decorate([
    (0, swagger_1.ApiPropertyOptional)({ example: 'C6HP0021A', description: 'Номер чертежа' }),
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)({ message: 'Поле drawingNumber должно быть строкой' }),
    __metadata("design:type", String)
], CreateShiftRecordDto.prototype, "drawingNumber", void 0);
//# sourceMappingURL=create-shift-record.dto.js.map