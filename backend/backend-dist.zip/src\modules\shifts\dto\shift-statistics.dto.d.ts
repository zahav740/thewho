export declare class OperatorStatDto {
    operatorName: string;
    totalQuantity: number;
    totalTime: number;
}
export declare class ShiftStatDto {
    totalQuantity: number;
    totalTime: number;
}
export declare class ShiftStatisticsDto {
    totalRecords: number;
    totalSetupTime: number;
    totalProductionTime: number;
    totalQuantity: number;
    dayShiftStats: ShiftStatDto;
    nightShiftStats: ShiftStatDto;
    operatorStats: OperatorStatDto[];
}
