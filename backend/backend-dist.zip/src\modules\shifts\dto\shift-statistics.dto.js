"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShiftStatisticsDto = exports.ShiftStatDto = exports.OperatorStatDto = void 0;
const swagger_1 = require("@nestjs/swagger");
class OperatorStatDto {
}
exports.OperatorStatDto = OperatorStatDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", String)
], OperatorStatDto.prototype, "operatorName", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], OperatorStatDto.prototype, "totalQuantity", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], OperatorStatDto.prototype, "totalTime", void 0);
class ShiftStatDto {
}
exports.ShiftStatDto = ShiftStatDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], ShiftStatDto.prototype, "totalQuantity", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], ShiftStatDto.prototype, "totalTime", void 0);
class ShiftStatisticsDto {
}
exports.ShiftStatisticsDto = ShiftStatisticsDto;
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], ShiftStatisticsDto.prototype, "totalRecords", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], ShiftStatisticsDto.prototype, "totalSetupTime", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], ShiftStatisticsDto.prototype, "totalProductionTime", void 0);
__decorate([
    (0, swagger_1.ApiProperty)(),
    __metadata("design:type", Number)
], ShiftStatisticsDto.prototype, "totalQuantity", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ type: ShiftStatDto }),
    __metadata("design:type", ShiftStatDto)
], ShiftStatisticsDto.prototype, "dayShiftStats", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ type: ShiftStatDto }),
    __metadata("design:type", ShiftStatDto)
], ShiftStatisticsDto.prototype, "nightShiftStats", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({ type: [OperatorStatDto] }),
    __metadata("design:type", Array)
], ShiftStatisticsDto.prototype, "operatorStats", void 0);
//# sourceMappingURL=shift-statistics.dto.js.map