export declare class ShiftsFilterDto {
    startDate?: string;
    endDate?: string;
    machineId?: number;
    operationId?: number;
}
