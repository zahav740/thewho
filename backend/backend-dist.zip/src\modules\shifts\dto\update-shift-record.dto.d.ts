import { CreateShiftRecordDto } from './create-shift-record.dto';
declare const UpdateShiftRecordDto_base: import("@nestjs/common").Type<Partial<CreateShiftRecordDto>>;
export declare class UpdateShiftRecordDto extends UpdateShiftRecordDto_base {
}
export {};
