import { DataSource } from 'typeorm';
export declare class ShiftsSimpleController {
    private readonly dataSource;
    constructor(dataSource: DataSource);
    private normalizeRecord;
    findAll(startDate?: string, endDate?: string): Promise<any>;
    create(createShiftDto: any): Promise<any>;
    testCreate(createShiftDto: any): Promise<{
        success: boolean;
        message: string;
        receivedData: any;
        timestamp: string;
    }>;
    findOne(id: string): Promise<any>;
    update(id: string, updateShiftDto: any): Promise<any>;
}
