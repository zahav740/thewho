"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShiftsSimpleController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
let ShiftsSimpleController = class ShiftsSimpleController {
    constructor(dataSource) {
        this.dataSource = dataSource;
    }
    normalizeRecord(record) {
        if (record) {
            if (record.dayShiftTimePerUnit !== null && record.dayShiftTimePerUnit !== undefined) {
                record.dayShiftTimePerUnit = parseFloat(record.dayShiftTimePerUnit.toString());
            }
            if (record.nightShiftTimePerUnit !== null && record.nightShiftTimePerUnit !== undefined) {
                record.nightShiftTimePerUnit = parseFloat(record.nightShiftTimePerUnit.toString());
            }
            if (record.setupTime !== null && record.setupTime !== undefined) {
                record.setupTime = parseInt(record.setupTime.toString());
            }
            if (record.dayShiftQuantity !== null && record.dayShiftQuantity !== undefined) {
                record.dayShiftQuantity = parseInt(record.dayShiftQuantity.toString());
            }
            if (record.nightShiftQuantity !== null && record.nightShiftQuantity !== undefined) {
                record.nightShiftQuantity = parseInt(record.nightShiftQuantity.toString());
            }
        }
        return record;
    }
    async findAll(startDate, endDate) {
        try {
            console.log('ShiftsSimpleController.findAll: Получение смен');
            let query = `
        SELECT sr.*, m.code as machine_code, m.type as machine_type 
        FROM shift_records sr
        LEFT JOIN machines m ON sr."machineId" = m.id
        ORDER BY sr.date DESC
      `;
            const params = [];
            if (startDate && endDate) {
                query = `
          SELECT sr.*, m.code as machine_code, m.type as machine_type 
          FROM shift_records sr
          LEFT JOIN machines m ON sr."machineId" = m.id
          WHERE sr.date BETWEEN $1 AND $2
          ORDER BY sr.date DESC
        `;
                params.push(startDate, endDate);
            }
            const records = await this.dataSource.query(query, params);
            const normalizedRecords = records.map(record => this.normalizeRecord(record));
            console.log('ShiftsSimpleController.findAll: Найдено записей:', normalizedRecords.length);
            return normalizedRecords;
        }
        catch (error) {
            console.error('ShiftsSimpleController.findAll: Ошибка:', error);
            throw error;
        }
    }
    async create(createShiftDto) {
        try {
            console.log('=== ShiftsSimpleController.create ===');
            console.log('Полученные данные:', JSON.stringify(createShiftDto, null, 2));
            const insertData = {
                date: createShiftDto.date,
                shiftType: createShiftDto.shiftType,
                setupTime: createShiftDto.setupTime || null,
                dayShiftQuantity: createShiftDto.dayShiftQuantity || null,
                dayShiftOperator: createShiftDto.dayShiftOperator || null,
                dayShiftTimePerUnit: createShiftDto.dayShiftTimePerUnit || null,
                nightShiftQuantity: createShiftDto.nightShiftQuantity || null,
                nightShiftOperator: createShiftDto.nightShiftOperator || null,
                nightShiftTimePerUnit: createShiftDto.nightShiftTimePerUnit || null,
                operationId: createShiftDto.operationId || null,
                machineId: createShiftDto.machineId,
                drawingNumber: createShiftDto.drawingNumber || null
            };
            const insertQuery = `
        INSERT INTO shift_records (
          date, "shiftType", "setupTime", "dayShiftQuantity", 
          "dayShiftOperator", "dayShiftTimePerUnit", "nightShiftQuantity", 
          "nightShiftOperator", "nightShiftTimePerUnit", "operationId", 
          "machineId", "drawingnumber", "createdAt", "updatedAt"
        ) VALUES (
          $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, NOW(), NOW()
        ) RETURNING *
      `;
            const values = [
                insertData.date,
                insertData.shiftType,
                insertData.setupTime,
                insertData.dayShiftQuantity,
                insertData.dayShiftOperator,
                insertData.dayShiftTimePerUnit,
                insertData.nightShiftQuantity,
                insertData.nightShiftOperator,
                insertData.nightShiftTimePerUnit,
                insertData.operationId,
                insertData.machineId,
                insertData.drawingNumber
            ];
            const result = await this.dataSource.query(insertQuery, values);
            console.log('Успешно создана запись смены:', result[0]);
            return this.normalizeRecord(result[0]);
        }
        catch (error) {
            console.error('=== Ошибка в ShiftsSimpleController.create ===');
            console.error('Тип ошибки:', error.constructor.name);
            console.error('Сообщение:', error.message);
            throw error;
        }
    }
    async testCreate(createShiftDto) {
        console.log('=== ShiftsSimpleController.testCreate ===');
        console.log('Полученные данные:', JSON.stringify(createShiftDto, null, 2));
        return {
            success: true,
            message: 'Данные получены успешно',
            receivedData: createShiftDto,
            timestamp: new Date().toISOString()
        };
    }
    async findOne(id) {
        try {
            console.log('ShiftsSimpleController.findOne: Получение записи смены ID:', id);
            const query = `
        SELECT sr.*, m.code as machine_code, m.type as machine_type 
        FROM shift_records sr
        LEFT JOIN machines m ON sr."machineId" = m.id
        WHERE sr.id = $1
      `;
            const result = await this.dataSource.query(query, [parseInt(id)]);
            if (result.length === 0) {
                throw new Error(`Запись смены с ID ${id} не найдена`);
            }
            const normalizedRecord = this.normalizeRecord(result[0]);
            console.log('ShiftsSimpleController.findOne: Запись найдена:', normalizedRecord);
            return normalizedRecord;
        }
        catch (error) {
            console.error('ShiftsSimpleController.findOne: Ошибка:', error);
            throw error;
        }
    }
    async update(id, updateShiftDto) {
        try {
            console.log('ShiftsSimpleController.update: Обновление записи смены ID:', id, updateShiftDto);
            const updateQuery = `
        UPDATE shift_records 
        SET 
          date = $2, "shiftType" = $3, "setupTime" = $4, 
          "dayShiftQuantity" = $5, "dayShiftOperator" = $6, "dayShiftTimePerUnit" = $7,
          "nightShiftQuantity" = $8, "nightShiftOperator" = $9, "nightShiftTimePerUnit" = $10,
          "operationId" = $11, "machineId" = $12, "drawingnumber" = $13, "updatedAt" = NOW()
        WHERE id = $1
        RETURNING *
      `;
            const values = [
                parseInt(id),
                updateShiftDto.date,
                updateShiftDto.shiftType,
                updateShiftDto.setupTime,
                updateShiftDto.dayShiftQuantity,
                updateShiftDto.dayShiftOperator,
                updateShiftDto.dayShiftTimePerUnit,
                updateShiftDto.nightShiftQuantity,
                updateShiftDto.nightShiftOperator,
                updateShiftDto.nightShiftTimePerUnit,
                updateShiftDto.operationId,
                updateShiftDto.machineId,
                updateShiftDto.drawingNumber
            ];
            const result = await this.dataSource.query(updateQuery, values);
            if (result.length === 0) {
                throw new Error(`Запись смены с ID ${id} не найдена`);
            }
            const normalizedRecord = this.normalizeRecord(result[0]);
            console.log('ShiftsSimpleController.update: Запись обновлена:', normalizedRecord);
            return normalizedRecord;
        }
        catch (error) {
            console.error('ShiftsSimpleController.update: Ошибка:', error);
            throw error;
        }
    }
};
exports.ShiftsSimpleController = ShiftsSimpleController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Получить все смены' }),
    __param(0, (0, common_1.Query)('startDate')),
    __param(1, (0, common_1.Query)('endDate')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], ShiftsSimpleController.prototype, "findAll", null);
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Создать запись смены' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ShiftsSimpleController.prototype, "create", null);
__decorate([
    (0, common_1.Post)('test'),
    (0, swagger_1.ApiOperation)({ summary: 'Тестовый endpoint - просто возвращает полученные данные' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ShiftsSimpleController.prototype, "testCreate", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить запись смены по ID' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ShiftsSimpleController.prototype, "findOne", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Обновить запись смены' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], ShiftsSimpleController.prototype, "update", null);
exports.ShiftsSimpleController = ShiftsSimpleController = __decorate([
    (0, swagger_1.ApiTags)('shifts-simple'),
    (0, common_1.Controller)('shifts'),
    __param(0, (0, typeorm_1.InjectDataSource)()),
    __metadata("design:paramtypes", [typeorm_2.DataSource])
], ShiftsSimpleController);
//# sourceMappingURL=shifts-simple.controller.js.map