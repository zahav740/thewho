import { ShiftsService } from './shifts.service';
import { CreateShiftRecordDto } from './dto/create-shift-record.dto';
import { UpdateShiftRecordDto } from './dto/update-shift-record.dto';
import { ShiftsFilterDto } from './dto/shifts-filter.dto';
import { ShiftRecord } from '../../database/entities/shift-record.entity';
import { ShiftStatisticsDto } from './dto/shift-statistics.dto';
import { Repository } from 'typeorm';
export declare class ShiftsController {
    private readonly shiftsService;
    private readonly shiftRecordRepository;
    private readonly logger;
    constructor(shiftsService: ShiftsService, shiftRecordRepository: Repository<ShiftRecord>);
    findAll(filterDto: ShiftsFilterDto): Promise<ShiftRecord[]>;
    getStatistics(filterDto: ShiftsFilterDto): Promise<ShiftStatisticsDto>;
    findOne(id: string): Promise<ShiftRecord>;
    create(createShiftRecordDto: CreateShiftRecordDto): Promise<ShiftRecord>;
    update(id: string, updateShiftRecordDto: UpdateShiftRecordDto): Promise<ShiftRecord>;
    remove(id: string): Promise<void>;
    getByDate(date: string): Promise<ShiftRecord[]>;
    getByOperator(operator: string): Promise<ShiftRecord[]>;
    resetOperationShifts(body: {
        operationId: number;
    }): Promise<any>;
}
