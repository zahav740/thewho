"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var ShiftsController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShiftsController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const shifts_service_1 = require("./shifts.service");
const create_shift_record_dto_1 = require("./dto/create-shift-record.dto");
const update_shift_record_dto_1 = require("./dto/update-shift-record.dto");
const shifts_filter_dto_1 = require("./dto/shifts-filter.dto");
const shift_record_entity_1 = require("../../database/entities/shift-record.entity");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
let ShiftsController = ShiftsController_1 = class ShiftsController {
    constructor(shiftsService, shiftRecordRepository) {
        this.shiftsService = shiftsService;
        this.shiftRecordRepository = shiftRecordRepository;
        this.logger = new common_1.Logger(ShiftsController_1.name);
    }
    async findAll(filterDto) {
        try {
            this.logger.log(`Получение записей смен с фильтром: ${JSON.stringify(filterDto)}`);
            return await this.shiftsService.findAll(filterDto);
        }
        catch (error) {
            this.logger.error(`Ошибка при получении записей смен: ${error.message}`, error.stack);
            throw error;
        }
    }
    async getStatistics(filterDto) {
        try {
            this.logger.log(`Получение статистики смен с фильтром: ${JSON.stringify(filterDto)}`);
            return await this.shiftsService.getStatistics(filterDto);
        }
        catch (error) {
            this.logger.error(`Ошибка при получении статистики смен: ${error.message}`, error.stack);
            throw error;
        }
    }
    async findOne(id) {
        try {
            this.logger.log(`Получение записи смены с ID: ${id}`);
            return await this.shiftsService.findOne(+id);
        }
        catch (error) {
            this.logger.error(`Ошибка при получении записи смены с ID ${id}: ${error.message}`, error.stack);
            throw error;
        }
    }
    async create(createShiftRecordDto) {
        try {
            this.logger.log(`=== Создание записи смены ===`);
            this.logger.log(`Полученные данные: ${JSON.stringify(createShiftRecordDto, null, 2)}`);
            if (!createShiftRecordDto.date) {
                throw new common_1.BadRequestException('Поле date обязательно');
            }
            if (!createShiftRecordDto.shiftType) {
                throw new common_1.BadRequestException('Поле shiftType обязательно');
            }
            this.logger.log('Типы полей:');
            Object.keys(createShiftRecordDto).forEach(key => {
                const value = createShiftRecordDto[key];
                this.logger.log(`  ${key}: ${typeof value} = ${value}`);
            });
            const result = await this.shiftsService.create(createShiftRecordDto);
            this.logger.log(`Успешно создана запись смены с ID: ${result.id}`);
            return result;
        }
        catch (error) {
            this.logger.error(`=== Ошибка при создании записи смены ===`);
            this.logger.error(`Тип ошибки: ${error.constructor.name}`);
            this.logger.error(`Сообщение: ${error.message}`);
            this.logger.error(`Полная ошибка:`, error);
            if (error instanceof common_1.BadRequestException) {
                throw error;
            }
            if (error.message && error.message.includes('validation')) {
                throw new common_1.BadRequestException(`Ошибка валидации данных: ${error.message}`);
            }
            throw new common_1.BadRequestException(`Ошибка при создании записи смены: ${error.message}`);
        }
    }
    async update(id, updateShiftRecordDto) {
        try {
            this.logger.log(`Обновление записи смены с ID: ${id}`);
            this.logger.log(`Данные для обновления: ${JSON.stringify(updateShiftRecordDto, null, 2)}`);
            const result = await this.shiftsService.update(+id, updateShiftRecordDto);
            this.logger.log(`Успешно обновлена запись смены с ID: ${id}`);
            return result;
        }
        catch (error) {
            this.logger.error(`Ошибка при обновлении записи смены с ID ${id}: ${error.message}`, error.stack);
            throw error;
        }
    }
    async remove(id) {
        try {
            this.logger.log(`Удаление записи смены с ID: ${id}`);
            await this.shiftsService.remove(+id);
            this.logger.log(`Успешно удалена запись смены с ID: ${id}`);
        }
        catch (error) {
            this.logger.error(`Ошибка при удалении записи смены с ID ${id}: ${error.message}`, error.stack);
            throw error;
        }
    }
    async getByDate(date) {
        try {
            this.logger.log(`Получение смен по дате: ${date}`);
            return await this.shiftsService.getShiftsByDate(new Date(date));
        }
        catch (error) {
            this.logger.error(`Ошибка при получении смен по дате ${date}: ${error.message}`, error.stack);
            throw error;
        }
    }
    async getByOperator(operator) {
        try {
            this.logger.log(`Получение смен по оператору: ${operator}`);
            return await this.shiftsService.getShiftsByOperator(operator);
        }
        catch (error) {
            this.logger.error(`Ошибка при получении смен по оператору ${operator}: ${error.message}`, error.stack);
            throw error;
        }
    }
    async resetOperationShifts(body) {
        try {
            this.logger.log(`Сброс данных смен для операции ${body.operationId}`);
            const result = await this.shiftRecordRepository.update({ operationId: body.operationId }, {
                dayShiftQuantity: 0,
                nightShiftQuantity: 0,
                dayShiftTimePerUnit: 0,
                nightShiftTimePerUnit: 0
            });
            return {
                success: true,
                message: 'Данные смен успешно сброшены',
                operationId: body.operationId,
                affectedRows: result.affected
            };
        }
        catch (error) {
            this.logger.error(`Ошибка при сбросе данных смен: ${error.message}`, error.stack);
            throw error;
        }
    }
};
exports.ShiftsController = ShiftsController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Получить записи смен с фильтрацией' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [shifts_filter_dto_1.ShiftsFilterDto]),
    __metadata("design:returntype", Promise)
], ShiftsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('statistics'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить статистику по сменам' }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [shifts_filter_dto_1.ShiftsFilterDto]),
    __metadata("design:returntype", Promise)
], ShiftsController.prototype, "getStatistics", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить запись смены по ID' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ShiftsController.prototype, "findOne", null);
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Создать запись смены' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_shift_record_dto_1.CreateShiftRecordDto]),
    __metadata("design:returntype", Promise)
], ShiftsController.prototype, "create", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Обновить запись смены' }),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_shift_record_dto_1.UpdateShiftRecordDto]),
    __metadata("design:returntype", Promise)
], ShiftsController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Удалить запись смены' }),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ShiftsController.prototype, "remove", null);
__decorate([
    (0, common_1.Get)('by-date/:date'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить смены по дате' }),
    __param(0, (0, common_1.Param)('date')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ShiftsController.prototype, "getByDate", null);
__decorate([
    (0, common_1.Get)('by-operator/:operator'),
    (0, swagger_1.ApiOperation)({ summary: 'Получить смены по оператору' }),
    __param(0, (0, common_1.Param)('operator')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], ShiftsController.prototype, "getByOperator", null);
__decorate([
    (0, common_1.Post)('reset-operation'),
    (0, swagger_1.ApiOperation)({ summary: 'Сбросить данные смен для операции' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], ShiftsController.prototype, "resetOperationShifts", null);
exports.ShiftsController = ShiftsController = ShiftsController_1 = __decorate([
    (0, swagger_1.ApiTags)('shifts'),
    (0, common_1.Controller)('shifts'),
    __param(1, (0, typeorm_1.InjectRepository)(shift_record_entity_1.ShiftRecord)),
    __metadata("design:paramtypes", [shifts_service_1.ShiftsService,
        typeorm_2.Repository])
], ShiftsController);
//# sourceMappingURL=shifts.controller.js.map