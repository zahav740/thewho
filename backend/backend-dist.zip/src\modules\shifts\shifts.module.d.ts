export declare class ShiftsModule {
}
