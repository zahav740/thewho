import { Repository } from 'typeorm';
import { ShiftRecord } from '../../database/entities/shift-record.entity';
import { CreateShiftRecordDto } from './dto/create-shift-record.dto';
import { UpdateShiftRecordDto } from './dto/update-shift-record.dto';
import { ShiftsFilterDto } from './dto/shifts-filter.dto';
import { ShiftStatisticsDto } from './dto/shift-statistics.dto';
export declare class ShiftsService {
    private readonly shiftRecordRepository;
    private readonly logger;
    constructor(shiftRecordRepository: Repository<ShiftRecord>);
    private normalizeShiftRecord;
    private normalizeShiftRecords;
    findAll(filterDto: ShiftsFilterDto): Promise<any[]>;
    findOne(id: number): Promise<any>;
    create(createShiftRecordDto: CreateShiftRecordDto): Promise<any>;
    update(id: number, updateShiftRecordDto: UpdateShiftRecordDto): Promise<any>;
    remove(id: number): Promise<void>;
    getStatistics(filterDto: ShiftsFilterDto): Promise<ShiftStatisticsDto>;
    getShiftsByDate(date: Date): Promise<any[]>;
    getShiftsByOperator(operatorName: string): Promise<any[]>;
    getShiftsByMachine(machineId: number): Promise<any[]>;
}
