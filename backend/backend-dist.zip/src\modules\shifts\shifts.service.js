"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var ShiftsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShiftsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const shift_record_entity_1 = require("../../database/entities/shift-record.entity");
let ShiftsService = ShiftsService_1 = class ShiftsService {
    constructor(shiftRecordRepository) {
        this.shiftRecordRepository = shiftRecordRepository;
        this.logger = new common_1.Logger(ShiftsService_1.name);
    }
    normalizeShiftRecord(record) {
        if (record) {
            record.dayShiftTimePerUnit = record.dayShiftTimePerUnit ?
                parseFloat(record.dayShiftTimePerUnit.toString()) : null;
            record.nightShiftTimePerUnit = record.nightShiftTimePerUnit ?
                parseFloat(record.nightShiftTimePerUnit.toString()) : null;
            record.setupTime = record.setupTime ?
                parseInt(record.setupTime.toString()) : null;
            record.dayShiftQuantity = record.dayShiftQuantity ?
                parseInt(record.dayShiftQuantity.toString()) : null;
            record.nightShiftQuantity = record.nightShiftQuantity ?
                parseInt(record.nightShiftQuantity.toString()) : null;
            if (record.machine) {
                record.machineCode = record.machine.code;
                record.machineType = record.machine.type;
            }
            if (record.operation) {
                record.operationNumber = record.operation.operationNumber;
                record.operationType = record.operation.operationType;
                if (record.operation.order) {
                    record.orderDrawingNumber = record.operation.order.drawingNumber;
                    record.orderId = record.operation.order.id;
                }
            }
            if (record.drawingnumber) {
                record.drawingNumber = record.drawingnumber;
            }
        }
        return record;
    }
    normalizeShiftRecords(records) {
        return records.map(record => this.normalizeShiftRecord(record));
    }
    async findAll(filterDto) {
        const { startDate, endDate, machineId, operationId } = filterDto;
        const queryBuilder = this.shiftRecordRepository
            .createQueryBuilder('shift')
            .leftJoinAndSelect('shift.machine', 'machine')
            .leftJoinAndSelect('shift.operation', 'operation')
            .leftJoinAndSelect('operation.order', 'order')
            .orderBy('shift.createdAt', 'DESC');
        if (startDate && endDate) {
            queryBuilder.andWhere('shift.date BETWEEN :startDate AND :endDate', {
                startDate: new Date(startDate),
                endDate: new Date(endDate),
            });
        }
        if (machineId) {
            queryBuilder.andWhere('shift.machineId = :machineId', { machineId });
        }
        if (operationId) {
            queryBuilder.andWhere('shift.operationId = :operationId', { operationId });
        }
        const records = await queryBuilder.getMany();
        return this.normalizeShiftRecords(records);
    }
    async findOne(id) {
        const shiftRecord = await this.shiftRecordRepository
            .createQueryBuilder('shift')
            .leftJoinAndSelect('shift.machine', 'machine')
            .leftJoinAndSelect('shift.operation', 'operation')
            .leftJoinAndSelect('operation.order', 'order')
            .where('shift.id = :id', { id })
            .getOne();
        if (!shiftRecord) {
            throw new common_1.NotFoundException(`Запись смены с ID ${id} не найдена`);
        }
        return this.normalizeShiftRecord(shiftRecord);
    }
    async create(createShiftRecordDto) {
        try {
            this.logger.log(`🆕 Создание записи смены с автосинхронизацией: ${JSON.stringify(createShiftRecordDto)}`);
            const shiftRecord = this.shiftRecordRepository.create(createShiftRecordDto);
            const savedRecord = await this.shiftRecordRepository.save(shiftRecord);
            this.logger.log(`✅ Запись смены создана с ID: ${savedRecord.id}`);
            return this.findOne(savedRecord.id);
        }
        catch (error) {
            this.logger.error(`❌ Ошибка создания записи смены: ${error.message}`, error.stack);
            throw error;
        }
    }
    async update(id, updateShiftRecordDto) {
        try {
            this.logger.log(`📝 Обновление записи смены ${id} с автосинхронизацией: ${JSON.stringify(updateShiftRecordDto)}`);
            const existingRecord = await this.shiftRecordRepository.findOne({ where: { id } });
            if (!existingRecord) {
                throw new common_1.NotFoundException(`Запись смены с ID ${id} не найдена`);
            }
            Object.assign(existingRecord, updateShiftRecordDto);
            const updatedRecord = await this.shiftRecordRepository.save(existingRecord);
            this.logger.log(`✅ Запись смены ${id} успешно обновлена`);
            return this.findOne(id);
        }
        catch (error) {
            this.logger.error(`❌ Ошибка обновления записи смены ${id}: ${error.message}`, error.stack);
            throw error;
        }
    }
    async remove(id) {
        const shiftRecord = await this.shiftRecordRepository.findOne({ where: { id } });
        if (!shiftRecord) {
            throw new common_1.NotFoundException(`Запись смены с ID ${id} не найдена`);
        }
        await this.shiftRecordRepository.remove(shiftRecord);
    }
    async getStatistics(filterDto) {
        const records = await this.findAll(filterDto);
        const totalSetupTime = records.reduce((sum, record) => sum + (record.setupTime || 0), 0);
        const totalDayQuantity = records.reduce((sum, record) => sum + (record.dayShiftQuantity || 0), 0);
        const totalNightQuantity = records.reduce((sum, record) => sum + (record.nightShiftQuantity || 0), 0);
        const totalQuantity = totalDayQuantity + totalNightQuantity;
        const dayShiftTime = records.reduce((sum, record) => sum + (record.dayShiftQuantity || 0) * (record.dayShiftTimePerUnit || 0), 0);
        const nightShiftTime = records.reduce((sum, record) => sum + (record.nightShiftQuantity || 0) * (record.nightShiftTimePerUnit || 0), 0);
        const totalProductionTime = dayShiftTime + nightShiftTime;
        const operatorStats = {};
        records.forEach((record) => {
            if (record.dayShiftOperator) {
                if (!operatorStats[record.dayShiftOperator]) {
                    operatorStats[record.dayShiftOperator] = { quantity: 0, time: 0 };
                }
                operatorStats[record.dayShiftOperator].quantity += record.dayShiftQuantity || 0;
                operatorStats[record.dayShiftOperator].time +=
                    (record.dayShiftQuantity || 0) * (record.dayShiftTimePerUnit || 0);
            }
            if (record.nightShiftOperator) {
                if (!operatorStats[record.nightShiftOperator]) {
                    operatorStats[record.nightShiftOperator] = { quantity: 0, time: 0 };
                }
                operatorStats[record.nightShiftOperator].quantity += record.nightShiftQuantity || 0;
                operatorStats[record.nightShiftOperator].time +=
                    (record.nightShiftQuantity || 0) * (record.nightShiftTimePerUnit || 0);
            }
        });
        return {
            totalRecords: records.length,
            totalSetupTime,
            totalProductionTime,
            totalQuantity,
            dayShiftStats: {
                totalQuantity: totalDayQuantity,
                totalTime: dayShiftTime,
            },
            nightShiftStats: {
                totalQuantity: totalNightQuantity,
                totalTime: nightShiftTime,
            },
            operatorStats: Object.entries(operatorStats).map(([name, stats]) => ({
                operatorName: name,
                totalQuantity: stats.quantity,
                totalTime: stats.time,
            })),
        };
    }
    async getShiftsByDate(date) {
        const records = await this.shiftRecordRepository
            .createQueryBuilder('shift')
            .leftJoinAndSelect('shift.machine', 'machine')
            .leftJoinAndSelect('shift.operation', 'operation')
            .leftJoinAndSelect('operation.order', 'order')
            .where('shift.date = :date', { date })
            .getMany();
        return this.normalizeShiftRecords(records);
    }
    async getShiftsByOperator(operatorName) {
        const records = await this.shiftRecordRepository
            .createQueryBuilder('shift')
            .leftJoinAndSelect('shift.machine', 'machine')
            .leftJoinAndSelect('shift.operation', 'operation')
            .leftJoinAndSelect('operation.order', 'order')
            .where('(shift.dayShiftOperator = :operatorName OR shift.nightShiftOperator = :operatorName)', { operatorName })
            .orderBy('shift.date', 'DESC')
            .getMany();
        return this.normalizeShiftRecords(records);
    }
    async getShiftsByMachine(machineId) {
        const records = await this.shiftRecordRepository
            .createQueryBuilder('shift')
            .leftJoinAndSelect('shift.machine', 'machine')
            .leftJoinAndSelect('shift.operation', 'operation')
            .leftJoinAndSelect('operation.order', 'order')
            .where('shift.machineId = :machineId', { machineId })
            .orderBy('shift.date', 'DESC')
            .getMany();
        return this.normalizeShiftRecords(records);
    }
};
exports.ShiftsService = ShiftsService;
exports.ShiftsService = ShiftsService = ShiftsService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(shift_record_entity_1.ShiftRecord)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], ShiftsService);
//# sourceMappingURL=shifts.service.js.map