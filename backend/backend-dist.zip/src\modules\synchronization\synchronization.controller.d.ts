import { SynchronizationService } from './synchronization.service';
export declare class SynchronizationController {
    private readonly syncService;
    private readonly logger;
    constructor(syncService: SynchronizationService);
    assignOperationWithSync(request: {
        operationId: number;
        machineId: number;
    }): Promise<{
        success: boolean;
        message: string;
        synchronizationStatus: import("./synchronization.service").SynchronizationStatus;
        timestamp: Date;
    }>;
    updateOperationProgress(operationId: string): Promise<{
        success: boolean;
        message: string;
        synchronizationStatus: import("./synchronization.service").SynchronizationStatus;
        timestamp: Date;
    }>;
    getSynchronizationStatus(operationId: string): Promise<{
        success: boolean;
        operationId: number;
        status: import("./synchronization.service").SynchronizationStatus;
        timestamp: Date;
    }>;
    syncAllActiveOperations(): Promise<{
        success: boolean;
        message: string;
        results: import("./synchronization.service").SynchronizationStatus[];
        timestamp: Date;
    }>;
    healthCheck(): Promise<{
        success: boolean;
        message: string;
        statistics: {
            activeOperations: number;
            recentShifts: number;
        };
        timestamp: Date;
        error?: undefined;
    } | {
        success: boolean;
        message: string;
        error: any;
        timestamp: Date;
        statistics?: undefined;
    }>;
}
