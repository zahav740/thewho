"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var SynchronizationController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SynchronizationController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const synchronization_service_1 = require("./synchronization.service");
let SynchronizationController = SynchronizationController_1 = class SynchronizationController {
    constructor(syncService) {
        this.syncService = syncService;
        this.logger = new common_1.Logger(SynchronizationController_1.name);
    }
    async assignOperationWithSync(request) {
        try {
            this.logger.log(`🔗 Назначение операции ${request.operationId} на станок ${request.machineId} с синхронизацией`);
            if (!request.operationId || !request.machineId) {
                throw new common_1.BadRequestException('operationId и machineId обязательны');
            }
            const result = await this.syncService.assignOperationWithSync(request.operationId, request.machineId);
            return {
                success: true,
                message: `Операция ${request.operationId} назначена на станок ${request.machineId} и синхронизирована`,
                synchronizationStatus: result,
                timestamp: new Date(),
            };
        }
        catch (error) {
            this.logger.error('Ошибка назначения операции с синхронизацией:', error);
            throw error;
        }
    }
    async updateOperationProgress(operationId) {
        try {
            this.logger.log(`📊 Обновление прогресса операции ${operationId}`);
            const result = await this.syncService.updateOperationProgress(Number(operationId));
            return {
                success: true,
                message: `Прогресс операции ${operationId} обновлен`,
                synchronizationStatus: result,
                timestamp: new Date(),
            };
        }
        catch (error) {
            this.logger.error(`Ошибка обновления прогресса операции ${operationId}:`, error);
            throw error;
        }
    }
    async getSynchronizationStatus(operationId) {
        try {
            this.logger.log(`📋 Получение статуса синхронизации операции ${operationId}`);
            const status = await this.syncService.getSynchronizationStatus(Number(operationId));
            return {
                success: true,
                operationId: Number(operationId),
                status,
                timestamp: new Date(),
            };
        }
        catch (error) {
            this.logger.error(`Ошибка получения статуса синхронизации операции ${operationId}:`, error);
            throw error;
        }
    }
    async syncAllActiveOperations() {
        try {
            this.logger.log(`🔄 Запуск принудительной синхронизации всех операций`);
            const results = await this.syncService.syncAllActiveOperations();
            return {
                success: true,
                message: `Синхронизация завершена. Обработано ${results.length} операций`,
                results,
                timestamp: new Date(),
            };
        }
        catch (error) {
            this.logger.error('Ошибка принудительной синхронизации:', error);
            throw error;
        }
    }
    async healthCheck() {
        try {
            const activeOpsCount = await this.syncService['dataSource'].query(`
        SELECT COUNT(*) as count FROM operations 
        WHERE status IN ('ASSIGNED', 'IN_PROGRESS')
      `);
            const shiftsCount = await this.syncService['dataSource'].query(`
        SELECT COUNT(*) as count FROM shift_records 
        WHERE date >= CURRENT_DATE - INTERVAL '7 days'
      `);
            return {
                success: true,
                message: 'Система синхронизации работает корректно',
                statistics: {
                    activeOperations: Number(activeOpsCount[0].count),
                    recentShifts: Number(shiftsCount[0].count),
                },
                timestamp: new Date(),
            };
        }
        catch (error) {
            this.logger.error('Ошибка проверки работоспособности:', error);
            return {
                success: false,
                message: 'Ошибка в системе синхронизации',
                error: error.message,
                timestamp: new Date(),
            };
        }
    }
};
exports.SynchronizationController = SynchronizationController;
__decorate([
    (0, common_1.Post)('assign-operation'),
    (0, swagger_1.ApiOperation)({
        summary: 'Назначить операцию с автоматической синхронизацией',
        description: 'Назначает операцию на станок и автоматически создает связанную запись смены'
    }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Операция успешно назначена и синхронизирована' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], SynchronizationController.prototype, "assignOperationWithSync", null);
__decorate([
    (0, common_1.Post)('update-progress/:operationId'),
    (0, swagger_1.ApiOperation)({
        summary: 'Обновить прогресс операции',
        description: 'Пересчитывает прогресс операции на основе данных смен'
    }),
    __param(0, (0, common_1.Param)('operationId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SynchronizationController.prototype, "updateOperationProgress", null);
__decorate([
    (0, common_1.Get)('status/:operationId'),
    (0, swagger_1.ApiOperation)({
        summary: 'Получить статус синхронизации операции',
        description: 'Возвращает текущий статус синхронизации между операцией и сменами'
    }),
    __param(0, (0, common_1.Param)('operationId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], SynchronizationController.prototype, "getSynchronizationStatus", null);
__decorate([
    (0, common_1.Post)('sync-all'),
    (0, swagger_1.ApiOperation)({
        summary: 'Принудительная синхронизация всех активных операций',
        description: 'Пересчитывает прогресс всех активных операций на основе данных смен'
    }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SynchronizationController.prototype, "syncAllActiveOperations", null);
__decorate([
    (0, common_1.Get)('health'),
    (0, swagger_1.ApiOperation)({
        summary: 'Проверка работоспособности системы синхронизации'
    }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SynchronizationController.prototype, "healthCheck", null);
exports.SynchronizationController = SynchronizationController = SynchronizationController_1 = __decorate([
    (0, swagger_1.ApiTags)('synchronization'),
    (0, common_1.Controller)('sync'),
    __metadata("design:paramtypes", [synchronization_service_1.SynchronizationService])
], SynchronizationController);
//# sourceMappingURL=synchronization.controller.js.map