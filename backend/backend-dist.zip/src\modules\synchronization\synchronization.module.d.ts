export declare class SynchronizationModule {
}
