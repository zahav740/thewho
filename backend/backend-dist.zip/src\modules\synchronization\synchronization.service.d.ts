import { DataSource } from 'typeorm';
export interface OperationAssignedEvent {
    operationId: number;
    machineId: number;
    operationNumber: number;
    orderDrawingNumber: string;
    estimatedTime: number;
    operationType: string;
    assignedAt: Date;
}
export interface ShiftRecordCreatedEvent {
    shiftRecordId: number;
    operationId: number;
    machineId: number;
    date: Date;
    dayShiftQuantity?: number;
    nightShiftQuantity?: number;
    totalQuantity: number;
}
export interface SynchronizationStatus {
    operationId: number;
    machineId: number;
    operationStatus: string;
    hasShiftRecords: boolean;
    totalProduced: number;
    targetQuantity: number;
    progress: number;
    lastSyncAt: Date;
}
export declare class SynchronizationService {
    private readonly dataSource;
    private readonly logger;
    constructor(dataSource: DataSource);
    assignOperationWithSync(operationId: number, machineId: number): Promise<SynchronizationStatus>;
    updateOperationProgress(operationId: number): Promise<SynchronizationStatus>;
    getSynchronizationStatus(operationId: number): Promise<SynchronizationStatus>;
    syncAllActiveOperations(): Promise<SynchronizationStatus[]>;
}
