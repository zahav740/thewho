"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var SynchronizationService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.SynchronizationService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
let SynchronizationService = SynchronizationService_1 = class SynchronizationService {
    constructor(dataSource) {
        this.dataSource = dataSource;
        this.logger = new common_1.Logger(SynchronizationService_1.name);
    }
    async assignOperationWithSync(operationId, machineId) {
        this.logger.log(`🚀 Начинаем синхронизированное назначение операции ${operationId} на станок ${machineId}`);
        const queryRunner = this.dataSource.createQueryRunner();
        await queryRunner.connect();
        await queryRunner.startTransaction();
        try {
            const [operation] = await queryRunner.query(`
        SELECT op.*, ord.drawing_number as "orderDrawingNumber", ord.quantity as "orderQuantity"
        FROM operations op
        LEFT JOIN orders ord ON op."orderId" = ord.id
        WHERE op.id = $1
      `, [operationId]);
            if (!operation) {
                throw new Error(`Операция ${operationId} не найдена`);
            }
            const [machine] = await queryRunner.query(`
        SELECT * FROM machines WHERE id = $1 AND "isActive" = true
      `, [machineId]);
            if (!machine) {
                throw new Error(`Станок ${machineId} не найден или неактивен`);
            }
            await queryRunner.query(`
        UPDATE operations 
        SET "assignedMachine" = $1, "assignedAt" = NOW(), status = 'ASSIGNED'
        WHERE id = $2
      `, [machineId, operationId]);
            await queryRunner.query(`
        UPDATE machines 
        SET "isOccupied" = true, "currentOperation" = $1, "assignedAt" = NOW()
        WHERE id = $2
      `, [operationId, machineId]);
            const today = new Date().toISOString().split('T')[0];
            const [existingShift] = await queryRunner.query(`
        SELECT id FROM shift_records 
        WHERE "operationId" = $1 AND "machineId" = $2 AND date = $3
      `, [operationId, machineId, today]);
            let shiftRecordId;
            if (!existingShift) {
                const [newShift] = await queryRunner.query(`
          INSERT INTO shift_records (
            date, "shiftType", "operationId", "machineId", "drawingnumber",
            "dayShiftQuantity", "nightShiftQuantity", 
            "dayShiftTimePerUnit", "nightShiftTimePerUnit",
            "dayShiftOperator", "nightShiftOperator",
            "createdAt", "updatedAt"
          ) VALUES (
            $1, 'DAY', $2, $3, $4,
            0, 0,
            0, 0,
            null, null,
            NOW(), NOW()
          ) RETURNING id
        `, [today, operationId, machineId, operation.orderDrawingNumber]);
                shiftRecordId = newShift.id;
                this.logger.log(`✅ Создана новая запись смены ${shiftRecordId} для операции ${operationId}`);
            }
            else {
                shiftRecordId = existingShift.id;
                this.logger.log(`ℹ️ Используется существующая запись смены ${shiftRecordId}`);
            }
            await queryRunner.commitTransaction();
            const syncStatus = await this.getSynchronizationStatus(operationId);
            this.logger.log(`🎉 Операция ${operationId} успешно назначена и синхронизирована`);
            return syncStatus;
        }
        catch (error) {
            await queryRunner.rollbackTransaction();
            this.logger.error(`❌ Ошибка синхронизации операции ${operationId}:`, error);
            throw error;
        }
        finally {
            await queryRunner.release();
        }
    }
    async updateOperationProgress(operationId) {
        this.logger.log(`📊 Обновляем прогресс операции ${operationId}`);
        try {
            const shiftRecords = await this.dataSource.query(`
        SELECT * FROM shift_records 
        WHERE "operationId" = $1 AND archived = false
        ORDER BY date DESC
      `, [operationId]);
            const totalProduced = shiftRecords.reduce((sum, record) => {
                return sum + (record.dayShiftQuantity || 0) + (record.nightShiftQuantity || 0);
            }, 0);
            const targetQuantity = 30;
            const progress = Math.min((totalProduced / targetQuantity) * 100, 100);
            let newStatus = 'ASSIGNED';
            if (progress >= 100) {
                newStatus = 'COMPLETED';
            }
            else if (totalProduced > 0) {
                newStatus = 'IN_PROGRESS';
            }
            await this.dataSource.query(`
        UPDATE operations 
        SET 
          status = $1,
          "actualQuantity" = $2,
          "completedAt" = CASE WHEN $1 = 'COMPLETED' THEN NOW() ELSE "completedAt" END,
          "updatedAt" = NOW()
        WHERE id = $3
      `, [newStatus, totalProduced, operationId]);
            if (newStatus === 'COMPLETED') {
                await this.dataSource.query(`
          UPDATE machines 
          SET "isOccupied" = false, "currentOperation" = null
          WHERE "currentOperation" = $1
        `, [operationId]);
                this.logger.log(`🏁 Операция ${operationId} завершена, станок освобожден`);
            }
            return await this.getSynchronizationStatus(operationId);
        }
        catch (error) {
            this.logger.error(`❌ Ошибка обновления прогресса операции ${operationId}:`, error);
            throw error;
        }
    }
    async getSynchronizationStatus(operationId) {
        try {
            const [result] = await this.dataSource.query(`
        SELECT 
          op.id as "operationId",
          op."assignedMachine" as "machineId",
          op.status as "operationStatus",
          op."actualQuantity",
          COUNT(sr.id) as "shiftRecordsCount",
          COALESCE(SUM((sr."dayShiftQuantity" + sr."nightShiftQuantity")), 0) as "totalProduced"
        FROM operations op
        LEFT JOIN shift_records sr ON op.id = sr."operationId"
        WHERE op.id = $1
        GROUP BY op.id, op."assignedMachine", op.status, op."actualQuantity"
      `, [operationId]);
            if (!result) {
                throw new Error(`Операция ${operationId} не найдена`);
            }
            const targetQuantity = 30;
            const totalProduced = Number(result.totalProduced) || 0;
            const progress = Math.min((totalProduced / targetQuantity) * 100, 100);
            return {
                operationId: result.operationId,
                machineId: result.machineId,
                operationStatus: result.operationStatus,
                hasShiftRecords: Number(result.shiftRecordsCount) > 0,
                totalProduced,
                targetQuantity,
                progress,
                lastSyncAt: new Date(),
            };
        }
        catch (error) {
            this.logger.error(`❌ Ошибка получения статуса синхронизации:`, error);
            throw error;
        }
    }
    async syncAllActiveOperations() {
        this.logger.log(`🔄 Начинаем принудительную синхронизацию всех активных операций`);
        try {
            const activeOperations = await this.dataSource.query(`
        SELECT id FROM operations 
        WHERE status IN ('ASSIGNED', 'IN_PROGRESS') 
        AND "assignedMachine" IS NOT NULL
      `);
            const results = [];
            for (const { id } of activeOperations) {
                try {
                    const status = await this.updateOperationProgress(id);
                    results.push(status);
                }
                catch (error) {
                    this.logger.error(`Ошибка синхронизации операции ${id}:`, error);
                }
            }
            this.logger.log(`✅ Синхронизация завершена. Обработано ${results.length} операций`);
            return results;
        }
        catch (error) {
            this.logger.error(`❌ Ошибка принудительной синхронизации:`, error);
            throw error;
        }
    }
};
exports.SynchronizationService = SynchronizationService;
exports.SynchronizationService = SynchronizationService = SynchronizationService_1 = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectDataSource)()),
    __metadata("design:paramtypes", [typeorm_2.DataSource])
], SynchronizationService);
//# sourceMappingURL=synchronization.service.js.map