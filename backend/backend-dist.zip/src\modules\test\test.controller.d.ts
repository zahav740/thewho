import { DataSource } from 'typeorm';
export declare class TestController {
    private readonly dataSource;
    constructor(dataSource: DataSource);
    simpleTest(): Promise<{
        status: string;
        message: string;
        timestamp: string;
    }>;
    testDb(): Promise<{
        status: string;
        dbConnection: boolean;
        machineCount: number;
        timestamp: string;
        error?: undefined;
    } | {
        status: string;
        dbConnection: boolean;
        error: any;
        timestamp: string;
        machineCount?: undefined;
    }>;
    testMachines(): Promise<{
        status: string;
        machines: any;
        count: any;
        timestamp: string;
        error?: undefined;
    } | {
        status: string;
        error: any;
        timestamp: string;
        machines?: undefined;
        count?: undefined;
    }>;
}
