"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Translation = exports.TranslationsController = exports.TranslationsService = exports.TranslationsModule = void 0;
var translations_module_1 = require("./translations.module");
Object.defineProperty(exports, "TranslationsModule", { enumerable: true, get: function () { return translations_module_1.TranslationsModule; } });
var translations_service_1 = require("./translations.service");
Object.defineProperty(exports, "TranslationsService", { enumerable: true, get: function () { return translations_service_1.TranslationsService; } });
var translations_controller_1 = require("./translations.controller");
Object.defineProperty(exports, "TranslationsController", { enumerable: true, get: function () { return translations_controller_1.TranslationsController; } });
var translation_entity_1 = require("./translation.entity");
Object.defineProperty(exports, "Translation", { enumerable: true, get: function () { return translation_entity_1.Translation; } });
//# sourceMappingURL=index.js.map