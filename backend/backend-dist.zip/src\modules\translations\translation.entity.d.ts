export declare class Translation {
    id: number;
    key: string;
    ru: string;
    en: string;
    category: string;
    created_at: Date;
    updated_at: Date;
}
