import { TranslationsService, CreateTranslationDto, UpdateTranslationDto } from './translations.service';
import { Translation } from './translation.entity';
export declare class TranslationsController {
    private readonly translationsService;
    constructor(translationsService: TranslationsService);
    findAll(category?: string): Promise<Translation[]>;
    getClientTranslations(): Promise<{
        ru: Record<string, string>;
        en: Record<string, string>;
    }>;
    findByKey(key: string): Promise<Translation>;
    create(createTranslationDto: CreateTranslationDto): Promise<Translation>;
    update(key: string, updateTranslationDto: UpdateTranslationDto): Promise<Translation>;
    delete(key: string): Promise<{
        message: string;
    }>;
    upsert(createTranslationDto: CreateTranslationDto): Promise<Translation>;
    bulkUpsert(translations: CreateTranslationDto[]): Promise<Translation[]>;
}
