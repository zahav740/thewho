"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TranslationsController = void 0;
const common_1 = require("@nestjs/common");
const translations_service_1 = require("./translations.service");
let TranslationsController = class TranslationsController {
    constructor(translationsService) {
        this.translationsService = translationsService;
    }
    async findAll(category) {
        try {
            if (category) {
                return await this.translationsService.findByCategory(category);
            }
            return await this.translationsService.findAll();
        }
        catch (error) {
            throw new common_1.HttpException('Failed to fetch translations', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async getClientTranslations() {
        try {
            return await this.translationsService.getTranslationsForClient();
        }
        catch (error) {
            throw new common_1.HttpException('Failed to fetch client translations', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async findByKey(key) {
        try {
            const translation = await this.translationsService.findByKey(key);
            if (!translation) {
                throw new common_1.HttpException(`Translation with key '${key}' not found`, common_1.HttpStatus.NOT_FOUND);
            }
            return translation;
        }
        catch (error) {
            if (error instanceof common_1.HttpException) {
                throw error;
            }
            throw new common_1.HttpException('Failed to fetch translation', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async create(createTranslationDto) {
        try {
            return await this.translationsService.create(createTranslationDto);
        }
        catch (error) {
            if (error.code === '23505') {
                throw new common_1.HttpException(`Translation with key '${createTranslationDto.key}' already exists`, common_1.HttpStatus.CONFLICT);
            }
            throw new common_1.HttpException('Failed to create translation', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async update(key, updateTranslationDto) {
        try {
            return await this.translationsService.update(key, updateTranslationDto);
        }
        catch (error) {
            if (error.message.includes('not found')) {
                throw new common_1.HttpException(`Translation with key '${key}' not found`, common_1.HttpStatus.NOT_FOUND);
            }
            throw new common_1.HttpException('Failed to update translation', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async delete(key) {
        try {
            await this.translationsService.delete(key);
            return { message: `Translation with key '${key}' successfully deleted` };
        }
        catch (error) {
            throw new common_1.HttpException('Failed to delete translation', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async upsert(createTranslationDto) {
        try {
            return await this.translationsService.upsert(createTranslationDto);
        }
        catch (error) {
            throw new common_1.HttpException('Failed to upsert translation', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async bulkUpsert(translations) {
        try {
            return await this.translationsService.bulkUpsert(translations);
        }
        catch (error) {
            throw new common_1.HttpException('Failed to bulk upsert translations', common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
};
exports.TranslationsController = TranslationsController;
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('category')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], TranslationsController.prototype, "findAll", null);
__decorate([
    (0, common_1.Get)('client'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], TranslationsController.prototype, "getClientTranslations", null);
__decorate([
    (0, common_1.Get)(':key'),
    __param(0, (0, common_1.Param)('key')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], TranslationsController.prototype, "findByKey", null);
__decorate([
    (0, common_1.Post)(),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], TranslationsController.prototype, "create", null);
__decorate([
    (0, common_1.Put)(':key'),
    __param(0, (0, common_1.Param)('key')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, Object]),
    __metadata("design:returntype", Promise)
], TranslationsController.prototype, "update", null);
__decorate([
    (0, common_1.Delete)(':key'),
    __param(0, (0, common_1.Param)('key')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], TranslationsController.prototype, "delete", null);
__decorate([
    (0, common_1.Post)('upsert'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], TranslationsController.prototype, "upsert", null);
__decorate([
    (0, common_1.Post)('bulk-upsert'),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Array]),
    __metadata("design:returntype", Promise)
], TranslationsController.prototype, "bulkUpsert", null);
exports.TranslationsController = TranslationsController = __decorate([
    (0, common_1.Controller)('translations'),
    __metadata("design:paramtypes", [translations_service_1.TranslationsService])
], TranslationsController);
//# sourceMappingURL=translations.controller.js.map