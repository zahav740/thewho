export declare class TranslationsModule {
}
