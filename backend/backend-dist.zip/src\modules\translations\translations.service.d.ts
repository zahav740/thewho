import { Repository } from 'typeorm';
import { Translation } from './translation.entity';
export interface CreateTranslationDto {
    key: string;
    ru: string;
    en: string;
    category?: string;
}
export interface UpdateTranslationDto {
    ru?: string;
    en?: string;
    category?: string;
}
export declare class TranslationsService {
    private translationRepository;
    constructor(translationRepository: Repository<Translation>);
    findAll(): Promise<Translation[]>;
    findByCategory(category: string): Promise<Translation[]>;
    findByKey(key: string): Promise<Translation | null>;
    create(createTranslationDto: CreateTranslationDto): Promise<Translation>;
    update(key: string, updateTranslationDto: UpdateTranslationDto): Promise<Translation>;
    delete(key: string): Promise<void>;
    upsert(createTranslationDto: CreateTranslationDto): Promise<Translation>;
    bulkUpsert(translations: CreateTranslationDto[]): Promise<Translation[]>;
    getTranslationsForClient(): Promise<{
        ru: Record<string, string>;
        en: Record<string, string>;
    }>;
}
