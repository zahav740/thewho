"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TranslationsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const translation_entity_1 = require("./translation.entity");
let TranslationsService = class TranslationsService {
    constructor(translationRepository) {
        this.translationRepository = translationRepository;
    }
    async findAll() {
        return this.translationRepository.find({
            order: { category: 'ASC', key: 'ASC' }
        });
    }
    async findByCategory(category) {
        return this.translationRepository.find({
            where: { category },
            order: { key: 'ASC' }
        });
    }
    async findByKey(key) {
        return this.translationRepository.findOne({ where: { key } });
    }
    async create(createTranslationDto) {
        const translation = this.translationRepository.create(createTranslationDto);
        return this.translationRepository.save(translation);
    }
    async update(key, updateTranslationDto) {
        await this.translationRepository.update({ key }, updateTranslationDto);
        const updatedTranslation = await this.findByKey(key);
        if (!updatedTranslation) {
            throw new Error(`Translation with key ${key} not found`);
        }
        return updatedTranslation;
    }
    async delete(key) {
        await this.translationRepository.delete({ key });
    }
    async upsert(createTranslationDto) {
        const existing = await this.findByKey(createTranslationDto.key);
        if (existing) {
            return this.update(createTranslationDto.key, {
                ru: createTranslationDto.ru,
                en: createTranslationDto.en,
                category: createTranslationDto.category,
            });
        }
        else {
            return this.create(createTranslationDto);
        }
    }
    async bulkUpsert(translations) {
        const results = [];
        for (const translation of translations) {
            const result = await this.upsert(translation);
            results.push(result);
        }
        return results;
    }
    async getTranslationsForClient() {
        const translations = await this.findAll();
        const result = {
            ru: {},
            en: {},
        };
        translations.forEach((translation) => {
            result.ru[translation.key] = translation.ru;
            result.en[translation.key] = translation.en;
        });
        return result;
    }
};
exports.TranslationsService = TranslationsService;
exports.TranslationsService = TranslationsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(translation_entity_1.Translation)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], TranslationsService);
//# sourceMappingURL=translations.service.js.map