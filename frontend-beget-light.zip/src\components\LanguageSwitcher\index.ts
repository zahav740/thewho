/**
 * @file: index.ts
 * @description: Экспорт компонента LanguageSwitcher
 * @created: 2025-01-28
 */

export { LanguageSwitcher } from './LanguageSwitcher';
