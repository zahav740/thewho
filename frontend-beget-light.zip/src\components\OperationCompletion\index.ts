// Главный экспорт для OperationCompletion
import OperationCompletionModal from './OperationCompletionModal';
export type { OperationCompletionModalProps } from './OperationCompletionModal';
export { OperationCompletionModal };
export default OperationCompletionModal;
