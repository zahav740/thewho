/**
 * @file: index.ts
 * @description: Экспорт компонента модального окна деталей операции
 * @created: 2025-06-07
 */
export { default as OperationDetailsModal } from './OperationDetailsModal';
