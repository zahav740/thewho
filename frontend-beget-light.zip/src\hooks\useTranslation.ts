/**
 * @file: hooks/useTranslation.ts
 * @description: Реэкспорт хука useTranslation для удобства импорта
 * @created: 2025-06-11
 */

export { useTranslation } from '../i18n';
