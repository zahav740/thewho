/**
 * @file: index.ts
 * @description: Экспорт компонентов страницы История операций
 * @created: 2025-06-07
 */
export { default as OperationHistory } from './OperationHistory';
