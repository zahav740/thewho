/**
 * @file: index.ts
 * @description: Экспорт страницы переводов
 * @created: 2025-01-28
 */

export { TranslationsPage } from './TranslationsPage';
