/**
 * @file: index.ts
 * @description: Экспорт сервиса истории операций
 * @created: 2025-06-07
 */
export * from './operationHistoryService';
